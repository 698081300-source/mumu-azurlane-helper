"""Alas 侧：找安装、读写配置、单任务起引擎、拉起 GUI（逃生舱）。

原则（见 `AGENTS.md`）：**只调用，不修改**。
壳不改 Alas 一行代码，也不映射它的内部字段；只用它的两个公开入口：
  - `config/alas.json`（配置）
  - `alas.py` 的 `AzurLaneAutoScript().run('event')`（单任务，绕开调度器）

为什么必须是单任务入口：走 `python alas.py` 会进调度器 `loop()`，
而调度器里「委托 / 科研 / 收获」是**写死强制开启**的（`i18n/zh-CN.json:321`），
用户点一下得先等它们跑完；单任务入口不查队列，它们一次都不会跑。
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

from onetap import paths
from onetap.mumu import SAFE_CWD, no_console     # 起子进程一律不要黑框（原因见 mumu.no_console）

TASK = "Event"                       # 「活动图」任务
MAIN_TASK = "Main"                   # 「主线」任务（Alas 有 Main/Main2/Main3 三个槽，壳只用 Main）
IMMEDIATE = "2020-01-01 00:00:00"    # Alas 的「立即运行」哨兵值
MODE_3STARS = "map_3_stars"          # 打到「100%通关 + 三星」
MODE_OIL = "non_stop"                # 「刷光石油」：不因关卡成就停，只等油不够

# 上面两个 mode 就是 Alas `StopCondition_MapAchievement` 的两个取值
# （`module/config/i18n/zh-CN.json:913-921`，non_stop 的中文名叫"否"）：
#   三星模式 → 达成成就即停（`fast_forward.py:447-469` 的 triggered_map_stop）
#   刷油模式 → 永不因成就停，唯一的刹车是油
#              （`module/campaign/run.py:95-100`：get_oil() < max(500, OilLimit) → 推迟 2~4h 后退出）
EMOTION_IGNORE = "ignore"            # 心情控制的「关」值，见 _ignore_emotion()

# 「清日常」跑的那几个任务。挑的标准（2026-10-15 定，见 AGENTS.md 的边界）：
# **日常都会做、而且点一下就完事** —— 不需要用户做任何选择。
# 左边是 Alas 的任务组名，右边是 Alas 自己的中文名（`module/config/i18n/zh-CN.json:129-191`）。
# **明确不搬**：困难图 / 每日任务 / 演习（要选打哪张图、还要打几分钟）、
# 商店 / 抽卡 / 宿舍计划 / 开发船坞 / 指挥喵（要替用户花资源做选择）、大舰队（要兑换清单）。
DAILY_TASKS: tuple[tuple[str, str], ...] = (
    ("Reward", "收获"),          # 领邮件里的油 / 金币 / 经验 / 每日任务奖励
    ("Freebies", "白嫖奖励"),    # 领通行证 / 数据密钥 / 补给箱 / 邮件功勋
    ("Dorm", "后宅"),            # 收后宅产出 + 喂食
    ("Commission", "委托"),      # 收委托 + 按优先级派新委托
    ("Research", "科研"),        # 挂一个科研项目
)
PARK_HOURS = 11                      # 把"别的任务"顶到"现在 + 这个小时数"，见 _park_target()

# 「活动每日」那 5 个任务 —— **Alas 自带的每日三倍专用任务**，不是我们发明的：
#   EventA~D → `module/event/campaign_abcd.py`：按 `EventDaily.StageFilter` 把该图每个小关
#              各打一趟（`total=1`），跑完把任务推迟到明天服务器刷新，还能断点续跑
#   EventSp  → `module/event/campaign_sp.py`：SP 打一趟，同样顺延到明天
EVENT_DAILY: tuple[tuple[str, str], ...] = (
    ("EventA", "A 图"), ("EventB", "B 图"), ("EventC", "C 图"),
    ("EventD", "D 图"), ("EventSp", "SP 图"),
)
# `campaign/event_20260908_cn` ← Alas 自己的活动目录命名，日期就是活动上线日
EVENT_FOLDER = re.compile(r"^event_(\d{8})_(\w+)$")
KEEP_BACKUPS = 5                     # 配置备份最多留几份，见 _prune_backups()
DEFAULT_WEBUI_PORT = 22267           # Alas 设置页面的端口（config/deploy.yaml 里的 WebuiPort）
TIME_FMT = "%Y-%m-%d %H:%M:%S"


def _load_state() -> dict:
    """壳改写 Alas 配置时的「原值快照」，供「还原配置」精确放回去。

    结构：`{"times": {任务: 原 NextRun}, "tasks": {任务: {组名: 原值块}}}`
    —— 壳动的是两类东西：**别的任务的运行时间**，和**被接管那个任务的几组配置**
    （`Campaign` / `StopCondition` / `Emotion`，见 `_snapshot`），两类都要能还原。

    兼容两个旧格式（都真实在盘上出现过）：
      最早：整份就是一个扁平的 `{任务: 时间}`
      上一版：多一个单独的 `"emotion_mode"` 键
    """
    try:
        data = json.loads(paths.park_state().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    if "times" not in data:
        data = {"times": data}
    if "emotion_mode" in data:
        mode = data.pop("emotion_mode")
        data.setdefault("tasks", {}).setdefault(TASK, {})["Emotion"] = {"Mode": mode}
    if not isinstance(data.get("times"), dict):
        data["times"] = {}
    if not isinstance(data.get("tasks"), dict):
        data["tasks"] = {}
    return data


def _save_state(state: dict) -> None:
    paths.park_state().write_text(
        json.dumps(state, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _prune_backups(path: Path, keep: int) -> None:
    """只留最近 `keep` 份 `*.bak-*`。

    壳每写一次配置就备份一份，而「自动下一关」一晚上能写几十次 →
    不清理的话 Alas 的 config 目录会被 `.bak-20261015-153000` 这种文件淹掉。
    文件名带时间戳，字典序 = 时间序，所以直接按名字排着删最老的。
    """
    olds = sorted(path.parent.glob(f"{path.name}.bak-*"))
    for old in olds[:-keep]:
        try:
            old.unlink()
        except OSError:
            pass


def _park_target() -> str:
    """「顶出去」时写的目标时间：**现在 + 11 小时**。

    **不能更远** —— Alas 有个"未来上限"机制（`module/config/config.py:287-315`）：
        limit_next_run(["Commission", "Reward"], limit=now + 12小时 - 1秒)   # config.py:310
        limit_next_run(["Research"],            limit=now + 24小时 - 1秒)   # config.py:311
        limit_next_run(["OpsiExplore", ...],    limit=now + 31天   - 1秒)
        limit_next_run(["OpsiArchive"],         limit=now + 7天    - 1秒)
        limit_next_run(self.args.keys(),        limit=now + 24小时 - 1秒)   # config.py:315 ← 所有任务
    任何任务的 NextRun **超过上限就会被拉回"现在"** → 又变 pending → 推关照样被打断。

    （实测踩过：第一版顶到 `2099-01-01`，结果 56 个任务**全被拉回同一个"现在"**。）

    11 小时 < 上面**所有**上限（12h / 24h / 7天 / 31天），所以一定不被拉回；
    而一次三星只要几分钟，11 小时富余得多。
    """
    return (datetime.now() + timedelta(hours=PARK_HOURS)).strftime(TIME_FMT)


def _is_parked(next_run: object) -> bool:
    """这个时间是不是已经被壳顶到远期了（按"还在 5 小时之后"算）。"""
    try:
        return datetime.strptime(str(next_run), TIME_FMT) > datetime.now() + timedelta(hours=5)
    except ValueError:
        return False


def _written_by_shell(next_run: object) -> bool:
    """这个值是不是壳写进去的：**顶到远期**，或者**设成"立即运行"**。

    还原时只放回壳写过的值，两头的理由不一样：
      - 顶到远期的 → 那个值本来就是壳的临时状态，必须放回原值；
      - "立即运行"的 → 壳起引擎前写的就是它（`set_stage` / `set_daily`），
        如果那个任务压根没跑成（维护中、起不来），它会一直留在"立即运行"，
        不还原就会在用户下次用 Alas 调度器时**插队乱跑**（2026-10-15 实测踩到）。
    反过来，Alas 自己后来改过的值（例如任务跑完把自己排到 30 分钟后）**不覆盖** ——
    那是它更新的、更准的排期。
    """
    return _is_parked(next_run) or str(next_run) == IMMEDIATE


def _park_others(data: dict, keep: set[str]) -> dict[str, str]:
    """把除 `keep`（这次要接管的那几个任务）外所有任务的 `Scheduler.NextRun` 顶出去。

    返回 `{任务名: 顶之前的值}`。**调用方用 `setdefault` 入库**，
    所以"原值只记第一次"这件事由调用方保证，这里只管顶。

    **不要"看时间猜这个值像不像我们顶的"**（2026-10-15 自查改掉）：
    一个天然排期就落在 5 小时后的任务（例如 `Restart` 的"次日 00:00"）会被那个猜测
    当成"壳已经顶过"而**既不顶、也不记** → 它 pending 着 → 轻则打断推关，
    重则让 Alas 提前 `task_switch` 收工（那正是推关走不到第二步的原因）。

    原值会被壳记进 `park_state.json`，供「还原配置」**精确**放回去
    —— 不能靠猜（原值有的是 `2020-01-01`，有的是真实排期，例如 `Restart` = 次日 00:00）。

    **为什么必须顶（2026-10-14 实测，同一份日志里正反对照）**：
      `module/campaign/run.py:463-465` 每跑完一趟图都会检查 `task_switched()`，
      是就立刻 `task_stop()` 收工。而委托 / 科研 / 收获是 Alas **强制开启**、壳关不掉的
      （`module/config/i18n/zh-CN.json:321` 原文："委托、科研、收获任务是强制打开的"），
      它们的 `NextRun` 又是过去时间 → **永远挂着 pending**。

      后果不只是"提前收工"，还会**让 Alas 永远走不到推进关卡那一步**：
      「向前开荒」是在**下一趟进图**时才检查的
      （`map_operation.py:169` 只在"出击准备"前检查，而地图要打完 BOSS 才满星），
      正常日志应该是：
          <<< CAMPAIGN END >>> → <<< ENTER MAP >>> → <<< ENTER MAP CANCEL >>> → <<< SCRIPT END >>>
      被 `task_switched()` 砍掉后，后半段再也不会出现 → 关卡永远停在原地。

    实测：16:39/16:57 两趟跑在 `Research.NextRun=17:12` 之前 → 不干扰 → 推关成功 ✓
          17:46/18:01 两趟跑在 17:12 之后 → 科研 pending → 砍在半路 ✗

    改 `Enable` 没用（锁死的会自己变回来），**得改 `NextRun`**。
    """
    target = _park_target()
    parked: dict[str, str] = {}
    for task, value in data.items():
        if task in keep or not isinstance(value, dict):
            continue
        sched = value.get("Scheduler")
        if not isinstance(sched, dict) or "NextRun" not in sched:
            continue
        if task not in keep:
            parked[task] = str(sched["NextRun"])
        sched["NextRun"] = target
    return parked


def _ignore_emotion(event: dict) -> str | None:
    """把「活动图」的心情控制关掉，返回原值（本来就是关的 → None）。

    `ignore` 在 Alas 里的三个作用（`module/combat/emotion.py:164-168`）：
      `is_calculate` False → **进图前不再预留心情**（`check_reduce` 直接 return，不再推迟任务）
                            **每次战斗前不再等心情**（`module/map/map.py:29` 那个 wait 被跳过）
      `is_ignore`     True → 低心情弹窗会被自动确认（`module/handler/info_handler.py:187-195`）

    **为什么必须关**（2026-10-14 实测，`logs/onetap_20261014-203601.log:2550-2563`）：
      Alas 判"这关三星了没"是在**下一次进图**时看的（`module/map/map_operation.py:167-172`），
      而那一步一次战斗都不打，却仍按**整图**预留心情（`check_reduce(self._map_battle)`）
      → 心情只要低于约 48，每关打完都得干等 6~12 分钟才肯确认并推关 → 推关链条直接断掉。
      那一刻的现象是"图明明打完了、关卡却没往前动"。

    用户要的就是"不影响我出击" —— 心情照旧由他本人看着办，壳不替他排队。
    """
    emotion = event.get("Emotion")
    if not isinstance(emotion, dict):
        return None
    old = str(emotion.get("Mode", ""))
    if not old or old == EMOTION_IGNORE:
        return None
    emotion["Mode"] = EMOTION_IGNORE
    return old

INSTALL_CANDIDATES = (
    Path(r"E:\bilan\AlasApp_0.4.10_fullcn\AzurLaneAutoScript"),
    Path(r"D:\bilan\AlasApp_0.4.10_fullcn\AzurLaneAutoScript"),
)
# 用户手选过的 Alas 位置（一行路径，放用户目录 —— 覆盖式更新不会冲掉）
ALAS_PATH = paths.data_dir() / "alas-path.txt"


class AlasError(RuntimeError):
    """Alas 侧的可预期错误（找不到安装、缺配置…），直接拿给用户看。"""


def saved_install() -> Path | None:
    """上次用户自己选的 Alas 目录（现在还在、还像 Alas → 返回它）。"""
    try:
        text = ALAS_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    path = Path(text)
    return path if is_root(path) else None


def remember_install(root: Path) -> None:
    """记住用户选的 Alas 位置 —— 交给他人的第一件事就是这个（2026-10-19）。"""
    try:
        ALAS_PATH.write_text(str(root), encoding="utf-8")
    except OSError:
        pass


def find_install() -> Path | None:
    """找 Alas：环境变量 → 用户选过的 → 开发机上的固定位置。

    ⚠️ 后两个候选只对**我们自己的机器**有意义 —— 别人的 Alas 装在哪儿只有他自己知道，
    所以 `saved_install()` 才是真正给用户的路径（第一次由界面弹框让他选，选完记住）。
    真·全盘搜索见 `discover_install()`（首次启动在后台跑，找到就直接用，不用他选）。
    """
    env = os.environ.get("ALAS_ROOT")
    if env and is_root(Path(env)):
        return Path(env)
    saved = saved_install()
    if saved:
        return saved
    for root in INSTALL_CANDIDATES:
        if is_root(root):
            return root
    return None


# 扫盘时不进的目录（系统目录进去纯浪费；AppData 里是缓存，不是安装位置）
SCAN_SKIP = frozenset({
    "windows", "windows.old", "programdata", "appdata", "$recycle.bin",
    "system volume information", "recovery", "perflogs", "node_modules",
    ".git", "__pycache__", "temp", "tmp",
})


def discover_install(deadline_s: float = 8.0) -> Path | None:
    """真的去硬盘上找 Alas（2026-10-20 用户质疑"你说没找到，到底找没找" —— 之前确实没找）。

    只认目录名带 `alas` 的（`AlasApp_x.x.x`、`AzurLaneAutoScript`、用户自建的 `Alas`），
    命中后用 `find_root_under()` 认出真正的根目录（`alas.py` + `module\\`）——
    **不能只看 alas.py**：2026-10-20 实测有人的包里 `alas.py` 在 `…\\deploy\\` 这一层。
    """
    deadline = time.time() + deadline_s
    for root in _scan_roots():
        if not root.exists():
            continue
        found = _scan_dir(root, depth=3, deadline=deadline)
        if found:
            return found
    return None


def _scan_roots() -> list[Path]:
    home = Path.home()
    roots = [home / name for name in ("Desktop", "Downloads", "Documents",
                                      "OneDrive/Desktop", "OneDrive/Downloads")]
    for drive in "CDEFGH":
        roots.append(Path(f"{drive}:\\"))
    roots.append(Path(r"C:\Program Files"))
    roots.append(Path(r"C:\Program Files (x86)"))
    return roots


def _scan_dir(path: Path, depth: int, deadline: float) -> Path | None:
    if time.time() > deadline:
        return None
    try:
        entries = list(os.scandir(path))
    except OSError:
        return None
    for entry in entries:
        try:
            if not entry.is_dir(follow_symlinks=False):
                continue
        except OSError:
            continue
        name = entry.name.lower()
        if name in SCAN_SKIP:
            continue
        child = Path(entry.path)
        if "alas" in name:
            found = find_root_under(child, depth=2)
            if found:
                return found
        if depth > 1:
            found = _scan_dir(child, depth - 1, deadline)
            if found:
                return found
    return None


def discover_launcher(deadline_s: float = 6.0) -> Path | None:
    """找一个"只有启动器、本体没下载"的 Alas 目录 —— 用来告诉用户到底卡在哪一步。"""
    deadline = time.time() + deadline_s
    for root in _scan_roots():
        if not root.exists():
            continue
        hit = _search(root, 3, is_launcher_only)
        if hit:
            return hit
    return None


def task_for(stage: str) -> str:
    """这一关归哪个 Alas 任务：`12-4` 这种是主线，`C1` / `SP` 这种是活动图。

    名字形态就能分（两套不打架）：主线是"数字-数字"，活动是"字母+数字"。
    判错也不会跑错图 —— 真跑起来壳会用日志里的 `CAMPAIGN_xxx` 核对（见 app.py）。

    主线在 Alas 里有 Main / Main2 / Main3 三个队列槽（`alas.py:353-366`），壳只用 Main。
    """
    return MAIN_TASK if re.fullmatch(r"\d+-\d+", (stage or "").strip()) else TASK


def _stage_sort_key(name: str) -> tuple:
    """候选列表排序：活动关在前（A1…D3、SP），主线关在后（1-1…14-4）。"""
    if "-" in name:
        chapter, stage = name.split("-", 1)
        return (1, int(chapter), int(stage))
    number = name[1:]
    return (0, name[0], int(number) if number.isdigit() else 0)


def _stages_in_folder(folder: Path) -> list[str]:
    """扫一个图数据目录，把文件名还原成关卡代号。

    实测两种命名（2026-10-15，来自 `campaign/` 下真实目录）：
      活动 `campaign/event_20250520_cn/` → `c3.py` / `sp.py`  → `C3` / `SP`（13 张）
      主线 `campaign/campaign_main/`    → `campaign_12_4.py`  → `12-4`（72 张，1-1…14-4）
    只按名字形态认关卡，别的一律丢掉（例如 `campaign_support_fleet.py`）。
    """
    if not folder.is_dir():
        return []
    out: list[str] = []
    for path in folder.glob("*.py"):
        stem = path.stem.upper()
        main = re.fullmatch(r"CAMPAIGN_(\d+)_(\d+)", stem)
        if main:
            out.append(f"{main.group(1)}-{main.group(2)}")
        elif re.fullmatch(r"[A-D][1-9]|SP\d*", stem):
            out.append(stem)
    return sorted(out, key=_stage_sort_key)


def _snapshot(state: dict, task: str, node: dict) -> bool:
    """把**壳要改的那几块**原值整块记下来（只记第一次），返回是否记了新的。

    为什么整块记而不是逐字段：壳改的值散在 `Campaign` / `StopCondition` / `Emotion` 里，
    逐字段记容易漏 —— 尤其主线，它的默认是"无限刷图"
    （`MapAchievement = non_stop` + `UseClearMode = true`），漏一个，
    用户的刷图配置就被壳悄悄改掉了，而他还以为「还原配置」能放回去。
    """
    saved = state.setdefault("tasks", {}).setdefault(task, {})
    recorded = False
    for group in ("Campaign", "StopCondition", "Emotion"):
        block = node.get(group)
        if isinstance(block, dict) and group not in saved:
            saved[group] = dict(block)
            recorded = True
    return recorded


def find_pids(match: str) -> list[int]:
    """找出命令行里含 `match` 的 python 进程号（Windows）。

    只用来做两件事：**清理上一轮残留的引擎**、**拦住第二个小窗**。
    标准库里没有"按命令行找进程"，只能问 WMI（PowerShell `Get-CimInstance`）。
    """
    script = ('Get-CimInstance Win32_Process -Filter "name like \'python%\'" | '
              f"Where-Object {{ $_.CommandLine -like '*{match}*' }} | "
              "Select-Object -ExpandProperty ProcessId")
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", script],
                             capture_output=True, timeout=30,
                             cwd=SAFE_CWD,      # 别让子进程把 cwd 落在安装目录里（会锁文件夹）
                             **no_console()).stdout.decode("utf-8", "ignore")
    except (OSError, subprocess.TimeoutExpired):
        return []
    return [int(x) for x in out.split() if x.strip().isdigit()]


def kill_pids(pids: list[int]) -> int:
    """强杀这些进程，返回杀掉了几个。"""
    killed = 0
    for pid in pids:
        try:
            subprocess.run(["taskkill", "/PID", str(pid), "/F"],
                           capture_output=True, timeout=15, cwd=SAFE_CWD, **no_console())
            killed += 1
        except (OSError, subprocess.TimeoutExpired):
            pass
    return killed


def missing_hint() -> str:
    """找不到 Alas 时给用户看的那句话 —— **要能区分"没选过"和"选过但失效了"**。

    2026-10-20 新机实测：用户选过一次，下次还是报"还没告诉我"，但看不出到底哪一步没成。
    """
    try:
        raw = ALAS_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        raw = ""
    if raw and not is_root(Path(raw)):
        return f"上次记住的 Alas 位置失效了：{raw}（点「选 Alas 文件夹」重选一次）"
    return "还没告诉我 Alas 装在哪 —— 点「选 Alas 文件夹」指一下就行"


def has_code(path: Path) -> bool:
    """Alas 的**本体代码**在不在：`module\\` 在本层或 `deploy\\`。

    只装启动器时这里是空的 —— 壳靠它判断"要不要等它下载完"（见 app._bootstrap_alas）。
    """
    return (path / "module").is_dir() or (path / "deploy" / "module").is_dir()


def is_root(path: Path) -> bool:
    """这是不是 Alas 的**工作目录**（它的相对路径 `config/ assets/ log/` 都以它为基准）。

    2026-10-20 实测三种包，都得认：
      A. 代码铺在本层：`AzurLaneAutoScript\\{alas.py, module\\, config\\, toolkit\\}`
      B. 启动器包：   `AzurLaneAutoScript\\{Alas.exe, deploy\\{alas.py, module\\}, config\\, toolkit\\}`
      C. 只有启动器、代码还没下载：`{Alas.exe, console.bat, deploy\\, toolkit\\, config\\}` ← **不算**
    判据 = 代码在本层或 `deploy\\`（有 `module\\`）+ 有入口 + 有工作目录特征（config / toolkit / campaign）。
    """
    code = has_code(path)
    entry = (path / "alas.py").exists() or (path / "deploy" / "alas.py").exists()
    workspace = any((path / name).is_dir() for name in ("config", "toolkit", "campaign"))
    return code and entry and workspace


def is_launcher_only(path: Path) -> bool:
    """这是 Alas 的**启动器目录，但代码还没下载**（用户最容易卡在这一步）。

    现场（2026-10-20）：目录里有 `Alas.exe` / `console.bat` / `deploy` / `toolkit`，
    但没有 `module` —— 说明他只装了启动器，`Alas.exe` 还没跑过（代码是它下载的）。
    """
    launcher = (path / "Alas.exe").exists() or (path / "console.bat").exists()
    return launcher and not has_code(path)


def diagnose_dir(path: Path) -> str:
    """选错目录时，尽量说清「你选的是哪一层、差什么」。"""
    if is_root(path):
        return ""
    if is_launcher_only(path):
        return "这是 Alas 的启动器，本体还没下载 —— 我来帮你自动下载"
    if path.name.lower() == "deploy":
        return "deploy 是 Alas 的部署脚本目录 —— 选它的上一层，或者直接选 AzurLaneAutoScript"
    return ("这里找不到 Alas —— 选到 AzurLaneAutoScript 那一层就行"
            "（选外一层我也会自己往下找）")


def event_folders(root: Path) -> set[str]:
    """本机 Alas 认得哪些活动（`campaign\\<目录>\\` 的名字，如 `event_20261009_cn`）。

    **这是判断"这版 Alas 缺了哪个活动"的唯一依据** —— 直接看目录，不信版本号。
    复刻的旧活动目录一直在，所以它会命中；只有**全新活动**才会缺。
    """
    try:
        return {p.name for p in (root / "campaign").iterdir() if p.is_dir()}
    except OSError:
        return set()


def version(root: Path) -> tuple[str, str, str]:
    """本机 Alas 是哪一版 → `(短 sha, "MM-DD", "YYYY-MM-DD")`；读不到 → 三个空串。

    **Alas 没有版本号，只有 commit** —— 它更新器页面上的"本地 / 上游仓库"两行就是两个 sha
    （`module/webui/app.py:802-809`）。所以我们也只能认 sha。

    两道来源，都是读文件（不跑 git、不打扰 Alas）：
      - `.git\\refs\\remotes\\origin\\master` → 现在这版
      - `.git\\logs\\HEAD` 末行 → 本机最后一次被更新是什么时候（用户看得懂的是这个）
    没有 `.git`（启动器还没下完代码 / 别人直接解压的包）→ 返回空，调用方别提示。
    """
    git = root / ".git"
    sha = ""
    for rel in ("refs/remotes/origin/master", "refs/heads/master", "ORIG_HEAD"):
        try:
            text = (git / rel).read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        found = re.search(r"[0-9a-f]{40}", text)
        if found:
            sha = found.group(0)[:7]
            break
    short = full = ""
    try:
        last = (git / "logs" / "HEAD").read_text(
            encoding="utf-8", errors="ignore").strip().splitlines()[-1]
        found = re.search(r" (\d{10}) [+-]\d{4}", last)
        if found:
            stamp = int(found.group(1))
            short = time.strftime("%m-%d", time.localtime(stamp))
            full = time.strftime("%Y-%m-%d", time.localtime(stamp))
    except (OSError, IndexError):
        pass
    return sha, short, full


def version_note(root: Path, broken: tuple[str, ...]) -> str:
    """一句"这版 Alas 有已知问题"；**没命中黑名单就返回空串**（默认永远沉默）。

    黑名单（`Update.alas.broken`）只在"真收到用户反馈、定位到某一版"时才加 ——
    所以它不是"我没测过"，而是"我已经知道它坏"。

    为什么只提示、不拦：Alas 自己会更新（开一次就更新，`deploy/installer.py:18`；
    凌晨 03:50 还会自己重启更新，`config/deploy.yaml:96`），我们拦不住也不该拦
    （AGENTS.md：不替 Alas 干活）。拦下来只会让用户啥也干不了。
    """
    sha, when, _full = version(root)
    if not sha or not broken:
        return ""
    if not any(sha.startswith(prefix.lower()) for prefix in broken):
        return ""
    date = f"{when} 更新的那版" if when else "这一版"
    return (f"你这台 Alas 是 {date}（{sha}），已知有问题 —— "
            "先在 Alas 里退回上一版，或者更一下助手")


def is_root_strict(path: Path) -> bool:
    """更紧的判据（代码就在本层）—— 只在两个候选打平时用来优先选它。"""
    return (path / "alas.py").exists() and (path / "module").is_dir()


def find_root_under(path: Path, depth: int = 2) -> Path | None:
    """在 `path` 自己、以及它往下 `depth` 层的子目录里找 Alas 工作目录。"""
    found = _search(path, depth, is_root)
    if found:
        # 同一次搜索里，`deploy` 和它的上一层都可能"像"根目录 —— 优先带 toolkit/config 的那层
        return found
    return _search(path, depth, is_root_strict)


def _search(path: Path, depth: int, test) -> Path | None:
    if test(path):
        return path
    if depth <= 0:
        return None
    try:
        children = [p for p in path.iterdir() if p.is_dir()]
    except OSError:
        return None
    for child in children[:64]:                     # 子目录太多的（比如整个盘）就别硬扫了
        if child.name.lower() in SCAN_SKIP:
            continue
        found = _search(child, depth - 1, test)
        if found:
            return found
    return None


class AlasMissing(AlasError):
    """**压根没找到 Alas** —— 只有这种才该给"去哪下载"的指引。"""


class AlasBox:
    def __init__(self, root: Path | None = None, launcher: Path | None = None) -> None:
        self.root = Path(root) if root else find_install()
        if self.root is None or not is_root(self.root):
            raise AlasMissing(missing_hint())
        self.launcher = Path(launcher) if launcher else (Path(__file__).resolve().parent / "_run_task.py")
        if not self.launcher.exists():
            raise AlasError(f"缺壳的启动脚本：{self.launcher}")
        self._proc: subprocess.Popen | None = None
        self._gui: subprocess.Popen | None = None

    # ---------- 路径 ----------
    @property
    def config_path(self) -> Path:
        return self.root / "config" / "alas.json"

    @property
    def python(self) -> Path:
        """用 Alas 自带的嵌入式 Python；没有才退回当前解释器。"""
        exe = self.root / "toolkit" / "python.exe"
        return exe if exe.exists() else Path(sys.executable)

    def log_file(self) -> Path:
        """引擎这次运行落盘的日志文件。

        **壳读日志走这里，不抓 stdout** —— 实测坑（2026-10-14）：
        抓 stdout 只拿到前 37 秒，之后 8 分钟的战斗阶段一个字都不给
        （Alas 把控制台交给了进度条），拿残缺日志判定三星会得出**假的"未达成"**。

        Alas 的日志文件名是 `log/<日期>_<入口脚本名>.txt`
        （`module/logger.py` 按 `sys.argv[0]` 的 stem 命名；
        实测还见过 `<日期>_-c.txt`，正是 `python -c` 起的那次 → 反证了这个规则）。
        我们的入口是 `_run_task.py`，所以文件名固定（所有任务当天都写进同一个文件，
        所以壳每次起进程前先记下字节位置，只读新追加的部分）。
        """
        return self.root / "log" / f"{time.strftime('%Y-%m-%d')}_{self.launcher.stem}.txt"

    # ---------- 配置 ----------
    def ensure_config(self) -> str:
        """缺 `config/alas.json` 就**用 Alas 自己的代码生成一份**，返回一句人话。

        为什么能自动（2026-10-20 查证）：`AzurLaneConfig.__init__` → `init_task()` → `load()` →
        `read_file()` 在文件不存在时返回 `{}`（`module/config/utils.py:69-96`），
        随后用 `args.json` 里的默认值算出完整配置并 `save()` 写盘（`module/config/config.py:110-123`）。

        所以**不需要用户先去开一次 Alas 的界面** —— 那正是他的抱怨：
        "如果这些配置都要用户自己手把手弄，那我直接去用 A 了"。
        """
        if self.config_path.exists():
            return ""
        proc = subprocess.run(
            [str(self.python), str(self.launcher), str(self.root), "--init"],
            cwd=str(self.root), capture_output=True, timeout=180, **no_console())
        if self.config_path.exists():
            return "✔ 已自动生成 Alas 的初始配置（不用你手动打开 Alas）"
        tail = (proc.stdout or b"").decode("utf-8", "ignore").strip().splitlines()[-3:]
        raise AlasError("自动生成 Alas 配置失败 —— 先手动打开一次 Alas，再点这里"
                        + ("\n     " + "\n     ".join(tail) if tail else ""))

    def read_config(self) -> dict:
        if not self.config_path.exists():
            raise AlasError(
                f"已找到 Alas（{self.root}），但它还没启动过一次 —— 缺 config\\alas.json。\n"
                "     先把 Alas 打开跑一次（它会自己生成配置），关掉，再点这里")
        return json.loads(self.config_path.read_text(encoding="utf-8"))

    def write_config(self, data: dict) -> Path:
        stamp = time.strftime("%Y%m%d-%H%M%S")
        backup = self.config_path.with_name(f"{self.config_path.name}.bak-{stamp}")
        shutil.copy2(self.config_path, backup)
        _prune_backups(self.config_path, KEEP_BACKUPS)
        self.config_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        return backup

    def stages(self) -> list[str]:
        """Alas 当前认得的关卡候选：**活动图 + 主线**，给「关卡」输入框用。

        **不写死** —— 都从 Alas 自己拿（`一键三星_需求记录.md` 的原则：MuMu 知道 + Alas 知道，
        我们就不猜）：读任务配置里的 `Campaign.Event` 当目录名，再扫 `campaign/<目录>/*.py`：
          活动 `Event.Campaign.Event = event_20250520_cn` → `A1…D3, SP`
          主线 `Main.Campaign.Event  = campaign_main`    → `1-1…14-4`
        换活动自动跟着变；某个任务扫空了就跳过它（扫空 = Alas 还不认识这个活动）。
        """
        try:
            data = self.read_config()
        except AlasError:
            return []
        out: list[str] = []
        for task in (TASK, MAIN_TASK):
            node = data.get(task)
            if isinstance(node, dict):
                out += _stages_in_folder(
                    self.root / "campaign" / str(node.get("Campaign", {}).get("Event", "")))
        return out

    def read_task_state(self, task: str) -> tuple[str, bool]:
        """读回某个任务（活动图 / 主线）现在的关卡与调度开关。

        Alas 打完一关会自己把配置改掉（`module/handler/fast_forward.py:438-448`）：
          有下一关 → `Campaign_Name` 改成下一关
          没下一关 → `Scheduler_Enable = False`
        壳靠这两个值判断"要不要接着推下一关" —— 不用解析任何日志语义。
        """
        node = self.read_config().get(task, {})
        name = str(node.get("Campaign", {}).get("Name", ""))
        enabled = bool(node.get("Scheduler", {}).get("Enable", False))
        return name, enabled

    def set_stage(self, stage: str, stage_increase: bool = False,
                  mode: str = MODE_3STARS, hard: bool = False) -> list[str]:
        """把这一关配成：打它 + 立即运行。返回「改了什么」。

        **两个 mode 只差"停在哪"**（都是 Alas 现成的字段，没有新概念）：
          `MODE_3STARS`：`MapAchievement = map_3_stars` + 关周回模式 → 达成三星就停
          `MODE_OIL`   ：`MapAchievement = non_stop` + 开周回模式 + 不推关
                         → **一直刷到油 < 500**（`run.py:95-100`）才停

        **按关卡名分流任务**（见 `task_for`）：`C1` / `SP` → 活动图 `Event`；
        `12-4` / `2-2` → 主线 `Main`。两套的判定 / 刹车 / 人话完全复用。

        `hard`：主线的「困难」版本和普通版本**同名**（`10-3` 两种都有），Alas 靠
        `Campaign.Mode` 区分（`alas.py:353-356`，所有入口都读它）。**必须每次都显式写** ——
        2026-10-17 实测：壳以前不写，用户配置里留着 `hard`，于是"打 10-3"实际一直在打**困难 10-3**。
        活动图没有这个分叉，一律写 `normal`。

        ⚠️ 别用日志里的 `Mode_switch_1 set to ?` 反推这一项：那个开关的**状态名和页面是反的**
        （`campaign_ui.py:119-148` —— 状态 `normal` 指的是"现在在困难页"）。
        对照关系：`normal` 只打一行 `Mode_switch_1 set to hard`（= 停在普通页）；
        `hard` 会打两行，最后一行是 `set to normal`（= 切到困难页），
        之后还会多一句 `Remaining number of times of hard mode...`（`campaign/run.py:422-429`）。

        「壳接管期间」的改动（原值都记进 park_state.json，供还原）：
          - 被接管任务的那几组配置（`_snapshot`，**必须在改动之前记**）
          - 关掉它的心情控制（`_ignore_emotion`）
          - 把其它任务顶到远期（`_park_others`）

        Args:
            stage_increase: 是否打开 Alas 的「达成关卡成就后向前开荒」。
                打开后 Alas 达成一关会把配置里的关卡推进到下一关（A1→A2→A3…），
                但**它只改配置**，接着跑下一关要靠壳在外面循环（见 app.py）。
                刷油模式忽略这一项 —— 刷油就是刷同一关，不推关。
        """
        stage = (stage or "").strip().upper()
        if not stage:
            raise AlasError("关卡不能为空（例如 D1 / C2 / 12-4）")
        if mode not in (MODE_3STARS, MODE_OIL):
            raise AlasError(f"不认的 mode：{mode}")

        task = task_for(stage)
        oil = mode == MODE_OIL
        data = self.read_config()
        if not isinstance(data.get(task), dict):
            raise AlasError(f"配置里没有「{task}」任务")

        node = data[task]
        state = _load_state()
        recorded = _snapshot(state, task, node)          # ← 必须在改动之前记原值

        # 只写这 7 个值；`MapAchievement` 由 mode 决定，不给用户改
        wanted: list[tuple[str, tuple[str, ...], object]] = [
            ("关卡名称", (task, "Campaign", "Name"), stage),
            # 困难图和普通图同名，靠这个值分（活动图没有分叉，一律 normal）
            ("关卡难度", (task, "Campaign", "Mode"),
             "hard" if (hard and task == MAIN_TASK) else "normal"),
            # 刷油开周回模式最快（也是 Alas 主线的默认值）；三星要全歼，得关掉让它自己清
            ("使用周回模式", (task, "Campaign", "UseClearMode"), oil),
            # 「自律寻敌」：脚本自己在图里找敌人、打完自动开下一局（`campaign_base.py:119-146`）
            # —— 这是 Alas 能做到"连续刷"的唯一开关（**它没有游戏里那个「连续作战」**，
            # 全仓 assets 只有 AUTO_SEARCH_*，没有连续作战按钮，2026-10-19 查证）。
            # **必须刷油时显式打开**：以前不写，用的是配置里的残留值，关着就退化成
            # "一趟趟进图"（日志里 `No auto search option.` = 这张图没这个开关，
            # 通常因为还没 100% 通关、周回没解锁，Alas 会自己退回手动跑图）。
            # 三星模式不写这一项（要不要自律寻敌会影响清图路径，保持用户/ Alas 默认）。
            *([("使用自律寻敌", (task, "Campaign", "UseAutoSearch"), True)] if oil else []),
            ("石油低于X后推迟", (task, "StopCondition", "OilLimit"), 0),
            ("达成成就后停止", (task, "StopCondition", "MapAchievement"), mode),
            ("达成成就后开荒", (task, "StopCondition", "StageIncrease"),
             bool(stage_increase) and not oil),
            ("下一次运行时间", (task, "Scheduler", "NextRun"), IMMEDIATE),
        ]
        notes: list[str] = [f"用「{task}」任务"]      # 关卡名自动分流，得让用户看见用的哪套
        for label, path, value in wanted:
            here = data
            for key in path[:-1]:
                here = here.setdefault(key, {})
            if here.get(path[-1]) != value:
                here[path[-1]] = value
                notes.append(label)
        # 确保这个任务在调度器里是"启用"的（单任务入口其实不看它，但保持配置自洽）
        node.setdefault("Scheduler", {})["Enable"] = True
        # 关掉心情控制 —— 否则打完一关会被"心情不够"推迟 6~12 分钟，推关走不到第二步
        if _ignore_emotion(node):
            notes.append("心情控制关掉")

        # 把别的任务顶到远期 —— 否则战役每趟结束就被科研/委托/收获赶走，推关走不到第二步。
        parked = _park_others(data, keep={task})
        if parked:
            notes.append("其它任务顶到远期")
        for other, old in parked.items():
            state["times"].setdefault(other, old)       # 只记第一次的原值
        if recorded or parked:
            _save_state(state)

        self.write_config(data)
        return notes

    def set_daily(self) -> list[str]:
        """把「清日常」那几个任务配成"立即运行"、其它任务顶到远期。返回「改了什么」。

        比 `set_stage` 简单得多：**只写 `Scheduler.NextRun` 一样东西** ——
        这几个任务都不打图，所以不碰心情控制、也不碰 `Campaign` / `StopCondition`，
        于是 `_snapshot` 那三块快照用不上，全部走已有的 `times` 机制（还原逻辑不用改）。

        它们由壳**一个一个**起（`run('<任务>')` 每次只跑一个任务，见 `_run_task.py`），
        所以这里不需要让 Alas 的调度器排队。
        """
        data = self.read_config()
        missing = [t for t, _ in DAILY_TASKS if not isinstance(data.get(t), dict)]
        if missing:
            raise AlasError(f"配置里没有这些任务：{'、'.join(missing)}")

        state = _load_state()
        changed = 0
        for task, _ in DAILY_TASKS:
            sched = data[task].setdefault("Scheduler", {})
            if sched.get("NextRun") != IMMEDIATE:
                old = sched.get("NextRun")
                if isinstance(old, str):
                    state["times"].setdefault(task, old)     # 只记第一次的原值
                sched["NextRun"] = IMMEDIATE
                changed += 1
        parked = _park_others(data, keep={t for t, _ in DAILY_TASKS})
        for other, old in parked.items():
            state["times"].setdefault(other, old)
        if changed or parked:
            _save_state(state)
            self.write_config(data)

        notes = [f"{len(DAILY_TASKS)} 个日常任务立即运行"]
        if parked:
            notes.append("其它任务顶到远期")
        return notes

    # ---------- 活动每日 ----------
    def pick_event(self) -> tuple[str, str]:
        """挑现在开着的活动 → `(文件夹名, "2026-09-08")`。

        **为什么必须壳来挑**：`Campaign.Event` 是用户在 Alas 界面里**手选**的，
        而我们的用户从不开 Alas 界面 —— 本机实测它还指着 `event_20250912_cn`（早就结束的活动），
        直接跑 `EventA` 会 `Event unavailable` 收场。

        判据只用 Alas 自己的东西：`campaign/event_YYYYMMDD_<服>/` 里，
        **日期最新、而且真有 a1/b1/c1/d1/sp 这类关卡文件**的那一个。
        （日期来自 Alas 自己的目录命名约定；`event_20240912_cn` 那种复刻也会被算进去，
        所以挑错的可能性是"最新那个不是正在开的" —— 日志里会说清楚打的是哪个活动。）
        """
        root = self.root / "campaign"
        candidates: list[tuple[str, str]] = []
        for folder in root.iterdir():
            match = EVENT_FOLDER.match(folder.name)
            if not match or not folder.is_dir():
                continue
            stages = {p.stem for p in folder.glob("*.py")}
            if not stages & {"a1", "b1", "c1", "d1", "sp"}:
                continue
            candidates.append((match.group(1), folder.name))
        if not candidates:
            raise AlasError("Alas 里一个活动文件夹都没有 —— 先把 Alas 更新到最新版")
        date, name = max(candidates)
        return name, f"{date[:4]}-{date[4:6]}-{date[6:]}"

    def set_event_daily(self, folder: str) -> list[str]:
        """把这 5 个任务指到当前活动、立即运行，其它任务顶到远期。返回「改了什么」。

        **这不是新功能，是 Alas 自带的「每日三倍」**：
          `EventA~D` → `module/event/campaign_abcd.py`：按 `EventDaily.StageFilter`
                       把该图每个小关**各打一趟**（`total=1`），断点续跑，跑完推迟到明天
          `EventSp`  → `module/event/campaign_sp.py`：SP 打一趟，同样推迟到明天
        壳只做两件事：把 `Campaign.Event` 指对 + 让它们立即运行。
        """
        data = self.read_config()
        missing = [t for t, _ in EVENT_DAILY if not isinstance(data.get(t), dict)]
        if missing:
            raise AlasError(f"配置里没有这些任务：{'、'.join(missing)}")

        state = _load_state()
        recorded = False
        for task, _ in EVENT_DAILY:
            node = data[task]
            recorded = _snapshot(state, task, node) or recorded      # 必须在改动之前记
            node.setdefault("Campaign", {})["Event"] = folder
            sched = node.setdefault("Scheduler", {})
            if sched.get("NextRun") != IMMEDIATE:
                if isinstance(sched.get("NextRun"), str):
                    state["times"].setdefault(task, sched["NextRun"])   # 只记第一次的原值
                sched["NextRun"] = IMMEDIATE
            sched["Enable"] = True
        parked = _park_others(data, keep={t for t, _ in EVENT_DAILY})
        for other, old in parked.items():
            state["times"].setdefault(other, old)
        if recorded or parked:
            _save_state(state)
        self.write_config(data)
        notes = [f"{len(EVENT_DAILY)} 个活动任务指向「{folder}」"]
        if parked:
            notes.append("其它任务顶到远期")
        return notes

    def set_emulator_serial(self, serial: str) -> str:
        """把 Alas 的 `Emulator.Serial` 对齐到壳选中的那台实例。返回一句人话。

        `Emulator` 挂在 `Alas` 那一组下（`config/alas.json` 第 2-4 行），**不属于任何具体任务**，
        所以它不在 `set_stage` 写的那 6 个值里，单独写一次。

        **不记快照、不参与还原** —— 它属于「环境对齐」（跟分辨率 / 保活 / 桥接一样），
        不是用户的配置偏好：序列号是**从当前实例算出来的**，把过期值还原回去
        只会让 Alas 的 GUI 也连不上（2026-10-15 想清楚的一点）。

        **为什么必须对齐**（2026-10-15 实测）：用户从 index 1 换到 index 0 之后，
        Alas 配置里还写着 `emulator-5556`（属于 index 1），而实际设备是 `emulator-5554`
        （属于 index 0）→ Alas `AdbError: device 'emulator-5556' not found` 重试 4 分钟
        → `Request human takeover` 退出。**用户看到的现象是"点了没反应"。**
        """
        data = self.read_config()
        node = data.get("Alas")
        if not isinstance(node, dict) or not isinstance(node.get("Emulator"), dict):
            return "没找到 Alas 的模拟器设置（可能装得不完整），先不动它"

        current = str(node["Emulator"].get("Serial", ""))
        if current == serial:
            return "模拟器已经对准了"
        node["Emulator"]["Serial"] = serial
        self.write_config(data)
        return "已把你正在玩的那台模拟器对准了"

    # ---------- 还原 ----------
    def parked_count(self) -> int:
        """壳改过多少处（被顶掉的任务 + 被接管过的任务），= 待还原的数量。"""
        state = _load_state()
        return len(state["times"]) + len(state["tasks"])

    def unpark_all(self) -> int:
        """**还原**：把壳改过的设置放回原值。返回还原了几处。

        「一键三星」会在每关开始前再改一次（不然推关会被打断）——
        所以「还原」的意义是：**你要去用 Alas 的调度器跑别的任务时，先把设置放回来**。

        两件事都要放回：
          1. 被顶到远期的那些任务时间（`times`）；
          2. 被接管任务的 `Campaign` / `StopCondition` / `Emotion` 三块（`tasks`）
             —— 主线尤其要紧：它默认是"无限刷图"，不还原就等于把用户的刷图配置改了。
        """
        state = _load_state()
        times: dict[str, str] = state["times"]
        tasks: dict[str, dict] = state["tasks"]
        if not times and not tasks:
            return 0
        data = self.read_config()
        restored = 0
        restored_times: list[str] = []
        for task, old in times.items():
            value = data.get(task)
            if not isinstance(value, dict):
                continue
            sched = value.get("Scheduler")
            if not isinstance(sched, dict):
                continue
            if _written_by_shell(sched.get("NextRun")):
                sched["NextRun"] = old
                restored += 1
                restored_times.append(task)
        for task, saved in list(tasks.items()):
            node = data.get(task)
            if not isinstance(node, dict):
                continue
            for group, block in saved.items():
                if node.get(group) != block:
                    node[group] = block
                    restored += 1
            if all(node.get(g) == b for g, b in saved.items()):
                tasks.pop(task, None)          # 这几块都放回去了，记录可以删
        if restored:
            self.write_config(data)
            # **只删掉真正还原掉的那几条** —— 原来直接 `_save_state({"times": {}})` 一把清空，
            # 那些"因为不像壳写的而没还原"的条目会连**原值**一起丢掉
            # （2026-10-15 真丢过一次：5 个任务的排期被冲成"立即运行"，还原又跳过它们）。
            for task in restored_times:
                times.pop(task, None)
            _save_state(state)
        return restored

    # ---------- 引擎（单任务入口）----------
    def start(self, task: str | None = None) -> subprocess.Popen:
        """起一次 Alas 的单任务入口。`task` 是 Alas 的任务组名（不给就默认 `Event`）。"""
        if self._proc is not None and self._proc.poll() is None:
            return self._proc
        argv = [str(self.python), str(self.launcher), str(self.root)]
        if task:
            argv.append(task)
        env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8")
        self._proc = subprocess.Popen(
            argv,
            cwd=str(self.root),
            env=env,
            # 壳不抓 stdout —— 改读 Alas 自己的日志文件（见 log_file()）。
            # 必须重定向到 DEVNULL：用 PIPE 却没人读，管道写满会把**子进程卡死**。
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            # 壳是 `pythonw` 起来的（没有控制台）→ 不给这个，引擎会**自己弹一个黑框**，
            # 而且它拉起的那层（adb server 之类）还会再弹
            **no_console(),
        )
        return self._proc

    def stop(self) -> None:
        proc = self._proc
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                proc.kill()
        self._proc = None

    def kill_stale(self) -> list[int]:
        """清理**上一轮残留**的引擎（窗口被强关、崩溃时留下的孤儿进程）。

        **只认命令行里带我们那个启动脚本名的 python 进程** —— 它只可能是壳自己起的，
        不会有误杀。2026-10-15 实测过这个坑：用户把窗口关了，Alas 还在后台自动打图 40 分钟，
        没人看着、也不知道它在干什么。
        """
        pids = find_pids(self.launcher.name)
        kill_pids(pids)
        return pids

    def gui_running(self) -> bool:
        """Alas 自己的设置界面（`gui.py`）现在开着吗？

        **为什么问**：两边别同时点「启动」—— 在 Alas 界面里点一下，会和壳抢同一个模拟器。
        壳只**提醒**、不替用户关掉它（那是越权，用户可能正在里面改设置）。
        """
        return bool(find_pids("gui.py"))

    def close_gui(self) -> bool:
        """关掉**我们自己**打开的那个设置页（连它起的 uvicorn 子进程一起）。

        为什么必须由我们关：用户点「打开 Alas 设置」时看到的是一个网页，
        背后那个 `python gui.py` 进程他根本看不见 —— 让他"关掉 Alas"是句废话
        （2026-10-23 用户指出）。更新前先把它收掉，就不必再劳烦用户。
        """
        proc, self._gui = self._gui, None
        if proc is None or proc.poll() is not None:
            return False
        try:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                           capture_output=True, timeout=10, **no_console())
        except (OSError, subprocess.SubprocessError):
            return False
        return True

    def running(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    # ---------- 逃生舱 ----------
    def webui_port(self) -> int:
        """Alas 设置页面的端口 —— 从 config/deploy.yaml 的 `WebuiPort` 读。"""
        path = self.root / "config" / "deploy.yaml"
        try:
            m = re.search(r"WebuiPort:\s*(\d+)", path.read_text(encoding="utf-8", errors="ignore"))
            if m:
                return int(m.group(1))
        except OSError:
            pass
        return DEFAULT_WEBUI_PORT

    def open_gui(self) -> str:
        """打开 Alas 的设置页面（`gui.py` = uvicorn + pywebio），返回它的网址。

        为什么不直接调 `deploy\\launcher\\Alas-gui.bat`：
          那个脚本用 `%~dp0` 推根目录 —— 它假设自己被放在**仓库根**，
          而它实际躺在 `deploy\\launcher\\` 下，直接调会把根目录算错。
        这里照它做的事自己做，**并跳过它的 updater**（用户只是想改设置，不该被强制更新）。
        """
        url = f"http://127.0.0.1:{self.webui_port()}"
        if self._gui is not None and self._gui.poll() is None:
            return url                                 # 已经开着，直接给网址

        env = dict(os.environ)
        toolkit = self.root / "toolkit"
        extra = [toolkit, toolkit / "Scripts", toolkit / "Git" / "mingw64" / "bin",
                 toolkit / "Lib" / "site-packages" / "adbutils" / "binaries"]
        env["PATH"] = os.pathsep.join([str(p) for p in extra] + [env.get("PATH", "")])
        self._gui = subprocess.Popen([str(self.python), "gui.py"], cwd=str(self.root), env=env,
                                     **no_console())
        return url
