﻿"""MuMu 碧蓝助手（壳）：把门打开 · 按住开始 · 说人话。

壳只做三件事：
  1. 把 MuMu 配到 Alas 能用的状态（环境对齐）—— 这是 MuMu 独有、Alas 拿不到的能力
  2. 写好「一键三星」的参数，用单任务入口起 Alas 引擎（绕开调度器）
  3. 把 Alas 的输出翻译成人话，并按 [Map_info] 判定是否真的「100%通关 + 三星」

壳**不解释 Alas，只翻译 Alas 的状态**；**不是配置中心**，永远不是。

设计依据见项目根的 `AGENTS.md` 与 `一键三星_需求记录.md`。
"""
from __future__ import annotations

__version__ = "0.2.8"        # 版本号就这一个地方，打包脚本和界面都读它
__all__ = ["alas_box", "alas_update", "app", "humanize", "mumu", "paths",
           "selfupdate", "update"]
