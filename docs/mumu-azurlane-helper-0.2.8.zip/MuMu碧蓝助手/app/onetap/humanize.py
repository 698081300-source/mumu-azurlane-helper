"""把 Alas 的输出翻译成人话 —— 壳的第二个职责（第一个是把门打开）。

设计原则：**壳不解释 Alas，只翻译它的状态。**
所以这里只认少量"值得告诉用户"的标记，其余一律丢掉 —— 用户不需要看到
`AdbBinary` / `atx-agent version` / `busybox nc` 那些开发者流水。
"""
from __future__ import annotations

import re

ANSI = re.compile(r"\x1b\[[0-9;]*m")

# 关卡名在日志里的形态（`CAMPAIGN_14_4` / `CAMPAIGN_C1` / `CAMPAIGN_SP1`）。
# **必须卡形态**：日志里还有 `Click (x, y) @ CAMPAIGN_MENU_GOTO_CAMPAIGN` 这种**资产名**，
# 贪心匹配会打印"开始跑关卡 MENU"；而这条正则同时喂着下面的「精准命中」校验，
# 还会**误报"跑错关卡"**（2026-10-15 用户实测撞到）。lookbehind 排除 `PAGE_xxx` 那种前缀。
CAMPAIGN_PATTERN = r"(?<![A-Za-z0-9_])CAMPAIGN_(\d+_\d+|[A-D][1-9]|SP\d*)"

# 按顺序匹配，第一条命中就收工。(正则, 人话)
RULES: tuple[tuple[str, str], ...] = (
    # ---- 关键节点 ----
    (r"<<< ENTER MAP CANCEL >>>", "已完成 → 推进到下一关"),
    (r"<<< ENTER MAP >>>", "进图了，开始清图"),
    (r"<<< CAMPAIGN END >>>", "这一趟打完了"),
    (r"<<< SCRIPT END >>>", "本关收尾"),
    (r"<<< CLEAR ENEMY >>>", "正在清小怪"),
    (r"<<< CLEAR BOSS >>>", "正在打 BOSS"),
    (r"<<< MAP INIT >>>", "读取地图"),
    (r"<<< FIND CURRENT FLEET >>>", "找自己的舰队"),
    (r"<<< APP LOGIN >>>", "等游戏登录"),
    (r"<<< APP RESTART >>>", "重启游戏（上一趟卡住了）"),
    # ---- 开局体检查到的 ----
    # Alas 每趟进图前 OCR 一次油（实测 33 次/天，约每趟 1~2 次，不会刷屏）：
    #   2026-10-14 22:38:28 | INFO | [OCR_OIL 0.039s] 20743
    # 心情值报不了 —— 坑之三关掉心情控制后 Alas 就不再打 `[Emotion fleet_N]` 了
    # （实测最后一条停在写成 ignore 的那一刻），见 一键三星_需求记录.md 坑之三。
    (r"\[OCR_OIL[^\]]*\]\s*(\d+)", "石油 {0}"),
    # ---- 值得警告的 ----
    (r"TRIGGERED STOP CONDITION: OIL LIMIT|Triggered stop condition: Oil limit",
     "石油不够 → 任务被推迟。先把石油补到 500 以上再来"),
    (r"(?i)triggered stop condition", "这一趟按设定停下来了（比如打满趟数 / 等级达标）"),
    (r"GameStuckError|Wait too long",
     "⚠️ 游戏卡住了 —— 可能弹了个确定/取消在等你，看一眼游戏画面"),
    (r"GameNotRunningError", "游戏没在运行 —— 先把碧蓝打开，再点一次"),
    # 「自律寻敌」开关在有些图上根本不存在（那张图还没 100% 通关、周回没解锁），
    # Alas 于是退回手动跑图 —— 用户看到的现象就是"一趟趟进图、比游戏里慢"。
    # 2026-10-14 的日志里这句出现几十次，但一直没人翻译它（2026-10-19 补）。
    # ⚠️ 文案必须**中性**：三星模式也会打出这句（那时它本来就该手动跑图）。
    #    第一版写成"先用『一键三星』打成三星"，用户正在用一键三星时看到就成了废话
    #    （2026-10-19 用户报）。"先三星→刷油才连续"这条建议挪去了刷油的开场提示（app.py）。
    # 「困难图每天次数用完」——Alas 把任务推迟到明天（`campaign/run.py:422-429`）。
    # 这**不是失败**：星星是累计的，明天再点一次会接着补（2026-10-19 用户实测 4-4 困难卡在 17/18）。
    (r"Remaining number of times of hard mode .* is 0, delay task to next day",
     "困难图今天的次数用完了 → Alas 把任务推迟到明天（明天再点一次，会接着补星星）"),
    # 仓库满了要退役，但游戏里的「快速退役」设置挑不到任何船（2026-10-21 用户实测 7-4）
    # Alas 会连抛两行：CRITICAL 让你去改设置 + `No ship retired`。**两条都翻成同一句**，
    # 免得用户看到英文、或者同一件事被说两遍（界面层还会去掉重复句）。
    (r"No ship retired|Quick Retire Options",
     "⚠️ 船坞满了，游戏里的「快速退役」设置选不中任何船 —— 去游戏里改一下退役设置，"
     "或者手动清一次船坞"),
    # 关卡名在 Alas 里不存在（2026-10-20 实测：用户填 11-7，而主线每章只有 4 关）
    # 主线要能把 campaign_11_7 还原成用户输入的 11-7；活动图没有这个规律，退化成通用说法
    (r"Map file not found: .*?campaign_(\d+)_(\d+)\s*$",
     "⚠️ Alas 里没有「{0}-{1}」这一关 —— 主线每章只有 4 关，检查一下关卡号"),
    (r"Map file not found: .*?(campaign_\w+)\s*$",
     "⚠️ Alas 里没有这关的数据（{0}）—— 检查一下关卡号，或者 Alas 还没更新到这个活动"),
    # `No auto search option.` **故意不翻译**（2026-10-21 用户定）：它只是"这趟没有加速档、
    # 照常手动跑"的说明，不影响能不能打 —— 显示出来只会给用户增加无效的阅读压力。
    # 连不上模拟器这类事以前是**完全静音**的（日志里只有 AdbError/Retry），
    # 用户看到的就成了"点了没反应" —— 2026-10-15 实测：序列号对不上时它会连 4 分钟。
    (r"AdbError: device '([^']+)' not found",
     "⚠️ 连不上模拟器（adb 里找不到它）—— 多半是模拟器刚重启过："
     "重新打开碧蓝助手，或者重启一次 MuMu 再试"),
    (r"(?i)no such device exists", "⚠️ 连不上模拟器：可能是没开，或者它的 adb 端口变了"),
    (r"Failed to start emulator after 3 trial",
     "⚠️ 模拟器一直没连上（试了 4 次）—— 先把 MuMu 打开"),
    (r'No emulator with serial "([^"]+)" found',
     "⚠️ 找不到这个模拟器地址（{0}）—— 多半是模拟器刚重启过，重新打开助手让它重读"),
    (r"[Rr]equest ?[Hh]uman ?[Tt]akeover",
     "⚠️ Alas 处理不了这个情况，先停下了 —— 上面那条就是原因"),
    # `<<< UI GOTO PAGE_CAMPAIGN_MENU >>>` 里也带 `CAMPAIGN_`，会被下面那条误吃成
    # "开始跑关卡 MENU" —— 先把它吞掉（返回空串 = 这行不值得说）。
    (r"<<< UI GOTO ", ""),
    # ---- 结果 ----
    (r"Stage (\S+) increases to (\S+)", "「{0}」搞定 → 自动进入「{1}」"),
    (r"Stage (\S+) cannot increase", "「{0}」已是最后一关"),
    (CAMPAIGN_PATTERN, "开始跑关卡 {0}"),
    (r"Reach condition:\s*map_3_stars", "🎉 达成「100%通关 + 三星」，这一关搞定了"),
    (r"Reach condition:\s*(\S+)", "达成停止条件（{0}）"),
    (r"\[Map_info\]\s*(\d+)%", "地图进度 {0}%"),
)


def clean(line: str) -> str:
    return ANSI.sub("", line).rstrip()


def translate(line: str) -> str | None:
    """一行 Alas 输出 → 一句人话；不值得说的返回 None。"""
    text = clean(line)
    if not text:
        return None
    for pattern, human in RULES:
        m = re.search(pattern, text)
        if m:
            return human.format(*m.groups()) if "{" in human else human
    return None


MAP_INFO = re.compile(r"\[Map_info\]\s*(\d+)%\s*,?\s*(.*)$")
REACH = re.compile(r"Reach condition:\s*(\S+)")
CAMPAIGN = re.compile(CAMPAIGN_PATTERN)
CAMPAIGN_END = re.compile(r"<<< CAMPAIGN END >>>")
COMBAT = re.compile(r"<<< CLEAR (?:ENEMY|BOSS) >>>")   # 这一趟真的打过架（清小怪 / 打 BOSS）
# Alas 中途"转去处理别的任务"时会打这一行（例如见到委托完成提示就 force_call Commission，
# 见 `module/campaign/run.py:355-366`）。我们从日志里认它，好把那个任务真的跑掉。
TASK_CALL = re.compile(r"Task call: (\w+)")
EVENT_DELAY = re.compile(r"Delay task `Event` to ([\d\-]+ [\d:]+)")
OIL_STOP = re.compile(r"Triggered stop condition: Oil limit")
RUN_STOP = re.compile(r"Triggered stop condition: Run count")
# 困难图次数用完（`campaign/run.py:422-429`）→ 不是失败，是"今天的额度没了"
HARD_LIMIT = re.compile(r"Remaining number of times of hard mode .* is 0")
# Alas 说"要人介入"时，**真正的原因**在它前一行 CRITICAL/ERROR 里
# （2026-10-20 实测：壳只翻了"Alas 放弃了"，用户和我都不知道为什么放弃）
TAKEOVER = re.compile(r"[Rr]equest ?[Hh]uman ?[Tt]akeover")
REASON = re.compile(r"\|\s*(?:CRITICAL|ERROR)\s*\|\s*(.+)")
# 船坞满了：Alas 的退役流程挑不到任何船，于是整趟放弃（2026-10-21 实机 7-4）
DOCK_FULL = re.compile(r"No ship retired|Quick Retire Options")
# Alas 自己崩了（2026-10-21 实测：截到一帧黑屏 → 地图识别失败 → 它异常处理里又抛 TypeError → 进程退出）
CRASH = re.compile(r"Traceback \(most recent call last\)")


def campaign_started(text: str) -> str | None:
    """Alas 实际开始跑的关卡（日志里的 `CAMPAIGN_xxx` 头）。用来核对"是否精准命中"。"""
    m = CAMPAIGN.search(text)
    return m.group(1) if m else None


def same_stage(left: str, right: str) -> bool:
    """把 `12_4` 和 `12-4`、`a1` 和 `A1` 看作同一关（去掉非字母数字后比）。"""
    norm = lambda s: re.sub(r"[^A-Za-z0-9]", "", s or "").upper()  # noqa: E731
    return bool(norm(left)) and norm(left) == norm(right)


def map_info_lines(text: str) -> list[tuple[int, str]]:
    """取出所有 [Map_info] 行 → [(百分比, 标记串)]，按出现顺序。

    Alas 那行的格式（`module/handler/fast_forward.py:205-216`）是**只列真值为真的项**：
        [Map_info] 99%, star_1, star_2, star_3, 100_percent_clear, 3_stars, clear_mode
    第一位是 `int(map_clear_percentage * 100)`；一个都没达成时就是 `0%,`。
    **必须逐行解析** —— Alas 的日志会把长行折成多行，用 `\\s*` 之类的通配会把下一行吃进来。
    """
    out: list[tuple[int, str]] = []
    for line in text.splitlines():
        if "[Map_info]" not in line:
            continue
        m = MAP_INFO.search(line)
        if m:
            out.append((int(m.group(1)), m.group(2)))
    return out


def stars_verdict(text: str) -> str | None:
    """判定「这一关到底三星了没」—— 壳对用户的承诺：**只有 100%通关 + 三星才算数**。

    判据首选 Alas 自己抛的那行（`module/map/map_operation.py:169-172`）：
        if self.triggered_map_stop():            # ← 只在 100%通关 and 三星 时为真
            raise ScriptEnd(f'Reach condition: {StopCondition_MapAchievement}')
    所以出现 `Reach condition: map_3_stars` = 真·达成，无歧义。

    没出现就用最后一次 [Map_info] 报进度（每次出击前都会重读，所以它是"最后看到的状态"）。
    """
    reached = [m.group(1) for m in REACH.finditer(text)]
    rows = map_info_lines(text)

    if "map_3_stars" in reached:
        detail = f"（地图 {rows[-1][0]}%）" if rows else ""
        return f"✅ 已达成「100%通关 + 三星」{detail}"

    if not rows:
        return None

    pct, flags = rows[-1]
    full = "100_percent_clear" in flags
    three = "3_stars" in flags

    # 「击破护卫舰队 n/N」是**跨趟累计**的星，第 3 颗星（击破所有敌舰）拿到之后，
    # Alas 就不再清全图（`fast_forward.py:199-201` 的 MAP_CLEAR_ALL_THIS_TIME），
    # 于是这颗星只能靠多跑几趟慢慢累加 —— 要说清"缺的是哪颗、怎么办"。
    if "star_3" in flags and "star_2" not in flags:
        return (f"⚠️ 还差一颗「累积星」：地图 {pct}% —— 缺的是「击破护卫舰队」，"
                "多跑几趟会自己累加（Alas 拿到第 3 颗星后只打最少的怪，不会再清全图）")

    if three:      # star_1/2/3 全亮 = 已经是三星，再说"未达成"就自相矛盾了
        return f"✅ 这张图已经是三星状态（地图 {pct}%）"

    if CAMPAIGN_END.search(text):
        # 一趟打完（CAMPAIGN END）却没有 Reach condition：
        # Alas 只在**下一次进图**时看星数、推关（`map_operation.py:167-172`），
        # 这一步没走到 = 关卡不会前进。理由直接说日志里能看到的那件事，不猜。
        delay = EVENT_DELAY.search(text)
        if delay:
            return (f"⚠️ 这一趟打完了，但 Alas 没有确认通关："
                    f"它把任务推迟到了 {delay.group(1)}（地图 {pct}%）")
        return (f"⚠️ 这一趟打完了，但 Alas 没有推进关卡（地图 {pct}%）："
                "可能无法自动通关，建议手动通关后再试")

    return (f"⚠️ 未达成：地图 {pct}%"
            f"（{'已' if full else '还没'}100%通关，{'已' if three else '还没'}三星）")


def oil_verdict(text: str) -> str:
    """「刷光石油」这一趟的结论（= `stars_verdict` 的刷油版）。

    刷油用的是 `MapAchievement = non_stop`：Alas 不因关卡成就停
    （`fast_forward.py:447-469` 的四个判断全不命中），
    唯一的刹车是油量（`module/campaign/run.py:95-100`）：

        if self.get_oil() < max(500, self.config.StopCondition_OilLimit):
            logger.hr('Triggered stop condition: Oil limit')
            self.config.task_delay(minute=(120, 240))

    所以「刷完了」= 日志里出现这一行。
    """
    if OIL_STOP.search(text):
        return ("✅ 刷完了：石油已不足 500（Alas 的门槛），它把任务推迟了 2~4 小时 —— "
                "补油后再点一次就行")
    if RUN_STOP.search(text):
        return "✅ 刷完了：达到设定的出击次数"
    return "⚠️ 没刷到低油就停了 —— 可能被打断或出错了，把这条日志发给开发者看看"
