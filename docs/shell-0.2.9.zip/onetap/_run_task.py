"""在 Alas 的嵌入式 Python 里跑：**只执行一个任务**，绕开调度器。

这个脚本放在**壳自己的目录**里，不属于 Alas —— 壳只调用 Alas 的公开入口，
不改它一行代码（见 AGENTS.md）。

用法：`_run_task.py <Alas根目录> [任务组名]`（默认 `Event`）

为什么不用 `python alas.py`：
那个入口是 `if __name__ == '__main__': AzurLaneAutoScript().loop()`
—— `loop()` 会进调度器，而调度器里「委托 / 科研 / 收获」是**写死强制开启**、
用户关不掉的（`module/config/i18n/zh-CN.json:321`），点一下得先等它们几十秒到几分钟。
`run('<任务>')` 直接 `getattr` 调方法（`alas.py:65-70`），**根本不查队列**，
而且**一次只跑一个任务**（"打完一趟又起一趟"是 `CampaignRun.run()` 内部自己的循环，
不在这里）。

顺带一个白捡的好处：单任务模式下没有调度器去接 `task_call('Restart')`，
所以它卡住时**不会自己乱重启游戏** —— 控制权回到壳手里，壳才能给人话报错。
"""
from __future__ import annotations

import os
import re
import sys


def method_name(task: str) -> str:
    """Alas 的任务组名 → 方法名：`ShopFrequent` → `shop_frequent`。"""
    return re.sub(r"(?<!^)(?=[A-Z])", "_", task).lower()


def main() -> int:
    if len(sys.argv) < 2:
        print("用法: _run_task.py <Alas 根目录> [任务组名]", file=sys.stderr)
        return 2

    root = os.path.abspath(sys.argv[1])
    task = sys.argv[2] if len(sys.argv) > 2 else "Event"
    os.chdir(root)                    # Alas 内部大量相对路径（config/ assets/ log/）
    sys.path.insert(0, root)
    # 有的整合包把 `alas.py` 放在 `deploy\` 这一层（2026-10-20 实测）——
    # 加进去只是让 import 找得到它，**不改 Alas 一个字节**。
    # ⚠️ 必须"本层没有才用 deploy 的"：`deploy\alas.py` 在正常安装里也存在，
    # 但那是部署脚本、没有 `AzurLaneAutoScript` 类 —— 无脑插到最前面会让 import 抢错文件。
    deploy = os.path.join(root, "deploy")
    if not os.path.isfile(os.path.join(root, "alas.py")) \
            and os.path.isfile(os.path.join(deploy, "alas.py")):
        sys.path.insert(0, deploy)

    from module.config.config import name_to_function
    from alas import AzurLaneAutoScript

    if "--init" in sys.argv:
        # 只生成配置文件（壳会用到）：Alas 自己的 `AzurLaneConfig` 在 `config/alas.json`
        # 不存在时会用默认值算出完整配置，但 `save()` 在"没有改动"时**什么都不写**
        # （`module/config/config.py:263-265`），所以这里显式落盘一份。
        # 等价于"它第一次启动"，但不开界面、不连模拟器。
        cfg = AzurLaneAutoScript().config
        target = os.path.join(root, "config", "alas.json")
        if not os.path.isfile(target):
            cfg.write_file(cfg.config_name, cfg.data)
        print("OK: config ready")
        return 0

    alas = AzurLaneAutoScript()

    # ⚠️ 必须先把这个任务绑到 config 上。
    # `run('event')` 内部用的是 `self.config.Campaign_Name`，而 config 默认只绑 `Alas`
    # （module/config/config.py:115-117），不绑 Event 就会落到全局默认值 ——
    # 实测：没绑时它拿着默认的 `12-4` / `campaign_main` / `non_stop`
    # 跑去打**主线 12-4**，用户填的 A1 完全没生效。
    # 调度器里也是这么做的（alas.py:497-500）：`config.task = task; config.bind(task)`。
    # `name_to_function` 是个通用工厂（`module/config/config.py:46-57`，不查表），
    # 所以换成「收获 / 委托 / 科研…」走的是同一条路。
    function = name_to_function(task)
    alas.config.task = function
    alas.config.bind(function)

    alas.run(method_name(task))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
