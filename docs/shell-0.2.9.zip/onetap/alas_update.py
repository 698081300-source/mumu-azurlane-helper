"""给 Alas 换代码（方案二）：**只换代码，不碰 pip / adb / 配置**。

用户点的那个「现在更新」按钮，背后只有三件事：

  1. `git fetch` —— 把新版下到 `.git` 里（**不改工作区**，所以可以先偷偷做）
  2. 检查工作区有没有他手改过的文件（**有就不动手**，否则 `reset --hard` 会抹掉）
  3. `git reset --hard origin/<branch>` —— 纯本地换页；失败滚回旧版本

为什么不打开 Alas 界面或 `Alas.exe`：
  - 一打开就等于开了它自己的更新闹钟（`module/webui/app.py:1451-1453` 注册了
    `check_update` 每 5 分钟、`schedule_update` 每天 03:50），还得再关；
  - `Alas.exe` 那套还会顺带替换模拟器的 adb（`deploy/Windows/installer.py`），
    会把 MuMu 的 adb 改名备份 —— 我们**不能碰**。

为什么不自己装 python 库：这次只需要换代码；`pip_install` 慢且容易失败，
`_internal` 那种事一次都不该在这个按钮里发生。

⚠️ 我们的**任务在跑的时候绝不能调用它** —— 换着文件跑，等于跑到一半换发动机。
调用方（`app.py`）保证只在"开跑之前"用它。
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import time
from pathlib import Path

from onetap.mumu import SAFE_CWD, no_console

FETCH_TIMEOUT_S = 180        # 联网拉包：国内可能很慢，给足 3 分钟
RESET_TIMEOUT_S = 120         # 换页：纯本地，但文件多，别卡在 30 秒
CMD_TIMEOUT_S = 30
DEFAULT_BRANCH = "master"


# ---------------- 找 git / 读它的配置 ----------------
def _conf(root: Path, key: str, default: str = "") -> str:
    """从 `config/deploy.yaml` 读一个值（只读，不写）。

    只用它的两个字段：`GitExecutable`（用哪个 git）和 `Branch`（跟哪条分支）。
    **不用它的 `Repository`** —— 远端地址以用户仓库里实际配置的 `origin` 为准，
    免得我们猜错（用户可能自己换过镜像）。
    """
    try:
        text = (root / "config" / "deploy.yaml").read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return default
    found = re.search(rf"^\s*{key}:\s*(\S[^\r\n]*?)\s*$", text, re.M)
    if not found:
        return default
    value = found.group(1).strip().strip("\"'")
    return default if value.lower() in ("", "null", "none") else value


def find_git(root: Path) -> Path | None:
    """找 Alas 自带的 `git.exe`（找不到才退回系统 PATH 里的）。"""
    raw = _conf(root, "GitExecutable")
    if raw:
        path = Path(raw.replace("\\", "/"))
        path = path if path.is_absolute() else (root / path)
        if path.exists():
            return path
    for rel in ("toolkit/Git/mingw64/bin/git.exe", "toolkit/git/bin/git.exe"):
        path = root / rel
        if path.exists():
            return path
    found = shutil.which("git")
    return Path(found) if found else None


def _run(git: Path, root: Path, *args: str, timeout: int = CMD_TIMEOUT_S):
    """跑一条 git 命令。

    `GIT_TERMINAL_PROMPT=0` 必须给：没有它就可能在"要账号密码"那里**无声挂住**，
    用户看到的是"点了没反应"（和之前 adb 那个坑是同一类）。
    """
    env = dict(os.environ)
    env["GIT_TERMINAL_PROMPT"] = "0"
    env.pop("GIT_ASKPASS", None)
    return subprocess.run([str(git), "-C", str(root), *args],
                          capture_output=True, timeout=timeout,
                          cwd=SAFE_CWD, env=env, **no_console())


def _text(proc) -> str:
    return (proc.stdout or b"").decode("utf-8", "ignore").strip()


def _head(git: Path, root: Path) -> str:
    try:
        return _text(_run(git, root, "rev-parse", "HEAD"))
    except (OSError, subprocess.SubprocessError):
        return ""


def _remote_head(git: Path, root: Path, branch: str) -> str:
    try:
        return _text(_run(git, root, "rev-parse", f"origin/{branch}"))
    except (OSError, subprocess.SubprocessError):
        return ""


def dirty(git: Path, root: Path) -> list[str]:
    """**被跟踪文件**的改动（`reset --hard` 会抹掉的那些）。

    只认前两列不是 `??` 的行 —— `??` 是未跟踪文件（我们自己的 `alas.json.bak-*`、
    包自带的 `deploy/Termux/`），`reset --hard` **不会删**，所以不算"脏"。
    """
    try:
        out = _text(_run(git, root, "status", "--porcelain"))
    except (OSError, subprocess.SubprocessError):
        return []
    return [line for line in out.splitlines() if line and not line.startswith("??")]


def gui_busy() -> bool:
    """Alas 自己的界面开着吗？开着就先别换代码（它可能正在更新，会互相踩）。"""
    from onetap.alas_box import find_pids
    return bool(find_pids("gui.py"))


# ---------------- 两步：先备货，再换页 ----------------
def prepare(root: Path) -> bool:
    """**只**把新版下到 `.git` 里，不动工作区 —— 开窗时偷偷做，失败无感。

    这一步是方案二里"点了几乎不会失败"的原因：联网的活提前干完，
    用户点的时候只剩本地换页。
    """
    root = Path(root)
    git = find_git(root)
    if git is None:
        return False
    branch = _conf(root, "Branch") or DEFAULT_BRANCH
    try:
        proc = _run(git, root, "fetch", "origin", branch, timeout=FETCH_TIMEOUT_S)
    except (OSError, subprocess.SubprocessError):
        return False
    return proc.returncode == 0


def update(root: Path, say=lambda _msg: None) -> tuple[bool, str]:
    """把 Alas 换到最新版。返回 `(成功?, 给用户的一句话)`。

    五道保险（顺序就是执行顺序）：
      1. 没 git → 不动手
      2. 连不上 → 不动手（此刻文件一个都没变）
      3. 工作区脏 → 不动手（否则抹掉用户手改的东西）
      4. 换页失败 / 换完版本号不对 → **滚回旧版本**
      5. 有事说事，不抛异常（调用方是 UI 线程里的 worker）
    """
    root = Path(root)
    git = find_git(root)
    if git is None:
        # 用户看不懂"git"是什么，所以这里**只说下一步怎么做**（2026-10-23 用户定）。
        return False, ("更新失败 —— 点「打开 Alas 设置」，在里面点「更新」，"
                       "更新完把助手关掉重开一次就行")
    branch = _conf(root, "Branch") or DEFAULT_BRANCH

    if gui_busy():
        # 正常用壳时不会走到这里：只有用户自己双击过 Alas 才可能。
        # 他既然能开，就能看到那个窗口 —— 所以直接点名"那个窗口"。
        return False, "Alas 的设置窗口还开着 —— 把那个窗口关掉（右上角 ✕），再点一次就好"

    say("· 正在问 Alas 的更新服务器…")
    try:
        fetched = _run(git, root, "fetch", "origin", branch, timeout=FETCH_TIMEOUT_S)
    except (OSError, subprocess.SubprocessError):
        fetched = None
    if fetched is None or fetched.returncode != 0:
        return False, ("更新失败 —— 连不上 Alas 的更新服务器，过会儿再点一次；"
                       "或者点「打开 Alas 设置」，在里面点「更新」")
    old = _head(git, root)
    new = _remote_head(git, root, branch)
    if not old or not new:
        return False, "更新失败 —— 读不到 Alas 的版本号，过会儿再点一次"
    if old == new:
        return True, "已经是最新的了"

    changed = dirty(git, root)
    if changed:
        # 用户不知道"工作区脏"是什么，只说**按哪个按钮**（2026-10-23 用户定）。
        return False, ("Alas 里有被改过的文件，直接更新会把它们抹掉 —— "
                       "先点「还原 Alas 初始配置」，再点左上角那句提醒更新就好")

    say("· 正在换上新版本…")
    try:
        proc = _run(git, root, "reset", "--hard", f"origin/{branch}", timeout=RESET_TIMEOUT_S)
    except (OSError, subprocess.SubprocessError):
        proc = None
    now = _head(git, root) if proc is not None else ""

    if proc is None or proc.returncode != 0 or now != new:
        _rollback(git, root, old)
        return False, "更新失败（已经退回原来的版本），过会儿再点一次"

    return True, "更新好了"


def _rollback(git: Path, root: Path, old: str) -> None:
    """滚回旧版本。旧文件本机都在，所以这一步是秒级的 —— 绝不留半新半旧。"""
    if not old:
        return
    for _ in range(2):
        try:
            if _run(git, root, "reset", "--hard", old,
                    timeout=RESET_TIMEOUT_S).returncode == 0:
                return
        except (OSError, subprocess.SubprocessError):
            pass
        time.sleep(0.5)


def version_of(root: Path) -> str:
    """当前版本号（短 sha），给日志和排错用。"""
    git = find_git(Path(root))
    if git is None:
        return ""
    return _head(git, Path(root))[:7]
