"""把下好的新版本换上去 —— 以及**换坏了怎么退回来**。

结构（见 `一键三星_需求记录.md` 的「1 万人怎么同步更新」）：
    MuMu碧蓝助手\\
        MuMu碧蓝助手.exe      ← 入口，几乎不变
        _internal\\            ← Python 运行时 / 依赖，很少变
        app\\onetap\\          ← **会变的代码，本文件换的就是这个目录**
每次修 bug 只发 `app/onetap` 打成的那几百 KB，用户不用下 60 MB。

为什么在**启动那一刻**换（而不是运行中）：
  - 换目录时壳的代码正在被自己用着，Windows 上改名能过、但进程里仍是旧代码 —— 换了也得重启；
  - 启动时没人用、没有后台任务在跑，是唯一干净的时机。
所以流程是：**开窗 → 有下好的新版 → 换目录 → 重新拉起自己 → 本进程退出**。

三道保险：
  1. `pending-update.json` 记下"换过、还没证明起得来"；新版本跑了两次都没活到窗口起来 → 退回旧版
  2. 换坏的那版记进 `blocked.json`，`update.check` 不再推给这台机器
  3. 换目录失败（文件被占用等）当场把旧目录改回来，不留半成品
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

from onetap import __version__, paths, update
from onetap.mumu import no_console     # 重新拉起自己时也不要黑框

MARKER = "pending-update.json"      # %APPDATA%\MuMu碧蓝助手\ 下
BLOCKED = "blocked.json"
PACKAGE_NAME = "onetap"             # app\ 下这个目录就是代码包
KEEP_OLDS = 1                       # 旧目录留几份（留 1 份 = 回滚要用）


# ---------------- 路径 ----------------
def live_dir() -> Path:
    """现在**正在跑**的代码目录（源码运行时是仓库里的 `onetap/`）。"""
    return paths.PACKAGE


def app_dir() -> Path:
    """`app\\` —— 代码目录的上一层（进 `sys.path` 的就是它）。"""
    return live_dir().parent


# ---------------- 安装包（staging）----------------
def stage(zip_path: Path, version: str) -> Path:
    """把下好的 zip 解到 `staging\\<版本>\\`，校验通过才算"下好"。

    校验三件事：路径不出 staging（防 zip 里写 `..\\..\\`）、根目录是 `onetap/`、有 `__init__.py`。
    """
    staging = paths.staging_dir()
    final = staging / version
    tmp = staging / f"{version}.tmp"
    for path in (tmp, final):
        if path.exists():
            shutil.rmtree(path, ignore_errors=True)
    try:
        with zipfile.ZipFile(zip_path) as zf:
            root = tmp.resolve()
            for name in zf.namelist():
                if not str((tmp / name).resolve()).startswith(str(root)):
                    raise update.UpdateError("包里有非法路径，拒绝安装")
            zf.extractall(tmp)
    except (OSError, zipfile.BadZipFile) as exc:
        shutil.rmtree(tmp, ignore_errors=True)
        raise update.UpdateError(f"包解不开：{exc}") from exc
    if not (tmp / PACKAGE_NAME / "__init__.py").exists():
        shutil.rmtree(tmp, ignore_errors=True)
        raise update.UpdateError("包里没有 onetap/，不是代码包")
    (tmp / "VERSION").write_text(version, encoding="utf-8")
    tmp.rename(final)
    zip_path.unlink(missing_ok=True)
    return final


def pending_package() -> tuple[str, Path] | None:
    """staging 里已经下好、而且比现在新的那一个 → `(版本, 目录)`。"""
    best: tuple[tuple[int, ...], str, Path] | None = None
    for path in paths.staging_dir().iterdir():
        if not path.is_dir() or path.name.endswith(".tmp"):
            continue
        version = path.name
        if not update.newer(version, __version__):
            continue
        if not (path / PACKAGE_NAME / "__init__.py").exists():
            continue
        key = tuple(int(x) for x in version.split(".") if x.isdigit())
        if best is None or key > best[0]:
            best = (key, version, path)
    return (best[1], best[2]) if best else None


# ---------------- 换 / 退 ----------------
def install(version: str) -> bool:
    """把 staging 里的那个版本换上去（旧目录改名留着，供回滚）。"""
    staged = paths.staging_dir() / version
    if not (staged / PACKAGE_NAME / "__init__.py").exists():
        return False
    live = live_dir()
    old = live.parent / f"{PACKAGE_NAME}.old-{__version__}"
    if old.exists():
        shutil.rmtree(old, ignore_errors=True)
    _write_marker({"from": __version__, "to": version, "tried": False})
    try:
        live.rename(old)                       # 先挪走（此时文件句柄已关，Windows 允许改名）
        shutil.move(str(staged / PACKAGE_NAME), str(live))
    except OSError:
        if not live.exists() and old.exists():
            old.rename(live)                   # 换失败当场还原，不留半成品
        _write_marker(None)
        return False
    shutil.rmtree(staged, ignore_errors=True)
    _prune_olds(live.parent)
    return True


def rollback(frm: str, bad: str) -> bool:
    """退回 `frm` 那版，并把 `bad` 记进黑名单（不再推给这台机器）。"""
    live = live_dir()
    old = live.parent / f"{PACKAGE_NAME}.old-{frm}"
    if not old.exists():
        return False
    try:
        live.rename(live.parent / f"{PACKAGE_NAME}.bad-{bad}")
        old.rename(live)
    except OSError:
        return False
    shutil.rmtree(paths.staging_dir() / bad, ignore_errors=True)
    _block(bad)
    return True


def blocked() -> set[str]:
    """换坏了、已经退回来的版本（这台机器不要再推）。"""
    try:
        data = json.loads((paths.data_dir() / BLOCKED).read_text(encoding="utf-8"))
        return {str(x) for x in data} if isinstance(data, list) else set()
    except (OSError, json.JSONDecodeError):
        return set()


# ---------------- 启动时的三步 ----------------
def bootstrap() -> bool:
    """开窗前调用。返回 `True` = **已经换了版本并重新拉起自己，本进程直接退出**。

    三步：先看上次换的版本起没起来（没起来就退回）→ 有下好的新版就换 → 都没有就正常开窗。
    """
    marker = _read_marker()
    if marker:
        if str(marker.get("to")) != __version__:
            _write_marker(None)                     # 已经不是那个版本了，标记作废
        elif marker.get("tried"):
            # 上一趟就是它、却没活到"窗口起来了" → 判定为坏版本，退回
            if rollback(str(marker.get("from") or ""), __version__):
                _write_marker(None)
                if relaunch():
                    return True
                # 起不来就**照常开窗**（旧版至少能用），别让用户对着空气等
            _write_marker(None)
        else:
            marker["tried"] = True
            _write_marker(marker)
    found = pending_package()
    if found:
        version = found[0]
        if install(version) and relaunch():
            return True
    return False


def mark_healthy() -> None:
    """窗口起来了才算"这次更新成功"。**必须由界面在真起来之后调用** ——
    它是回滚判据：没走到这里，下次启动就把新版本换回去。"""
    _write_marker(None)


def relaunch() -> bool:
    """重新拉起自己（打包后 = 同一个 exe；源码运行 = `pythonw -m onetap`）。**返回起没起来。**

    调用方要在**真起来之后**才关旧窗口 —— 否则起不来 + 旧窗口已关 = 用户以为工具崩了。
    """
    try:
        if getattr(sys, "frozen", False):
            subprocess.Popen([sys.executable], **no_console())
        else:
            subprocess.Popen([sys.executable, "-m", "onetap"],
                             cwd=str(app_dir()), **no_console())
    except OSError:
        return False
    return True


# ---------------- 小工具 ----------------
def _marker_path() -> Path:
    return paths.data_dir() / MARKER


def _read_marker() -> dict | None:
    try:
        data = json.loads(_marker_path().read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def _write_marker(data: dict | None) -> None:
    path = _marker_path()
    if data is None:
        path.unlink(missing_ok=True)
        return
    try:
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def _block(version: str) -> None:
    versions = blocked()
    versions.add(version)
    try:
        (paths.data_dir() / BLOCKED).write_text(
            json.dumps(sorted(versions), ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def _prune_olds(app: Path) -> None:
    """旧目录只留最近几份（一份就够回滚，多了白占磁盘）。"""
    olds = sorted(app.glob(f"{PACKAGE_NAME}.old-*"))
    for old in olds[:-KEEP_OLDS] if KEEP_OLDS else olds:
        shutil.rmtree(old, ignore_errors=True)
    for bad in app.glob(f"{PACKAGE_NAME}.bad-*"):
        shutil.rmtree(bad, ignore_errors=True)
