"""入口：python -m onetap"""
from __future__ import annotations

from onetap.app import main

if __name__ == "__main__":
    main()
