"""MuMu 侧：找安装、列实例、读改设置、拉起实例。

这一层是壳唯一**独占**的能力。
Alas 只能读 `adb devices` **猜**该连哪台（而且那张表会被历史连接污染、还可能不含真实实例）；
MuMu 自己知道真相（`MuMuManager info -v all` → 哪台 start_finished、adb_port 是多少）。
壳的价值就是把"MuMu 知道的"喂给"Alas 要猜的"。
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

# 起外部命令时**必须**给个工作目录（2026-10-21 用户实测）：
# 子进程会继承我们的 cwd，而 `adb` 的 server 是**常驻守护进程** ——
# 它一旦把 cwd 落在安装目录里，用户关了窗口也删不掉那个文件夹（"文件夹正在使用"，只能重启）。
# 这里统一给系统临时目录，谁也别站在用户的安装目录里。
SAFE_CWD = tempfile.gettempdir()

from onetap import paths

# Alas 硬要求 1280x720；MuMu 的分辨率预设档（本机实测 tablet.1=1600x900，tablet.2=1280x720）
RES_MODE_720P = "tablet.2"
# 上次真正用它跑过的那台实例 —— 没开模拟器时优先开它（多台机器上"编号最小"往往是错的）
LAST_INDEX = paths.data_dir() / "last-index.txt"


def saved_index() -> int | None:
    try:
        return int(LAST_INDEX.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def save_index(index: int) -> None:
    try:
        LAST_INDEX.write_text(str(index), encoding="utf-8")
    except OSError:
        pass


# 碧蓝的包名（本机 Alas 配置 `Emulator.PackageName` 写的就是这个）。
# 换了渠道包这里会对不上 —— 那样只会"问不出来"，退回挑最小号那台，不会做错事。
GAME_PACKAGE = "com.bilibili.azurlane"

ROOT_CANDIDATES = (
    Path(r"E:\mumu\MuMuPlayer"),
    Path(r"D:\mumu\MuMuPlayer"),
    Path(r"C:\Program Files\Netease\MuMuPlayer-12.0"),
    Path(r"D:\Program Files\Netease\MuMuPlayer-12.0"),
)

# 壳自己（`pythonw`）**没有控制台**，不给标志的话，它起的每个子进程
# Windows 都会**单开一个黑框**（MuMuManager / adb / powershell / Alas 引擎）——
# 用户实测："一直疯狂弹黑色的程序框"。
def no_console() -> dict:
    """起子进程时把它 `**` 进 kwargs —— 保证用户**一个黑框都看不到**。

    手法照抄 adbutils（`adbutils/_utils.py:44-63`，作者注释写着
    "Stops executable from flashing on Windows"）：给子进程一个**隐藏的控制台**。

    ⚠️ 别改成 `creationflags=CREATE_NO_WINDOW`（2026-10-15 实测纠错）：
    那个标志让子进程**完全没有控制台**，于是**它的**子进程又会各开一个新的黑框 ——
    MuMuManager 拉起的工具、`adb.exe` 顺带起的 server 守护进程都算，
    而壳根本管不到那一层。给了隐藏控制台，**整棵进程树都继承它**，一层都漏不出来。
    """
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = subprocess.SW_HIDE
    return {"startupinfo": si}


class MuMuError(RuntimeError):
    """MuMu 侧的可预期错误（找不到安装、没有实例…），直接拿给用户看。"""


def find_root() -> Path | None:
    env = os.environ.get("MUMU_ROOT")
    if env and (Path(env) / "nx_main" / "MuMuManager.exe").exists():
        return Path(env)
    for root in ROOT_CANDIDATES:
        if (root / "nx_main" / "MuMuManager.exe").exists():
            return root
    return _from_registry()


def _from_registry() -> Path | None:
    """从注册表（卸载信息）里找 MuMu —— 用户装在自己挑的目录时，上面那串候选全落空。

    这对"给完全没用过的人用"是硬要求（2026-10-19）：别人的 MuMu 不会正好装在
    `E:\\mumu\\MuMuPlayer`。MuMu 会给自己的卸载项登记 `DisplayName` / `InstallLocation`，
    顺着 `InstallLocation` 往下找一两层就能摸到 `nx_main\\MuMuManager.exe`。
    """
    try:
        import winreg
    except ImportError:          # 非 Windows / 被裁剪的解释器
        return None
    uninstall = (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                 r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall")
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        for sub in uninstall:
            try:
                with winreg.OpenKey(hive, sub) as key:
                    total = winreg.QueryInfoKey(key)[0]
                    for i in range(total):
                        found = _probe_entry(key, winreg.EnumKey(key, i))
                        if found:
                            return found
            except OSError:
                continue
    return None


def _probe_entry(key, name: str) -> Path | None:
    """看一条卸载项是不是 MuMu；是就把它的安装根目录（含 nx_main 的那层）摸出来。"""
    import winreg
    try:
        with winreg.OpenKey(key, name) as item:
            display = str(winreg.QueryValueEx(item, "DisplayName")[0] or "")
            if "mumu" not in display.lower():
                return None
            location = str(winreg.QueryValueEx(item, "InstallLocation")[0] or "")
    except OSError:
        return None
    if not location:
        return None
    base = Path(location)
    for depth in ("", "*/", "*/*/"):
        for hit in base.glob(f"{depth}nx_main/MuMuManager.exe"):
            return hit.parent.parent
    return None


class MuMu:
    def __init__(self, root: Path | None = None) -> None:
        self.root = Path(root) if root else find_root()
        if self.root is None:
            raise MuMuError("没找到 MuMu —— 先把 MuMu 模拟器装好再点这里")
        nx = self.root / "nx_main"
        self.manager = nx / "MuMuManager.exe"
        self.adb = nx / "adb.exe"
        if not self.adb.exists():               # 有的版本 adb 不在这里，退回系统里的
            found = shutil.which("adb")
            if found:
                self.adb = Path(found)
        if not self.manager.exists():
            raise MuMuError("MuMu 装得不太对（少了 MuMuManager.exe），建议重装一次 MuMu")

    # ---------- 底层 ----------
    def _run(self, *args: str, timeout: int = 60) -> str:
        proc = subprocess.run([str(self.manager), *(*args,)], capture_output=True, timeout=timeout,
                              cwd=SAFE_CWD, **no_console())
        return proc.stdout.decode("utf-8", "ignore")

    @staticmethod
    def _json(text: str) -> dict:
        start = text.find("{")
        if start < 0:
            return {}
        try:
            data = json.loads(text[start:])
        except json.JSONDecodeError:
            return {}
        return data if isinstance(data, dict) else {}

    # ---------- 查询 ----------
    def instances(self) -> list[dict]:
        """所有实例（含没启动的）。"""
        data = self._json(self._run("info", "-v", "all"))
        return [i for i in data.values() if isinstance(i, dict)]

    def running(self) -> list[dict]:
        """真正在跑的实例 —— 这是 MuMu 的权威答案（判据见 `_inst_running`）。"""
        return [i for i in self.instances() if self._inst_running(i)]

    def pick_index(self) -> int | None:
        """挑一台在跑的实例：**哪台在跑碧蓝就挑哪台**，都没看到就跑得最靠前的那台。

        2026-10-15 实测：MuMu 里同时跑着 index 0 / 1 两台时，原来固定挑最小号 ——
        但用户可能在另一台上玩。「哪台在跑碧蓝」MuMu + adb 一问就知道
        （`pidof`），又一处「MuMu 知道、Alas 靠猜」。
        """
        run = self.running()
        if not run:
            return None
        run.sort(key=lambda i: int(i["index"]))
        for inst in run:
            index = int(inst["index"])
            if self.game_running(index):
                return index
        return int(run[0]["index"])

    def settings(self, index: int) -> dict[str, str]:
        data = self._json(self._run("setting", "-v", str(index), "--all_writable"))
        return {k: v for k, v in data.items() if isinstance(v, (str, int, float))}

    def adb_devices(self) -> list[str]:
        """adb 里**真正可用**的设备（`offline` / `unauthorized` 的不算）。"""
        try:
            proc = subprocess.run([str(self.adb), "devices"], capture_output=True, timeout=30,
                                  cwd=SAFE_CWD, **no_console())
        except (OSError, subprocess.TimeoutExpired):
            return []
        out = proc.stdout.decode("utf-8", "ignore")
        devices = []
        for line in out.splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 2 and parts[1] == "device":
                devices.append(parts[0])
        return devices

    def _connect(self, serial: str) -> None:
        """让 MuMu 自带的 adb 连上这台（幂等；Alas 拿到 `host:port` 也会自己连）。"""
        try:
            subprocess.run([str(self.adb), "connect", serial],
                           capture_output=True, timeout=30, cwd=SAFE_CWD, **no_console())
        except (OSError, subprocess.TimeoutExpired):
            pass

    def _pidof(self, serial: str, package: str) -> bool:
        try:
            proc = subprocess.run([str(self.adb), "-s", serial, "shell", "pidof", package],
                                  capture_output=True, timeout=30, cwd=SAFE_CWD, **no_console())
        except (OSError, subprocess.TimeoutExpired):
            return False
        return bool(proc.stdout.decode("utf-8", "ignore").strip())

    def _adb(self, *args: str) -> str:
        """跑一条 MuMu 自带 adb 的命令，返回 stdout（失败就当空串）。"""
        try:
            proc = subprocess.run([str(self.adb), *args], capture_output=True, timeout=30,
                                  cwd=SAFE_CWD, **no_console())
        except (OSError, subprocess.TimeoutExpired):
            return ""
        return proc.stdout.decode("utf-8", "ignore")

    def ensure_adb(self, serial: str, wait_s: float = 20.0) -> tuple[bool, str]:
        """开跑前确认这个模拟器地址真连得上，能修的就修。返回 `(行不行, 一句人话)`。

        **为什么要这一步**（2026-10-15 实测）：Alas 连不上模拟器时会空转 **4 分钟**
        然后 `Request human takeover` 退出 —— 用户看到的就是"点了没反应"。

        能修的三步（都在 MuMu 自带的 adb 上做，幂等）：
          1. `adb devices` 里已经有 → 直接过
          2. 没有 → `adb connect`
          3. 还不行 → `adb kill-server` 后重连（adb server 假死是常见毛病）

        ⚠️ 2026-10-20 新机实测：原来"连三次、每次之间不等"，模拟器刚起来时 adb 端口还没监听，
        三次全落空就直接判死。现在**每一轮都等**（默认 20 秒），杀 server 后也给它 2 秒重启；
        失败时把 `adb devices` 实际看到的东西打出来 —— 没有这个，用户和我们都只能瞎猜。
        """
        if serial in self.adb_devices():
            return True, ""

        def wait_until(deadline: float) -> bool:
            while time.time() < deadline:
                if serial in self.adb_devices():
                    return True
                time.sleep(2)
            return serial in self.adb_devices()

        self._connect(serial)
        if wait_until(time.time() + wait_s):
            return True, "模拟器的连接修好了"

        self._adb("kill-server")
        time.sleep(2)                      # 给 adb server 重启留点时间，别立刻又查
        self._connect(serial)
        if wait_until(time.time() + wait_s):
            return True, "模拟器连接卡住了，重启了一下 adb 就好了"

        seen = "、".join(self.adb_devices()) or "一台都没有"
        return False, (f"连不上模拟器 {serial}（重启 adb 后还是连不上）。\n"
                       f"     现在 adb 只看到：{seen}\n"
                       "     → 先确认模拟器还开着；还不行就重启一次模拟器（它的 adb 端口可能变了）")

    def serial_for(self, index: int) -> str | None:
        """这台实例该让 Alas 连哪个 adb 地址 —— **用 MuMu 权威表里的 `host:port`**。

        `MuMuManager info -v all` 每台都带 `adb_host_ip` + `adb_port`
        （本机实测：index 0 → `127.0.0.1:16384`、index 1 → `127.0.0.1:16416`），
        这是唯一权威的地址 —— **别自己按 `emulator-5554 + 2 × index` 推**：
        2026-10-15 实测 index 1 算出来是 `emulator-5556`，而它**根本不在 adb 表里**
        （得先 `adb connect` 才有对应设备），Alas 拿着它连了 4 分钟才放弃。

        Alas 对 `host:port` 形式的序列号会自己 `adb connect`（对 `emulator-*` 只是跳过连接），
        所以给 `host:port` 最省事。这里顺手先连一次，让后面的探测能用上。
        拿不到 `adb_port` 就返回 None —— 宁可说"认不出"，也不写一个错地址进去。
        """
        for inst in self.instances():
            if str(inst.get("index")) != str(index):
                continue
            host = str(inst.get("adb_host_ip") or "127.0.0.1")
            port = inst.get("adb_port")
            if not port:
                return None
            serial = f"{host}:{port}"
            if serial not in self.adb_devices():
                self._connect(serial)
            return serial
        return None

    def game_running(self, index: int, package: str = GAME_PACKAGE) -> bool:
        """这台实例里碧蓝在跑吗？

        **只问这一台**（用 `serial_for` 给的权威地址），不问别的设备 ——
        否则会把"另一台在跑"误判成"这台在跑"，把壳指到错的实例上。
        问不出来（换了渠道包、连不上）就当"没有"，退回挑最小号那台：
        **宁可挑老样子，也不要挑错台。**
        """
        serial = self.serial_for(index)
        if serial is None:
            return False
        return self._pidof(serial, package)

    # ---------- 改动 ----------
    def set_settings(self, index: int, values: dict[str, str]) -> None:
        args = ["setting", "-v", str(index)]
        for key, val in values.items():
            args += ["-k", key, "-val", str(val)]
        self._run(*args)

    def align_env(self, index: int) -> list[str]:
        """把 Alas 硬要求的环境配到位，返回「我替你改了什么」（人话列表）。

        **分辨率不在这里改**：配置项改了要重启实例才生效，只写配置反而制造"看起来对了"的假象
        （2026-10-20 实测踩到）。分辨率统一走 `ensure_resolution()`，按真实画面判断。
        """
        want = {
            "app_keptlive": "false",           # 关「后台挂机时保活运行」
            "net_bridge_open": "false",        # 关「网络桥接」
        }
        current = self.settings(index)
        todo = {k: v for k, v in want.items() if str(current.get(k, "")).lower() != str(v).lower()}
        if not todo:
            return []
        self.set_settings(index, todo)
        notes: list[str] = []
        if "app_keptlive" in todo:
            notes.append("关掉「后台挂机时保活运行」")
        if "net_bridge_open" in todo:
            notes.append("关掉「网络桥接」")
        return notes

    def screen_size(self, serial: str) -> str:
        """**运行中的实例**真实分辨率，形如 `1280x720`（问 adb，不听配置）。

        ⚠️ `wm size` 报的是**自然方向**：1280×720 的横屏会报成 `720x1280`。
        所以比较时一律用 `is_720p()`（按长短边），别拿字符串直接等号 ——
        2026-10-20 就是因为这个误判，把用户**已经手动改对**的分辨率又关掉重开、还改回了 1080p。
        """
        out = self._adb("-s", serial, "shell", "wm", "size")
        for line in out.splitlines():
            if ":" in line:
                return line.split(":", 1)[1].strip()
        return ""

    @staticmethod
    def is_720p(size: str) -> bool:
        """`1280x720` 和 `720x1280` 都是"720p"（横竖屏同一个分辨率）。"""
        try:
            w, h = (int(x) for x in size.lower().split("x"))
        except (ValueError, AttributeError):
            return False
        return sorted((w, h)) == [720, 1280]


    @staticmethod
    def _inst_running(inst: dict) -> bool:
        """这台实例"启动完成"了吗。

        ⚠️ 不能只看 `player_state == 'start_finished'`（2026-10-20 实机2 卡在这）：
        MuMu 的 `info` 里还有一个更硬的字段 `is_android_started` —— 安卓已经起来了、
        只是 `player_state` 的取值在不同版本里不一样。两个认一个就算起来了。
        """
        if inst.get("is_android_started"):
            return True
        return str(inst.get("player_state") or "") == "start_finished"

    def _instance(self, index: int) -> dict | None:
        for inst in self.instances():
            if str(inst.get("index")) == str(index):
                return inst
        return None

    def _state(self, index: int) -> str:
        """这台实例现在什么状态（给日志看的）。"""
        inst = self._instance(index)
        if inst is None:
            return "未知"
        if self._inst_running(inst):
            return str(inst.get("player_state") or "已启动")
        return "未启动"

