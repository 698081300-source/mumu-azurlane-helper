"""MuMu 碧蓝助手（壳）的小窗。

职责就三件：**把门打开**（配 MuMu）· **按住开始**（写参数 + 起引擎）· **说人话**（翻译输出 + 报结果）。
界面只有一个按钮 + 一个逃生舱 + 一行状态；不做配置中心。

线程模型：界面在主线程，干活在 worker 线程，人话日志经 queue 回传，界面用 after 轮询取。
"""
from __future__ import annotations

import ctypes
import datetime
import json
import math
import os
import platform
import queue
import re
import subprocess
import sys
import threading
import time
import tkinter as tk
import webbrowser
import zipfile
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from onetap import __version__, alas_update, paths, selfupdate, update
from onetap.alas_box import (DAILY_TASKS, EVENT_DAILY, MAIN_TASK, MODE_3STARS, MODE_OIL,
                             AlasBox, AlasError, AlasMissing, diagnose_dir, discover_install,
                             discover_launcher, event_folders, find_install, find_pids,
                             find_root_under, has_code, is_launcher_only, rotate_fleets,
                             remember_install, task_for, version, version_note)
from onetap.humanize import (CAMPAIGN_END, COMBAT, CRASH, DOCK_FULL, HARD_LIMIT,
                             MAP_INFO, OIL_STOP, REACH, RUN_STOP, TASK_CALL,
                             campaign_started, clean, oil_verdict, same_stage,
                             stars_verdict, translate)
from onetap.mumu import MuMu, MuMuError, SAFE_CWD, no_console, save_index

PACKAGE = Path(__file__).resolve().parent
POLL_MS = 120
BOOT_TIMEOUT_S = 180
MAX_ROUNDS = 30          # 「打完自动下一关」最多连推几关（防无限跑）
TAIL_INTERVAL = 0.3      # 跟读 Alas 日志文件的间隔（秒）
MODE_DAILY = "daily"     # 壳自己的第三类动作：清日常（不是 Alas 的 MapAchievement 取值）
MODE_EVENT = "event"     # 第四类动作：活动每日（A/B/C/D/SP 各打一次，也是壳自己的动作名）
# 第五类动作：轮换刷油（2026-10-27 用户定）—— 每 ROTATE_RUNS 趟打完后自动换一组编队，
# 零浪费（Alas 在"一趟回港"时自己停，不是我们杀进程）。心情归用户自己看。
MODE_ROTATE = "rotate"
ROTATE_RUNS = 10         # 一批刷几趟就换队（2026-10-28 用户定：10 趟约掉 100 点心情，
                         # 刚好在 40 之前换手；再大第一队就直接见底了）
# 换队后第一次的"静默判死"阈值（秒）。为什么要短：游戏里没有第 3、4 队时会卡在
# 编队界面，用户看到的是"挂着不动"—— 等到 10 分钟他会以为工具坏了（2026-10-28 用户提）。
# 90 秒足够走完"起引擎 8 秒 + 检测界面 5 秒 + 进图 10 秒"，再慢就是真卡了。
ROTATE_SILENT_S = 90
MAX_OIL_ROUNDS = 200     # 轮换最多跑几批（纯保险，正常会先被"油光"停掉）
# 按钮名（只给提示文案用：用户点的是哪个，话里就说哪个，别一律写"一键三星"）
MODE_LABELS = {MODE_3STARS: "一键三星", MODE_OIL: "刷光石油",
               MODE_DAILY: "清日常", MODE_EVENT: "活动每日",
               MODE_ROTATE: "轮换刷油"}

# 构建时间（打包时由 tools/build_green.py 写进 onetap/_build.py；源码运行时没有）
try:
    from onetap._build import STAMP as BUILD_STAMP
except ImportError:
    BUILD_STAMP = ""


def build_stamp_text() -> str:
    """`2026-10-20 23:07` → `2026.10.20 23:07`（源码运行时是空串）。"""
    return BUILD_STAMP.replace("-", ".") if BUILD_STAMP else ""


# ---------------- 活动缺失（方案二）----------------
def missing_event_options(root: Path) -> dict[str, str]:
    """线上表里"正在开的新活动" 减去 本机 Alas 已有的目录 → `{活动目录名: 活动名}`。

    **复刻的旧活动不会出现在这里**（它的目录一直在），所以这是"要不要更新 Alas"的
    唯一触发点。线上表没写 `events` → 返回空 → 什么都不提醒。

    2026-10-23 改：原来拿"显示文字"当键、要塞进关卡下拉让用户选；用户否掉了那个做法
    （下拉是选关卡的，不是贴通知的），所以键改成目录名，界面自己决定怎么说。
    """
    try:
        have = event_folders(root)
    except OSError:
        return {}
    return {item["id"]: item["name"] for item in update.events() if item["id"] not in have}


def stale_alas_note(root: Path) -> str:
    """兜底那句「你的 Alas 有点旧」——**线上表没写 `alas.latest` 就永远不说**。

    它不依赖"缺哪个活动"，所以就算我们忘了维护活动清单、或者游戏临时开活动，
    只要 Alas 太久没更新，这句话也能兜住。7 天最多说一次（见 `_hint_due`）。
    """
    latest = update.alas_latest()
    if not latest:
        return ""
    _sha, _short, last = version(root)
    if not last:
        return ""
    try:
        days = (datetime.date.fromisoformat(latest)
                - datetime.date.fromisoformat(last)).days
    except ValueError:
        return ""
    if days < 30 or not _hint_due():
        return ""
    return (f"你的 Alas 是 {last} 那版（{days} 天没更新了），新活动可能刷不了 —— "
            "左上角那句提醒可以更新它")


def _hint_due() -> bool:
    """7 天冷却：同一台机器别天天念同一句。"""
    path = paths.data_dir() / "event-hint.json"
    today = datetime.date.today()
    last = None
    try:
        raw = json.loads(path.read_text(encoding="utf-8")).get("date", "")
        last = datetime.date.fromisoformat(str(raw))
    except (OSError, ValueError, TypeError, AttributeError):
        last = None
    if last is not None and (today - last).days < 7:
        return False
    try:
        path.write_text(json.dumps({"date": today.isoformat()}), encoding="utf-8")
    except OSError:
        pass
    return True


def _blend(left: str, right: str, t: float) -> str:
    """两个 `#rrggbb` 按 `t`（0..1）插值 —— 渐变动画用（见 `App._pulse`）。"""
    t = max(0.0, min(1.0, t))
    a = tuple(int(left[i:i + 2], 16) for i in (1, 3, 5))
    b = tuple(int(right[i:i + 2], 16) for i in (1, 3, 5))
    return "#%02x%02x%02x" % tuple(round(x + (y - x) * t) for x, y in zip(a, b))


AUTO_UPDATE_STATE = paths.data_dir() / "alas-autoupdate.json"
# 「轮换刷油」只问一次：确认游戏里有第 3、4 队。存在 = 问过了，以后不再问。
ROTATE_MARK = paths.data_dir() / "rotate-ok.txt"


def _rotate_ready() -> bool:
    """用户是不是已经确认过"我配好第 3、4 队了"。"""
    try:
        return ROTATE_MARK.exists()
    except OSError:
        return False


def _rotate_remember() -> None:
    try:
        ROTATE_MARK.write_text("ok", encoding="utf-8")
    except OSError:
        pass


def _rotate_forget() -> None:
    """换队失败 → 作废"已确认有第 3、4 队"。

    不删的话，头铁玩家会在**每 20 趟**都被打断一次、白等 90 秒（2026-10-28 用户指出）。
    删掉之后，下次点「轮换刷油」会重新问一遍 —— 他可以选择「否」，就不会再来一次。
    """
    try:
        ROTATE_MARK.unlink(missing_ok=True)
    except OSError:
        pass


def _auto_cooling() -> str:
    """自动更新 Alas 失败后的冷却里？返回上次的失败原因（空串 = 可以试）。

    为什么要有冷却：自动更新失败的原因多半不会马上变（Alas 正开着、工作区有改动、
    网断了）。没有冷却的话，用户每开一次窗就重试一次、每开一次就弹一次提醒 —— 纯骚扰。
    """
    try:
        data = json.loads(AUTO_UPDATE_STATE.read_text(encoding="utf-8"))
        last = datetime.datetime.fromisoformat(str(data.get("fail_at") or ""))
    except (OSError, ValueError, TypeError):
        return ""
    if (datetime.datetime.now() - last).total_seconds() < 6 * 3600:
        return str(data.get("why") or "上次没成功")
    return ""


def _auto_remember(why: str = "") -> None:
    """记下自动更新的结果：`why` 非空 = 失败（进冷却），空 = 成功（清掉冷却）。"""
    payload = ({"fail_at": datetime.datetime.now().isoformat(timespec="seconds"), "why": why}
               if why else {"fail_at": ""})
    try:
        AUTO_UPDATE_STATE.write_text(
            json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8")
    except OSError:
        pass


def _fleet_label(one: int, two: int) -> str:
    """`(1, 2)` → `1-2 队`；二队是 0（不用二队）时只说 `1 队`。"""
    return f"{one}-{two} 队" if two else f"{one} 队"


DAILY_TIMEOUT_S = 300    # 清日常里单个任务最多跑多久（秒），超了就停掉、跳过
DAILY_FIRST_TIMEOUT_S = 600   # 第一个任务放宽（要登录、开游戏，实测比后面几个慢）
EVENT_TIMEOUT_S = 1800   # 活动每个图最多跑多久：一个进程里要把该图所有小关各打一趟
DUMP_LIMIT = 2_000_000   # 原始日志最多留这么多字符，见 _dump_raw()
FEED_LINES = 20000       # 内存里最多攒这么多行日志（挂机几小时也不至于吃掉几百 MB）
STUCK_SILENT_S = 600     # 多久没有任何"人话"输出就判定卡住（秒），见 stuck_reason()
# 卡住之后**分原因**（2026-10-28 用户定）：能修的（模拟器掉线 / 游戏卡死）就重试一次；
# 修不好的（编队是空的）直接退回 1-2 队并告诉用户，别让他干等。
ADB_BAD = re.compile(r"AdbError|device offline|AdbTimeout")
GAME_STUCK = re.compile(r"GameStuckError|Wait too long|GameTooManyClickError")
# 进图的标志。**换队后只等这个信号**（2026-10-28 用户实测）：
# 正常刷一局，两次「石油 XXXX」之间能隔 2~3 分钟，用"任何日志都没动静"判死会误杀。
ENTER_MAP = re.compile(r"<<< ENTER MAP >>>")
STUCK_WHITE_RUNS = 2     # 连跑几趟"白跑"（一趟架都没打成）→ 判定打不完，见 stuck_reason()
MAX_RUNS_3STARS = 4      # 三星模式最多刷几趟同一关（星星计数是跨趟累计的），见 stuck_reason()


def stuck_reason(white_runs: int, reached: bool, idle_s: float,
                 allow_runs: bool = True, runs: int = 0,
                 run_limit: int = 0, silent_s: int = STUCK_SILENT_S) -> tuple[str, str]:
    """刹车判据：这一趟是不是已经跑废了？返回 `(类型, 理由)`。

    类型：`''` 没卡住 / `'white'` 连跑几趟白跑 / `'runs'` 刷到趟数上限 / `'silent'` 假死。
    三个判据都**直读日志**，不做推测：
      - 连跑 N 趟 `CAMPAIGN END`、**每趟一架都没打成** → 这关跑不通（`'white'`）
      - 刷到趟数上限还是没达成 → 停手，把"要不要接着刷"交给用户（`'runs'`）
      - 连续 N 秒没有任何"人话"输出 → 一直没进展（`'silent'`，实测见过连刷 40 分钟 `Walk timeout`）

    ⚠️ **"白跑"必须按"打没打成架"算，不能按"有没有三星"算**（2026-10-15 实测纠错）：
    三星里那颗「击破护卫舰队 n/N」是**跨趟累计**的计数星，一关本来就得刷好几趟才满，
    每趟都会以 `CAMPAIGN END` 正常收尾、且**没有** `Reach condition`。
    按"没达成三星"算，壳会在第二趟就把正在正常推进的它掐掉 ——
    4-3 那次就是这样：Alas 第二趟把计数刷满、正在第三趟进图时重读星数准备宣布三星，
    壳在它前面 1 秒下了手 → 用户看到"未达成"，游戏里却是三星。

    分类型是为了 `_stage()` 的重试：只有 `'silent'` 值得换一趟再跑。

    `allow_runs=False` 给**刷光石油**用 —— 那个模式本来就该跑很多趟、
    每趟都以「打完一趟」结束而没有「达成三星」，**"趟数类"判据（`'white'`/`'runs'`）会误杀它**，
    所以两个一起关掉，只留「假死」刹车（它的刹车本来就是油量）。
    """
    if allow_runs and not reached and white_runs >= STUCK_WHITE_RUNS:
        return "white", f"连跑 {white_runs} 趟都没打成架"
    if idle_s > silent_s:
        return "silent", f"已经 {int(idle_s / 60)} 分钟没有任何进展"
    if allow_runs and run_limit and not reached and runs >= run_limit:
        return "runs", f"连刷 {runs} 趟还没把星星拿满"
    return "", ""


def _task_label(task: str) -> str:
    """Alas 任务名 → 人话。

    认不出来的任务**不能露英文名**（2026-10-21 用户指出）：`Task call: X` 的 X 可能是
    `Restart` / `OpsiHazard1Leveling` 这类，直接显示会很突兀 —— 一律说「别的任务」。
    """
    for name, label in DAILY_TASKS:
        if name == task:
            return label
    return EXTRA_LABELS.get(task, "别的任务")


# `Task call: X` 里可能出现的其它任务（`campaign/run.py`、`os_run.py` 里能看到）
EXTRA_LABELS = {
    "Restart": "重启游戏",
    "Reward": "收获",
    "OpsiHazard1Leveling": "大世界练级",
    "OpsiAshBeacon": "大世界信标",
}


class App:
    def __init__(self) -> None:
        self._app_id()      # 必须在建窗口之前：任务栏靠它认图标
        self.root = tk.Tk()
        self.root.title("MuMu 碧蓝助手")
        # 窗口大小（2026-10-28 用户定了范围）：比原来的 600x500 大一点、日志能看全，
        # 但别铺满屏 —— 1080p 上约 740x640，768p 笔记本自动收到 580 高。
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()
        win_w = min(740, max(660, screen_w - 400))
        win_h = min(640, max(560, screen_h - 200))
        self.root.geometry(f"{win_w}x{win_h}+{max(0, (screen_w - win_w) // 2)}"
                           f"+{max(0, (screen_h - win_h) // 3)}")
        self.root.minsize(640, 540)
        icon = PACKAGE / "icon.ico"
        if icon.exists():
            try:
                # 不给图标，标题栏就顶着 Tk 那只羽毛，一眼"半成品"
                self.root.iconbitmap(str(icon))
            except tk.TclError:
                pass

        self.q: queue.Queue[str] = queue.Queue()
        self._last_said = ""              # 上一行原文（连续重复的丢掉）
        self._said_warn: set[str] = set()  # 这一趟已经说过的告警（同一句只说一次）
        self.box: AlasBox | None = None
        self.worker: threading.Thread | None = None
        self.cancelled = False

        self.stage = tk.StringVar(value="")             # 默认**留空**：英文+数字的代号基本都是限时活动关
        self.all_stages: list[str] = []                 # Alas 认得的活动关卡，见 _load_stages()
        self._missing_events: dict[str, str] = {}       # 「灰色选项 → 活动目录名」，见 _load_stages()
        self._stages_ready = False                      # 后台取到了没（主线程据此去刷新界面）
        self._stages_applied = False
        self._pending_stage_clear = False               # worker 要求清空关卡框（更新完要用）
        self.auto_next = tk.BooleanVar(value=True)      # 打完自动下一关，默认开
        self.hard = tk.BooleanVar(value=False)          # 打主线「困难」图（和普通图同名，默认普通）
        # 心情不归壳管（见 row3 注释）。轮换刷油只需要「换队」这一个动作，
        # 由 `StopCondition.RunCount` 在"一趟回港"时触发，零浪费。
        self._hard = False                # worker 用的困难图快照（主线程 on_start 里写）
        self._oil_done = False            # 这一趟是不是"油不足"正常收工（轮换到这就收手）
        self._last_stuck = ""             # 上一趟卡住的原因（silent / adb / game）
        self._restored = False            # 本次任务是否已经"换队失败退回 1-2 队"过一次
        self._pending_fleet_alert = False # 主线程去弹「编队检测为空」
        self._running_mode = ""                         # 正在跑的那个入口（决定哪个按钮是蓝的）
        self.status = tk.StringVar(value="待命")
        self._pending_status: str | None = None         # worker 只写这两个，界面归主线程改
        self._pending_busy: bool | None = None          # （跨线程碰 Tk 实测会抛 RuntimeError）
        self._tone_color: str = ""                      # 最后一条日志的口吻（成/败）→ 状态点颜色
        self._busy_now = False
        self._pending_update: dict | None = None        # 后台查到的新版本，主线程去显示
        self._pending_chip: str | None = None           # 顶部那句"正在下载/已就绪"（worker 写）
        self._update_retry = 0                          # 下载失败自动重试的次数（最多 2 次）
        self._retry_scheduled = False                   # 已经排了一次重试（避免重复排队）
        self._update_found: dict | None = None          # 已经显示过的那条（开跑清屏后要补回来）
        self._staged_version = ""                       # 已经下好、等用户点头就换上去的版本
        # ── 提醒（左上角渐变文字 + 右下角倒计时卡片，照 M9A 的做法）──
        # 为什么要两层：渐变文字是"一直提醒你但绝不打断"，卡片是"说清改了什么、10 秒后自己消失"。
        self._chip_text = ""                            # 渐变文字的正文（空 = 隐藏、动画停）
        self._chip_action = None                        # 点它做什么（None = 重新打开卡片）
        self._pulsing = False                           # 渐变动画在跑
        self._pulse_phase = 0.0
        self._toast_win: tk.Toplevel | None = None      # 右下角那张卡片
        self._toast_job: str | None = None              # 倒计时的 after 句柄
        self._last_toast: tuple | None = None           # 刚才那张卡片的内容（点渐变文字再弹一次）
        self._toasted_key = ""                          # 已经弹过卡片的那个状态（别重复弹）
        self._alas_auto_note = ""                       # 后台自动更新 Alas 时的一句话（on_start 用它拦）
        self._pending_alas_alert: tuple[str, str] | None = None   # (活动名, 失败原因)
        self._pending_alas_chip: str | None = None      # 冷却期里只留左上角那句、不弹卡片
        self._pending_toast: tuple[str, str] | None = None        # (标题, 正文) 主线程去弹
        self._alas_scan: str | None = None              # 后台扫盘结果（""=没找到）
        self._alas_prompted = False                     # 本次开窗只问一次
        self._prompt_req: dict | None = None            # worker 想弹框 → 交给主线程（见 _ask_blocking）
        self._style()                                   # 皮肤先立好，控件再建（否则吃系统默认样式）
        self._build()
        self._title_bar()
        self._taskbar_icon()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.after(POLL_MS, self._drain)
        self.root.after(200, self._load_stages)         # 候选后台加载，不拖慢开窗
        self.root.after(400, self._startup_check)       # 单实例 + 清理残留引擎
        self.root.after(600, self._check_update)        # 顺便看看有没有新版（失败静默）
        # 窗口建出来 = 新版本活过来了 → 立刻销掉"待验证"标记（见 selfupdate.mark_healthy）。
        # 不能放在"几秒之后"：用户开窗两秒就关掉的话，下次启动会被判成坏版本退回旧版。
        selfupdate.mark_healthy()

    # ---------------- 界面（皮肤）----------------
    # 配色与手法照同类小工具（MAA 的「一键长草」、MFA 的任务管理器）：
    # 浅灰底 + 白卡片 + 蓝色主按钮 + 顶部一行「状态点 + 现在在干什么」+ 日志单独一张卡。
    # 只用 ttk 的 clam 主题 + `tk.Frame` 描边画卡片 —— 不引第三方 UI 库、不自绘控件：
    # 壳是钩子，皮肤只求"一眼看出该点哪、现在在干什么"，不追视觉复杂度（见 AGENTS.md）。
    BG = "#f2f3f5"        # 窗口底
    CARD = "#ffffff"      # 卡片底
    LINE = "#e3e5e8"      # 卡片描边
    INK = "#1f2329"       # 主文字
    MUTED = "#8a9099"     # 次要文字
    ACCENT = "#2563eb"    # 主色：一键三星按钮、运行中的状态点
    ACCENT_DARK = "#1d4ed8"
    OK = "#16a34a"
    WARN = "#d97706"
    BAD = "#dc2626"
    FONT = "Microsoft YaHei UI"

    def _app_id(self) -> None:
        """让任务栏按钮用**窗口图标**（贴纸那张脸），而不是 `pythonw.exe` 的 Python 图标。

        任务栏默认按"进程的 exe"认图标 —— 壳现在跑在 `pythonw.exe` 上，
        所以任务栏顶着 Python 图标（用户 2026-10-16 截图指出）。
        给进程一个自己的 AppUserModelID，Windows 就改用窗口的图标（= `icon.ico`）。
        打包成 exe 之后由 PyInstaller 的 `--icon` 接管，这一步留着也无害。
        """
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "MuMu.AzurLane.Helper")
        except (AttributeError, OSError):
            pass

    def _taskbar_icon(self) -> None:
        """把 `icon.ico` **显式塞给窗口**（`WM_SETICON`）。

        Tk 的 `iconbitmap` 只管标题栏那个小图标；任务栏那格取的是"大图标"，
        取不到就退回 Tk 的默认羽毛 —— 2026-10-16 实测：标题栏已经是我们的图标了，
        任务栏还顶着羽毛。所以自己 `LoadImage` 再 `WM_SETICON`。

        ⚠️ `LoadImage` 一定要**报尺寸**：写 0 的话 Windows 会拿 ico 里最大那张（256）再自己缩到
        24，等于多挨一次缩放插值 —— 24px 那格本来就紧，这一下就明显糊。所以按槽位各取各的帧：
        小图标（标题栏）= 16、大图标（任务栏）= 24。
        """
        icon = PACKAGE / "icon.ico"
        if not icon.exists():
            return
        try:
            self.root.update_idletasks()
            u = ctypes.windll.user32
            u.LoadImageW.restype = ctypes.c_void_p
            u.LoadImageW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_uint,
                                     ctypes.c_int, ctypes.c_int, ctypes.c_uint]
            hwnd = u.GetParent(self.root.winfo_id())
            for slot, size in ((0, 16), (1, 24)):      # 0=ICON_SMALL(标题栏) 1=ICON_BIG(任务栏)
                hicon = u.LoadImageW(None, str(icon), 1, size, size, 0x00000010)
                if hicon:
                    u.SendMessageW(hwnd, 0x0080, slot, ctypes.c_void_p(hicon))
        except (AttributeError, OSError):
            pass

    def _style(self) -> None:
        """统一控件外观。`clam` 才允许自由改颜色（vista 主题很多样式被系统锁死）。"""
        s = ttk.Style(self.root)
        s.theme_use("clam")
        f = (self.FONT, 10)
        self.root.configure(background=self.BG)
        s.configure(".", background=self.BG, foreground=self.INK, font=f)
        s.configure("TFrame", background=self.BG)
        s.configure("Card.TFrame", background=self.CARD)
        s.configure("TLabel", background=self.BG, foreground=self.INK, font=f)
        s.configure("Card.TLabel", background=self.CARD, foreground=self.INK, font=f)
        s.configure("Muted.TLabel", background=self.BG, foreground=self.MUTED,
                    font=(self.FONT, 9))
        s.configure("CardMuted.TLabel", background=self.CARD, foreground=self.MUTED,
                    font=(self.FONT, 9))
        s.configure("Status.TLabel", background=self.BG, foreground=self.INK,
                    font=(self.FONT, 11))
        s.configure("TCheckbutton", background=self.CARD, foreground=self.INK, font=f)
        s.map("TCheckbutton", background=[("active", self.CARD)])
        s.configure("TCombobox", padding=(6, 4), arrowsize=14)
        # 次要按钮：白底 + 1px 描边；小一号的给工具行（弱化）
        s.configure("TButton", background=self.CARD, foreground=self.INK, font=f,
                    borderwidth=1, relief="solid", padding=(14, 8), focusthickness=0)
        s.map("TButton",
              background=[("active", "#eef1f5"), ("pressed", "#e4e8ee"), ("disabled", "#f5f6f7")],
              foreground=[("disabled", "#b3b8bf")])
        s.configure("Small.TButton", padding=(10, 5), font=(self.FONT, 9))
        # 停止：次要按钮里最"危险"的那个，只把字染红，不抢主按钮的位置
        s.configure("Danger.TButton", background=self.CARD, foreground=self.BAD,
                    borderwidth=1, relief="solid", padding=(10, 5), font=(self.FONT, 9),
                    focusthickness=0)
        s.map("Danger.TButton",
              background=[("active", "#fdeeee"), ("disabled", "#f5f6f7")],
              foreground=[("disabled", "#b3b8bf")])
        # 主按钮：填色 —— **只在"这个入口正在跑"时用它**（用户 2026-10-16 指出：常驻蓝色会被
        # 误读成"当前选中的是一键三星"）。所以三个入口闲着时长得一样，谁在跑谁变蓝。
        s.configure("Run.TButton", background=self.ACCENT, foreground="#ffffff",
                    borderwidth=0, focusthickness=0, padding=(20, 11),
                    font=(self.FONT, 11, "bold"))
        s.map("Run.TButton",
              background=[("active", self.ACCENT), ("pressed", self.ACCENT),
                          ("disabled", self.ACCENT)],
              foreground=[("disabled", "#eaf0ff")])
        s.configure("Vertical.TScrollbar", background="#d8dbe0", troughcolor=self.CARD,
                    borderwidth=0, arrowsize=12)

    def _card(self, fill: str = "x", expand: bool = False,
              pady: tuple[int, int] = (0, 10)) -> tk.Frame:
        """一张白卡片：`tk.Frame` 画 1px 浅描边。

        Tk 画不了圆角，但"浅灰底 + 白卡片 + 留白"这三样在，观感就已经到位了。
        """
        card = tk.Frame(self.root, background=self.CARD, bd=0, highlightthickness=1,
                        highlightbackground=self.LINE, highlightcolor=self.LINE)
        card.pack(fill=fill, expand=expand, padx=14, pady=pady)
        return card

    def _build(self) -> None:
        # ── 顶部：状态点 + 现在在干什么 ──
        bar = tk.Frame(self.root, background=self.BG)
        bar.pack(fill="x", padx=16, pady=(14, 10))
        self.dot = tk.Canvas(bar, width=10, height=10, background=self.BG,
                             highlightthickness=0)
        self.dot.pack(side="left", pady=(4, 0))
        self.dot_id = self.dot.create_oval(1, 1, 9, 9, fill=self.MUTED, outline="")
        ttk.Label(bar, textvariable=self.status, style="Status.TLabel").pack(side="left", padx=(8, 0))
        # 版本号 + 构建日期写在右上角（用户报问题时，第一眼就能知道他手上是哪版）。
        # 放两行、小字：不占宽度，也不像日志里那样显眼（2026-10-21 用户要求）。
        ttk.Label(bar, text=f"v{__version__}\n{build_stamp_text()}", style="Muted.TLabel",
                  justify="right").pack(side="right")
        # 更新提醒：**紧贴状态文字（左上角）**，照 M9A 的做法 ——
        # 平时不占位，有更新才出现，并且颜色一直呼吸渐变（见 `_pulse`），
        # 目的是"一直在提醒你，但绝不打断你"。点它 → 重新打开右下角那张卡片。
        self.update_chip = tk.Label(bar, text="", background=self.BG, foreground=self.WARN,
                                    font=(self.FONT, 9, "bold"), cursor="hand2")
        self.update_chip.pack(side="left", padx=(14, 0))
        self.update_chip.bind("<Button-1>", lambda _e: self._open_update())

        # ── 卡片一：关卡 ──
        c1 = self._card()
        row = ttk.Frame(c1, style="Card.TFrame")
        row.pack(fill="x", padx=14, pady=(12, 0))
        ttk.Label(row, text="关卡", style="Card.TLabel").pack(side="left")
        # 可下拉选（看到全部关卡），也能直接打代号；打字时按输入过滤候选。
        # 候选来自 Alas 自己认得的关卡（`AlasBox.stages()`），不写死。
        self.stage_box = ttk.Combobox(row, textvariable=self.stage, width=8,
                                      postcommand=self._filter_stages)
        self.stage_box.pack(side="left", padx=(12, 0))
        self.stage_box.bind("<KeyRelease>", self._on_stage_typed)
        self.stage_hint = ttk.Label(row, text="填代号（活动 C2 / 主线 12-4）",
                                    style="CardMuted.TLabel")
        self.stage_hint.pack(side="left", padx=(12, 0))
        row2 = ttk.Frame(c1, style="Card.TFrame")
        row2.pack(fill="x", padx=14, pady=(10, 12))
        # 开关自己画：clam 主题把"选中"画成 ✗、"未选"画成实心块（语义正好反着，用户实测被绕晕），
        # 经典 Tk 的勾选框两个状态都是空框 —— 原生两条路都不能用（见 shots/check_test.png）。
        self.toggle = tk.Canvas(row2, width=40, height=20, background=self.CARD,
                                highlightthickness=0, cursor="hand2")
        self.toggle.pack(side="left")
        self.toggle.bind("<Button-1>", lambda _e: self._flip(self.toggle, self.auto_next))
        self.auto_label = ttk.Label(row2, text="打完自动下一关", style="Card.TLabel",
                                    cursor="hand2")
        self.auto_label.pack(side="left", padx=(8, 0))
        self.auto_label.bind("<Button-1>", lambda _e: self._flip(self.toggle, self.auto_next))
        ttk.Label(row2, text="（A1 → A2 → A3 一路推）",
                  style="CardMuted.TLabel").pack(side="left", padx=(8, 0))

        # 主线「困难」图和普通图**同名**（10-3 两种都有），Alas 靠 `Campaign.Mode` 分。
        # 所以这里必须让用户明说一句，否则打的是哪种全看配置文件里留了什么。
        row3 = ttk.Frame(c1, style="Card.TFrame")
        row3.pack(fill="x", padx=14, pady=(0, 12))
        self.hard_toggle = tk.Canvas(row3, width=40, height=20, background=self.CARD,
                                     highlightthickness=0, cursor="hand2")
        self.hard_toggle.pack(side="left")
        self.hard_toggle.bind("<Button-1>", lambda _e: self._flip(self.hard_toggle, self.hard))
        self.hard_label = ttk.Label(row3, text="打困难图", style="Card.TLabel", cursor="hand2")
        self.hard_label.pack(side="left", padx=(8, 0))
        self.hard_label.bind("<Button-1>", lambda _e: self._flip(self.hard_toggle, self.hard))
        # 心情不再由壳管（2026-10-27 用户定）：Alas 有 8 个心情参数、每队一套，
        # 壳要跟上就得把它们全暴露出来 —— 那就是"替 Alas 打工"。
        # 用户自己在游戏里看心情条；想少亏就点「轮换刷油」，壳只负责换队。
        for canvas, var in ((self.toggle, self.auto_next), (self.hard_toggle, self.hard)):
            self._draw_toggle(canvas, var)

        # ── 卡片二：动作 ──
        # 三个入口只差「干什么」：打三星 / 刷光石油 / 清日常；下面一行是工具（弱化）。
        # 「还原配置」这名字会被误读成"清空助手自己的设置"，所以点名：动的是 Alas 的东西。
        c2 = self._card()
        act = ttk.Frame(c2, style="Card.TFrame")
        act.pack(fill="x", padx=14, pady=(14, 0))
        # 五个入口**等宽**排一行（`grid` + `weight`）：600 宽窗口里 `pack` 会放不下，
        # 第 5 个只露一条边（2026-10-27 实测）。等宽网格自动按比例分，加按钮也不会溢出。
        for col in range(5):
            act.columnconfigure(col, weight=1)
        specs = (("一键三星", MODE_3STARS),
                 ("刷光石油", MODE_OIL),
                 # 轮换刷油：每 ROTATE_RUNS 趟自动换一组编队（零浪费，Alas 在一趟回港时自己停）
                 ("轮换刷油", MODE_ROTATE),
                 ("清日常", MODE_DAILY),
                 # 活动每日：活动期间每天必须做（A/B/C/D/SP 各打一次）
                 ("活动每日", MODE_EVENT))
        made = []
        for col, (text, mode) in enumerate(specs):
            button = ttk.Button(act, text=text, command=lambda m=mode: self.on_start(m))
            button.grid(row=0, column=col, sticky="ew", padx=(0 if col == 0 else 4, 0))
            made.append(button)
        self.btn_start, self.btn_oil, self.btn_rotate, self.btn_daily, self.btn_event = made
        tools = ttk.Frame(c2, style="Card.TFrame")
        tools.pack(fill="x", padx=14, pady=(12, 14))
        self.btn_open_alas = ttk.Button(tools, text="打开 Alas 设置", style="Small.TButton",
                                        command=self.on_open_alas)
        self.btn_open_alas.pack(side="left")
        ttk.Button(tools, text="还原 Alas 初始配置", style="Small.TButton",
                   command=self.on_unpark).pack(side="left", padx=(8, 0))
        # 给别人用的第一件事：Alas 装在哪个盘只有用户自己知道（壳只认得我们自己的机器）
        ttk.Button(tools, text="选 Alas 文件夹", style="Small.TButton",
                   command=self.on_pick_alas).pack(side="left", padx=(8, 0))
        self.btn_stop = ttk.Button(tools, text="停止", style="Danger.TButton",
                                   command=self.on_stop, state="disabled")
        self.btn_stop.pack(side="left", padx=(8, 0))

        # ── 卡片三：日志（人话，按级别着色）──
        # 高度交给 `expand=True` 去撑：Text 的 height 只当"最小高度"用，
        # 故意给小一点，否则它撑出来的自然高度会顶穿窗口、把卡片下沿切掉（实测踩过）。
        c3 = self._card(fill="both", expand=True, pady=(0, 12))
        head = ttk.Frame(c3, style="Card.TFrame")
        head.pack(fill="x", padx=14, pady=(10, 0))
        ttk.Label(head, text="日志", style="CardMuted.TLabel").pack(side="left")
        body = tk.Frame(c3, background=self.CARD)
        body.pack(fill="both", expand=True, padx=10, pady=(4, 10))
        self.txt = tk.Text(body, height=7, wrap="word", state="disabled", relief="flat",
                           bd=0, background=self.CARD, foreground=self.INK,
                           font=(self.FONT, 9), padx=6, pady=4, cursor="arrow",
                           spacing1=1, spacing3=3, selectbackground="#dce7fb")
        scroll = ttk.Scrollbar(body, orient="vertical", command=self.txt.yview,
                               style="Vertical.TScrollbar")
        self.txt.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.txt.pack(side="left", fill="both", expand=True)
        self.txt.tag_configure("head", foreground=self.INK,
                               font=(self.FONT, 10, "bold"), spacing3=6)
        self.txt.tag_configure("ok", foreground=self.OK)
        self.txt.tag_configure("warn", foreground=self.WARN)
        self.txt.tag_configure("bad", foreground=self.BAD)
        self.txt.tag_configure("muted", foreground=self.MUTED)
        self.txt.tag_configure("sep", foreground="#c9ced6")
        # 可点的链接（现在只有"有新版本 → 点这里下载"用）
        self.txt.tag_configure("link", foreground=self.ACCENT, underline=True)
        self.txt.tag_bind("link", "<Button-1>", lambda _e: self._open_update())
        self.txt.tag_bind("link", "<Enter>", lambda _e: self.txt.configure(cursor="hand2"))
        self.txt.tag_bind("link", "<Leave>", lambda _e: self.txt.configure(cursor="arrow"))

        # 「导出日志」放**日志卡片底部**（2026-10-28 用户要求），配一句灰色说明：
        # 用户不知道报错时要干什么，得明说"出问题就把这个文件发给开发者"。
        export_row = ttk.Frame(c3, style="Card.TFrame")
        export_row.pack(fill="x", padx=14, pady=(0, 10))
        ttk.Button(export_row, text="导出日志发给开发者", style="Small.TButton",
                   command=self.on_export_log).pack(side="left")
        ttk.Label(export_row,
                  text="（如遇报错，点这里把日志打包发给开发者；只存你电脑上，不会上传）",
                  style="CardMuted.TLabel").pack(side="left", padx=(8, 0))
        # 空状态 = 一张"工具简介"（用户 2026-10-16 要的）：一进来就说清这是什么、该点哪。
        # 一开跑 `_run_once` 会把整块日志清掉，所以它只活在"还没动手"的时候。
        self._show_intro()

    def on_export_log(self) -> None:
        try:
            path = self._export_bundle()
        except OSError as exc:
            self.say(f"❌ 导出失败：{exc}")
            return
        self.say(f"✔ 日志已打包：{path}")
        messagebox.showinfo(
            "日志已导出",
            f"已保存到：\n{path}\n\n把这个文件发给我就能定位问题。\n"
            "（只打包在你电脑上，不会上传任何东西）",
            parent=self.root)
        try:
            subprocess.run(["explorer", "/select,", str(path)], cwd=SAFE_CWD)
        except OSError:
            pass

    def _export_bundle(self) -> Path:
        """把日志 + 环境信息打成一个 zip 放桌面（只在本机，不联网）。

        为什么要"打包"而不是让用户自己找目录：真正的原因在 Alas 自己的日志里，
        而它是按天一个文件、藏在安装目录下 —— 让普通用户去翻，等于放弃反馈。
        """
        desktop = Path(os.environ.get("USERPROFILE") or Path.home()) / "Desktop"
        if not desktop.exists():
            desktop = paths.data_dir()
        out = desktop / f"MuMu碧蓝助手日志-{time.strftime('%Y%m%d-%H%M%S')}.zip"

        info = [f"版本      : {__version__}",
                f"构建      : {BUILD_STAMP or '开发版'}",
                f"时间      : {time.strftime('%Y-%m-%d %H:%M:%S')}",
                f"Python    : {sys.version.split()[0]}",
                f"平台      : {platform.platform()}",
                f"更新表来源: {update.LAST_SOURCE or '（没读到）'}",
                f"Alas 路径 : {find_install() or '（没找到）'}"]
        try:
            mumu = MuMu()
            info.append(f"MuMu 根目录: {mumu.root}")
            for inst in mumu.instances():
                info.append(f"  实例 {inst.get('index')}：{inst.get('name')}，"
                            f"状态={inst.get('player_state') or '未启动'}，"
                            f"adb={inst.get('adb_host_ip')}:{inst.get('adb_port')}")
        except Exception as exc:                       # noqa: BLE001
            info.append(f"MuMu      : 读不到（{exc}）")

        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("环境信息.txt", "\n".join(info) + "\n")
            # 壳自己的人话日志（2026-10-28 加）—— 排查"壳为什么这么判断"全靠它
            shells = sorted(paths.log_dir().glob("shell-*.log"),
                            key=lambda p: p.stat().st_mtime)
            for log in shells[-2:]:
                zf.write(log, f"壳人话日志/{log.name}")
            logs = sorted(paths.log_dir().glob("onetap_*.log"),
                          key=lambda p: p.stat().st_mtime)
            for log in logs[-3:]:                      # 最近三次（Alas 原文快照）
                zf.write(log, f"Alas原文快照/{log.name}")
            if self.box is not None:
                try:
                    alas_log = self.box.log_file()
                    if alas_log.exists():
                        zf.write(alas_log, f"Alas日志/{alas_log.name}")
                except Exception:                      # noqa: BLE001
                    pass
        return out

    def _check_update(self) -> None:
        """后台查一次新版，**顺手把包下下来**。查不到 / 没网 / 下载失败一律当没事。

        为什么不是"提示用户点链接"（MAA 那种）：那是给会去 GitHub 的人用的。
        1 万人里绝大多数不会点、也不该被要求点 —— 壳自己下好、自己换（见 selfupdate）。
        """
        def work() -> None:
            found = update.check(__version__, skip=selfupdate.blocked())
            if not found:
                return
            found["staged"] = False
            self._pending_chip = f"🔄 正在后台下载新版本 v{found['version']}…"
            try:                                   # 下不下来都不影响"有新版本"这条提示
                zip_path = paths.staging_dir() / f"shell-{found['version']}.zip"
                update.download([found["url"], *found.get("mirrors", [])],
                                zip_path, found["sha256"], found["size"])
                selfupdate.stage(zip_path, found["version"])
                found["staged"] = True
            except (update.UpdateError, OSError):
                pass
            self._pending_update = found           # 界面归主线程改，见 _drain

        threading.Thread(target=work, daemon=True).start()

    # ---------------- 提醒（渐变文字 + 倒计时卡片）----------------
    def _set_chip(self, text: str, action=None) -> None:
        """左上角那句提醒：空串 = 收起。设了就自动开始呼吸渐变。"""
        self._chip_text = text
        self._chip_action = action
        try:
            self.update_chip.configure(text=text)
        except (AttributeError, tk.TclError):
            return
        if text and not self._pulsing:
            self._pulsing = True
            self._pulse()

    def _pulse(self) -> None:
        """让那句提醒的颜色一直呼吸（照 M9A 的"动态颜色吸引点击"）。

        用正弦插值而不是两色硬切：硬切看着像闪烁，读起来累。
        80ms 一帧约 12 帧/秒，够顺滑又不吃 CPU，而且**文字一撤就自己停**。
        """
        if not self._chip_text:
            self._pulsing = False
            return
        try:
            self.update_chip.configure(
                foreground=_blend("#b45309", "#f59e0b", (math.sin(self._pulse_phase) + 1) / 2))
        except (AttributeError, tk.TclError):
            self._pulsing = False
            return
        self._pulse_phase += 0.12
        self.root.after(80, self._pulse)

    def _toast(self, title: str, body: str, notes: str = "",
               action=None, action_text: str = "", seconds: int = 10) -> None:
        """右下角那张卡片：说清"有什么新东西"，**倒计时读完自己消失**（M9A 的做法）。

        为什么不弹 messagebox：那会卡住用户、必须点"确定"。天天弹一次就是骚扰，
        而这两件事（下包、换版本）本来就不需要他做任何决定。
        """
        self._toast_close()
        self._last_toast = (title, body, notes, action, action_text)
        win = tk.Toplevel(self.root)
        win.withdraw()                              # 先藏起来：尺寸算好再露面，避免闪一下
        win.overrideredirect(True)                  # 无边框：像浮在窗口上的卡片
        win.attributes("-topmost", True)
        win.configure(background=self.LINE)
        # **别给窗口设尺寸再量内容**：`overrideredirect` 的窗口初始 1x1，
        # 先 `geometry()` 一个高度会让 pack 认为"没地方了"，把后面的控件全藏起来
        # → 卡片弹出来是空白（2026-10-23 实测踩到两次）。所以：藏起来 → 排好 → 量 → 再定尺寸。
        width = 320
        card = tk.Frame(win, background=self.CARD)
        card.pack(fill="both", expand=True, padx=1, pady=1)
        tk.Label(card, text=title, background=self.CARD, foreground=self.INK,
                 font=(self.FONT, 10, "bold"), anchor="w", justify="left",
                 wraplength=286).pack(fill="x", padx=16, pady=(14, 4))
        tk.Label(card, text=body, background=self.CARD, foreground=self.INK,
                 font=(self.FONT, 9), justify="left", anchor="w", wraplength=286).pack(
            fill="x", padx=16)
        if notes:
            tk.Label(card, text=notes, background=self.CARD, foreground=self.MUTED,
                     font=(self.FONT, 9), justify="left", anchor="w",
                     wraplength=286).pack(fill="x", padx=16, pady=(8, 0))
        row = tk.Frame(card, background=self.CARD)
        row.pack(fill="x", padx=14, pady=(14, 12))
        # 先 pack 主按钮再 pack「以后」：`side="right"` 是**先到先靠最右**，
        # 反过来就把"以后"顶到最右边了（2026-10-23 截图发现）。
        if action_text:
            tk.Button(row, text=action_text, background=self.ACCENT, foreground="#ffffff",
                      relief="flat", bd=0, activebackground=self.ACCENT_DARK,
                      activeforeground="#ffffff", font=(self.FONT, 9), cursor="hand2",
                      padx=14, pady=3,
                      command=action or self._toast_close).pack(side="right")
        # 「以后」只在**真有得选**的时候给：壳的更新是自动的，用户点不点都会换，
        # 再摆一个"以后"就是在骗他（2026-10-23 用户指出两个按钮做的是同一件事）。
        if action:
            tk.Button(row, text="以后", background=self.CARD, foreground=self.MUTED,
                      relief="flat", bd=0, activebackground="#eef1f5", font=(self.FONT, 9),
                      cursor="hand2", command=self._toast_close).pack(side="right", padx=(0, 12))
        # 底部那条倒计时（M9A 的那个"读条"）：读完 = 卡片自己消失
        bar = tk.Canvas(card, height=4, background="#eef1f5", highlightthickness=0)
        bar.pack(fill="x", side="bottom")
        fill = bar.create_rectangle(0, 0, 1, 4, fill="#d97706", outline="")
        win.update_idletasks()
        height = card.winfo_reqheight() + 2
        x = self.root.winfo_rootx() + self.root.winfo_width() - width - 18
        y = self.root.winfo_rooty() + self.root.winfo_height() - height - 18
        win.geometry(f"{width}x{height}+{max(0, x)}+{max(0, y)}")
        win.deiconify()
        win.update_idletasks()
        self._toast_win = win
        total = remain = max(1, seconds * 20)

        def tick() -> None:
            nonlocal remain
            remain -= 1
            if remain <= 0 or self._toast_win is None:
                self._toast_close()
                return
            try:
                bar.coords(fill, 0, 0, max(1, int(width * remain / total)), 4)
            except tk.TclError:
                return
            self._toast_job = self.root.after(50, tick)

        self._toast_job = self.root.after(50, tick)

    def _toast_close(self) -> None:
        if self._toast_job is not None:
            try:
                self.root.after_cancel(self._toast_job)
            except tk.TclError:
                pass
            self._toast_job = None
        if self._toast_win is not None:
            try:
                self._toast_win.destroy()
            except tk.TclError:
                pass
            self._toast_win = None

    def _show_update(self, found: dict) -> None:
        """壳有新版本：左上角渐变提醒 + 右下角卡片。

        **下载是全自动的，换不换由用户点头**（2026-10-23 用户定）：
        以前是"下好 800 毫秒就自己重启"，卡片还没看清窗口就闪了 —— 那等于白弹。
        现在改成：点「知道了」立刻换；不点就下次开窗时换（`selfupdate.bootstrap`）。
        """
        self._update_found = found
        version = found["version"]
        if found.get("staged"):
            self._staged_version = version
            self._set_chip(f"🔄 新版本 v{version} 已就绪", self._open_update)
            body = "已经下好了。点「现在更新」就换上（窗口闪一下就好）。"
        else:
            self._set_chip(f"🔄 有新版本 v{version}，正在下载", self._open_update)
            body = "正在后台下载，不用管它。"
            if self._update_retry < 2 and not self._retry_scheduled:
                self._update_retry += 1
                self._retry_scheduled = True
                self.root.after(90_000, self._retry_update)
        # 卡片只在"状态变了"时弹一次：下载中弹一次、下好了再弹一次（第二张才有按钮）。
        # 只按版本号去重是不够的 —— 那样下好之后不会再弹，用户永远看不到「现在更新」。
        key = f"{version}:{'ready' if found.get('staged') else 'downloading'}"
        if self._toasted_key != key:
            self._toasted_key = key
            notes = f"更新内容：{found['notes']}" if found["notes"] else ""
            # 卡在"下载中"时不给按钮 —— 那时点了也没得换，只会骗人。
            self._toast(f"助手有新版本 v{version}", body, notes,
                        action=self._apply_now if found.get("staged") else None,
                        action_text="现在更新" if found.get("staged") else "", seconds=10)

    def _apply_now(self) -> None:
        """点了「知道了」：**立刻就换**（待命 = 空闲，没有理由再等 —— 用户 2026-10-23 指出）。"""
        self._toast_close()
        if not self._staged_version:
            return
        if self.worker is not None and self.worker.is_alive():
            self.say("· 这一趟跑完就换上，不会打断你")
            return
        self._do_update()

    def _retry_update(self) -> None:
        """下载失败 90 秒后再试一次（最多 2 次）。0.2.5 那轮卡死就是因为没有这个。"""
        self._retry_scheduled = False
        if self._staged_version or (self.worker is not None and self.worker.is_alive()):
            return
        self._check_update()

    def _open_update(self) -> None:
        """点左上角那句 → 把刚才那张卡片再弹一次（M9A 的做法）。"""
        if self._last_toast:
            self._toast(*self._last_toast)
        elif self._update_found:
            self._show_update(self._update_found)

    def _do_update(self) -> None:
        """换上新版本并重启自己（只由用户点「知道了」触发，见 `_apply_now`）。

        **有 Alas 在跑就绝不换** —— 换目录要重启窗口，正在打图的任务会被打断
        （那种伤害比"晚几分钟更新"大得多）。
        """
        version, self._staged_version = self._staged_version, ""
        if not version:
            return
        if self.box is not None and self.box.running():
            self._staged_version = version       # 有引擎在跑 → 留着，下次开窗时换
            self.say("· 引擎还在跑，这一版留到下次开窗时换上")
            return
        self.say(f"· 正在换成 v{version}（窗口会闪一下，马上就回来）")
        if not selfupdate.install(version):
            self.say("⚠️ 更新没换成（文件可能被占用），下次开窗会自动再试")
            return
        if selfupdate.relaunch():
            self.root.destroy()                  # 新窗口已经起来了，这个才关
            return
        # 起不来：**别关窗口**，否则用户以为工具崩了。新代码已经装好，重开就是新版。
        self.say("⚠️ 新版本装好了，但没能自动重开 —— 手动关掉助手再打开，就是新版了")

    def _show_intro(self) -> None:
        """空状态显示"工具简介"：一进来就知道这工具干什么、该点哪里、要注意什么。

        用户 2026-10-16 要的（原话：一进来日志区应该是类似工具简介的内容）。
        文案按 AGENTS.md 的边界来：只讲这三件事怎么点，不讲 Alas 的参数、不提它有多少功能。
        """
        lines = (
            ("head", "欢迎使用 MuMu 碧蓝助手，助你轻松护肝"),
            ("sep", "─" * 48),
            ("", "1. 上面填关卡：活动图填 C2 / D3，主线图填 12-4（困难图把「打困难图」打开）"),
            ("", "2. 点「一键三星」= 清图到三星，通关后自动推下一关"),
            ("muted", "     也能「刷光石油」（只刷这一关）、「清日常」或「活动每日」"),
            ("", "3. 想停 → 「停止」；想自己调设置 → 「打开 Alas 设置」"),
            ("muted", "石油少于 500 不会开始；跑的时候别在 Alas 界面点「启动」"),
        )
        self.txt.configure(state="normal")
        self.txt.delete("1.0", "end")
        for tag, text in lines:
            self.txt.insert("end", text + "\n", tag)
        self.txt.configure(state="disabled")

    def _dot(self, color: str) -> None:
        self.dot.itemconfigure(self.dot_id, fill=color)

    def _draw_toggle(self, canvas: tk.Canvas, var: tk.BooleanVar) -> None:
        """画画那个开关：胶囊 + 滑块。开 = 主色，关 = 灰（一眼分得出来，不靠 ✗ 这种记号）。"""
        on = bool(var.get())
        w, h, pad = 40, 20, 2
        track = self.ACCENT if on else "#c9ced6"
        canvas.delete("all")
        canvas.create_oval(0, 0, h, h, fill=track, outline="")
        canvas.create_oval(w - h, 0, w, h, fill=track, outline="")
        canvas.create_rectangle(h / 2, 0, w - h / 2, h, fill=track, outline="")
        x = w - h + pad if on else pad
        canvas.create_oval(x, pad, x + h - 2 * pad, h - pad, fill="#ffffff", outline="")

    def _flip(self, canvas: tk.Canvas, var: tk.BooleanVar) -> None:
        var.set(not var.get())
        self._draw_toggle(canvas, var)

    def _title_bar(self) -> None:
        """让标题栏别用深色。

        内容是浅灰白卡片，标题栏却跟着系统深色走 → 一条黑边顶着白卡片，很割裂
        （2026-10-15 截图一眼看出来）。Win10/11 认 `DWMWA_USE_IMMERSIVE_DARK_MODE`(20)，
        置 0 = 强制浅色标题栏；认不到就当没这回事（老系统本来也是浅色）。
        """
        try:
            self.root.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
            light = ctypes.c_int(0)
            ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(light),
                                                       ctypes.sizeof(light))
        except (AttributeError, OSError):
            pass

    @staticmethod
    def _tag(msg: str) -> str:
        """日志行的级别 → 颜色。只认开头那一个记号，其余一律正常色。"""
        s = msg.lstrip()
        if s.startswith(("✅", "✔", "🏁")):
            return "ok"
        if s.startswith(("❌", "⏹")):
            return "bad"
        if s.startswith(("⚠", "↻")):
            return "warn"
        if s.startswith("─"):
            return "sep"
        if s.startswith(("·", "（")):
            return "muted"
        return ""

    # ---------------- 关卡候选 ----------------
    def _load_stages(self) -> None:
        """后台取一次 Alas 认得的活动关卡。

        放后台 + 失败静默：候选只是"方便"，拿不到就退回原来的手填 ——
        不能让开窗或点按钮因为这件事失败。
        **只写普通属性，不在这里碰 Tk**：跨线程调 `root.after()` 实测会抛
        `RuntimeError: main thread is not in main loop`（2026-10-15），
        所以结果交给主线程的 `_drain()` 去应用。
        """
        def work() -> None:
            box = None
            try:
                box = self.box or AlasBox()
                self.all_stages = box.stages()
                self._missing_events = missing_event_options(box.root)
            except (AlasError, OSError):
                self.all_stages = []
                self._missing_events = {}
            self._stages_ready = True
            # 缺新活动 → **静默自动更新 Alas，不问、不等用户点**（2026-10-23 用户定）。
            # 先让界面用旧列表跑起来，更新在同一个后台线程里接着做（见 `_auto_update_alas`）。
            if box is not None and self._missing_events:
                self._auto_update_alas(box)

        threading.Thread(target=work, daemon=True).start()

    def _apply_stages(self) -> None:
        self._filter_stages()
        self._show_hint(generic=True)

    def _filter_stages(self) -> None:
        """按输入框里的字过滤候选（点下拉箭头时也会走这里，见 `postcommand`）。

        **只有"半截输入"才过滤**：输入框里已经是完整代号（如 `D1`）时下拉给全部候选 ——
        否则用户点箭头只能看到自己刚填的那一个，等于没法浏览全部关卡。
        """
        typed = self.stage.get().strip().upper()
        if not typed or typed in self.all_stages:
            # 下拉里**只放 Alas 真正认得的关卡**。缺的活动不塞进来：
            # 2026-10-23 用户否掉了那个做法（"提示放在下拉完全不合理"）——
            # 下拉是"选一个能跑的"，不是贴通知的地方。缺活动改走左上角提醒 + 右下角卡片。
            self.stage_box["values"] = self.all_stages
        else:
            self.stage_box["values"] = [s for s in self.all_stages if typed in s]

    def _show_hint(self, generic: bool = False) -> None:
        """右边那行提示：没候选时说怎么填，打字时列出筛出来的候选。

        `generic=True` 用于候选刚加载完时 —— 那时输入框里的默认值不代表用户意图。
        """
        typed = "" if generic else self.stage.get().strip().upper()
        if not self.all_stages:
            self.stage_hint.configure(text="填代号（活动 C2 / 主线 12-4）；没扫到 Alas 的关卡列表就先手动填")
        elif not typed:
            self.stage_hint.configure(text=f"可下拉选（{len(self.all_stages)} 关：活动+主线），也能直接打代号")
        else:
            matches = [s for s in self.all_stages if typed in s]
            self.stage_hint.configure(
                text="→ 可选：" + " ".join(matches[:6]) + ("…" if len(matches) > 6 else "")
                if matches else "Alas 里没有这个代号，看看游戏里显示的是什么")

    def _on_stage_typed(self, _event: object = None) -> None:
        """打字即反馈。

        **不自动弹出下拉** —— 实测 `Post` / `<Down>` 不会覆盖输入（2026-10-15），
        但弹出后的焦点与输入行为在这里验证不了，不值得为"更炫"去踩这个坑。
        """
        self._filter_stages()
        self._show_hint()

    def say(self, msg: str) -> None:
        """写一行到日志区。

        **同一个警告只出现一次**（2026-10-21 实机反馈：船坞满那句连刷 4 遍）。
        Alas 每次重试都会把同样的 CRITICAL 再打一遍，壳原来照单全收 —— 用户看到的就是"刷屏"。
        规则：
          - 和上一行完全相同 → 丢掉（连刷同一句没有意义）
          - `⚠️` / `❌` 开头的告警 → 整趟任务里只出现一次
          - 其它（进度、趟数）照旧重复显示，那是正常的推进过程
        """
        key = msg.strip()
        if not key:
            return
        if key == self._last_said:
            return
        if key.startswith(("⚠️", "❌")):
            if key in self._said_warn:
                return
            self._said_warn.add(key)
        self._last_said = key
        self.q.put(msg)
        self._log_ui(msg)

    def _log_ui(self, msg: str) -> None:
        """把界面上每一行人话也写进 `shell-<日期>.log`（2026-10-28 加的）。

        为什么必须单独写一份：`_dump_raw` 存的是 **Alas 原文**，排查"壳为什么这么
        判断"时一个字都看不到 —— 这次换队就卡在这：只能看到 Alas 打
        `Using fleet: [1,2,0]`，看不到壳以为已经换过了。
        只追加、不覆盖，一天几十 KB。
        """
        try:
            path = paths.log_dir() / f"shell-{time.strftime('%Y%m%d')}.log"
            with path.open("a", encoding="utf-8") as fh:
                fh.write(f"{time.strftime('%H:%M:%S')} {msg}\n")
        except OSError:
            pass

    def set_status(self, text: str) -> None:
        """worker 线程只写这个属性，真正动界面交给主线程（见 `_drain`）。"""
        self._pending_status = text

    def _drain(self) -> None:
        # 先把 worker 留下的"待办"在主线程里应用掉 —— 跨线程调 root.after() 实测会抛
        # `RuntimeError: main thread is not in main loop`，所以一律走这里。
        if self._pending_status is not None:
            self.status.set(self._pending_status)
            self._pending_status = None
        if self._pending_stage_clear:
            self._pending_stage_clear = False
            self.stage.set("")
        if self._pending_busy is not None:
            busy = self._pending_busy
            self._pending_busy = None
            self._busy_now = busy
            # 谁在跑，谁就是蓝底大按钮；其余禁用变灰。闲着时三个长得一模一样。
            for btn, mode in ((self.btn_start, MODE_3STARS), (self.btn_oil, MODE_OIL),
                              (self.btn_rotate, MODE_ROTATE), (self.btn_daily, MODE_DAILY),
                              (self.btn_event, MODE_EVENT)):
                mine = busy and mode == self._running_mode
                btn.configure(style="Run.TButton" if mine else "TButton",
                              state="disabled" if busy else "normal")
            self.btn_stop.configure(state="normal" if busy else "disabled")
        if self._stages_ready and not self._stages_applied:
            self._stages_applied = True
            self._apply_stages()
        if self._pending_chip is not None:
            text, self._pending_chip = self._pending_chip, None
            self._set_chip(text)
        if self._pending_update is not None:
            found, self._pending_update = self._pending_update, None
            self._show_update(found)
        if self._pending_alas_alert is not None:
            name, why = self._pending_alas_alert
            self._pending_alas_alert = None
            self._alas_alert(name, why)
        if self._pending_alas_chip is not None:
            name, self._pending_alas_chip = self._pending_alas_chip, None
            self._set_chip(f"🔄 Alas 要更新才能刷「{name}」", self._open_update)
        if self._pending_fleet_alert:
            # **绝不能用 messagebox**（2026-10-28 用户要求）：它是模态的，会卡住主线程，
            # 而刷油在 worker 线程里照跑 —— 用户看到的就是"窗口假死但后台在动"，
            # 日志不刷新、停止点不动。改成卡片 + 左上角常驻那句，完全不阻塞。
            self._pending_fleet_alert = False
            self._set_chip("⏸ 编队检测为空，已退回 1-2 队", self._open_update)
            self._toast("编队检测为空",
                        "请确认编队情况。已先退回 1-2 队继续刷光石油。",
                        "想用轮换：先去游戏里配好第 3、4 队，再点「轮换刷油」。",
                        action_text="我知道了", seconds=20)
        if self._pending_toast is not None:
            title, body = self._pending_toast
            self._pending_toast = None
            self._toast(title, body, "", action_text="知道了", seconds=8)
        # 扫盘结果（线程写的）在主线程处理：找到就记住，没找到才问用户
        if self._alas_scan is not None:
            result, self._alas_scan = self._alas_scan, None
            if result.startswith("launcher:"):
                path = Path(result.split(":", 1)[1])
                # E3（2026-10-21 用户定）：**自动开始下载**，不弹"要不要" —— 用户装的就是启动器，
                # 剩下的"下载本体"由壳代劳，只显示进度窗。
                self.say(f"· 找到了 Alas 启动器：{path}")
                self.say("  · 正在让它自动下载 Alas 本体（第一次要几分钟，我会盯着）")
                if self._bootstrap_alas(path):
                    remember_install(path)
                    self.say(f"✔ 已自动配置好位于：{path}")
                else:
                    self.say("  · 没下载成功 —— 你可以手动双击那个文件夹里的 Alas.exe 跑一次")
                result = ""
            if result:
                remember_install(Path(result))
                self.say(f"✔ 找到 Alas 了：{result}")
            elif not self._alas_prompted:
                self._alas_prompted = True
                self._ask_alas_path(first=True)
        # worker 线程想让用户回答一个问题 → 在主线程里弹（跨线程直接弹 Tk 会崩）
        if self._prompt_req is not None:
            req, self._prompt_req = self._prompt_req, None
            if req.get("kind") == "info":
                messagebox.showinfo(req["title"], req["text"], parent=self.root)
            else:
                req["holder"]["ok"] = messagebox.askyesno(req["title"], req["text"],
                                                          parent=self.root)
            req["event"].set()
        # 包下好后**不自己重启**：卡片还在屏幕上，用户可能正在看那几行字，
        # 800 毫秒就闪一下等于白弹（2026-10-23 用户指出）。换不换由他点头
        # （`_apply_now`）；不点就下次开窗时换（`selfupdate.bootstrap`）。
        while True:
            try:
                msg = self.q.get_nowait()
            except queue.Empty:
                break
            tag = self._tag(msg)
            if tag in ("ok", "bad"):
                self._tone_color = self.OK if tag == "ok" else self.BAD
            self.txt.configure(state="normal")
            self.txt.insert("end", msg + "\n", tag)
            self.txt.see("end")
            self.txt.configure(state="disabled")
        # 状态点：在跑 = 主色（一眼看出没卡住）；停下来 = 看最后一次输赢，没输赢就灰的
        self._dot(self.ACCENT if self._busy_now else (self._tone_color or self.MUTED))
        self.root.after(POLL_MS, self._drain)

    def _busy(self, busy: bool) -> None:
        """同上：worker 只置个位，界面由主线程 `_drain` 改。"""
        self._pending_busy = busy

    # ---------------- 动作 ----------------
    def on_close(self) -> None:
        """关窗口时别把引擎丢在后台。

        2026-10-15 实测过这个坑：用户把窗口关了，Alas 还在后台自动打图 40 分钟 ——
        没人看着、也不知道它在干什么。
        """
        if self.box is not None and self.box.running():
            if not messagebox.askyesno("Alas 还在跑",
                                       "关掉窗口会连它一起停掉。确定要关吗？",
                                       parent=self.root):
                return
            self.cancelled = True
            self.box.stop()
        self.root.destroy()

    def _startup_check(self) -> None:
        """开窗后做三件小事：**拦住第二个小窗**、**清掉上一轮残留的引擎**、**找 Alas**。

        查进程要跑一次 PowerShell（几百毫秒），所以放线程里，不挡开窗；
        找 Alas 的结果要弹框（必须在主线程），所以它单独留在主线程。
        """
        # 找不到 Alas 就**真的去硬盘上找**（后台扫盘，别卡开窗）；找到直接用，找不到才问人
        found = find_install()
        if found:
            self.say(f"· 已连接 Alas：{found}")
            if not (found / "config" / "alas.json").exists():
                self.say("· 这台 Alas 还没启动过 —— 点按钮时我会自动帮它生成配置")
        else:
            self.say("· 正在你电脑上找 Alas（桌面 / 下载 / 我的文档 / 各个盘）…")

            def scan() -> None:
                hit = discover_install()
                if hit:
                    self._alas_scan = str(hit)
                    return
                # 找不到可用安装也没关系 —— 至少告诉用户"你只装了启动器"
                launcher = discover_launcher()
                self._alas_scan = f"launcher:{launcher}" if launcher else ""

            threading.Thread(target=scan, daemon=True).start()

        def work() -> None:
            # 两种启动方式都要认：exe 那版没有 -m，绿色包走的是 app\run.py（2026-10-20 加）
            found = {p for pat in ("-m onetap", "app\\run.py") for p in find_pids(pat)}
            found.discard(os.getpid())
            if found:
                self.say("⚠️ 助手已经开了一个窗口 —— 两个窗口会抢同一个模拟器，"
                         "先关掉那个再点这里。")
                return                                   # 有别的窗口就别动引擎，免得砍到它的腿
            try:
                pids = (self.box or AlasBox()).kill_stale()
            except (AlasError, OSError):
                return
            if pids:
                self.say("· 顺手停掉了上次没关干净的后台任务")

        threading.Thread(target=work, daemon=True).start()

    def on_start(self, mode: str = MODE_3STARS) -> None:
        """三个入口（一键三星 / 刷光石油 / 清日常）都走这里，只差一个 mode。"""
        if self.worker is not None and self.worker.is_alive():
            self.say("⚠️ 已经有一趟在跑了，先点「停止」")
            return
        # 轮换刷油第一次点：问一次"游戏里有没有第 3、4 队"（2026-10-27 用户定）。
        # 不问的话会白等：Alas 不检查编队是否为空，会一直重试到 10 分钟超时。
        if mode == MODE_ROTATE and not _rotate_ready():
            if not messagebox.askyesno(
                    "轮换刷油",
                    f"轮换刷油会每 {ROTATE_RUNS} 趟把编队从「1-2 队」换到「3-4 队」，再换回来。\n\n"
                    "请先确认：你在游戏里已经配好第 3、4 队了吗？\n"
                    "（没配好就换队，会卡在编队界面跑不起来）",
                    parent=self.root):
                self.say("· 好的，先不轮换 —— 配好第 3、4 队再点这个")
                return
            _rotate_remember()
        # 关卡默认留空（代号基本是限时活动关，瞎填一个反而误导），所以这里必须挡一下；
        # 「清日常」「活动每日」跟关卡无关，不用填。
        # 后台正在自动更新 Alas → 先别起任务：换代码的同一秒起引擎会撞车。
        if self._alas_auto_note:
            self.say(f"· 稍等一下 —— {self._alas_auto_note}")
            return
        if mode not in (MODE_DAILY, MODE_EVENT) and not self.stage.get().strip():
            self.say("· 先在上面填个关卡（活动 C2 / 主线 12-4），再点这个")
            self.stage_box.focus_set()
            return
        # 关卡先对着 Alas 的真实关卡表核一遍（2026-10-20 实测：用户填 11-7，主线每章只有 4 关）
        typed = self.stage.get().strip().upper()
        if (typed and self.all_stages
                and not any(same_stage(typed, s) for s in self.all_stages)):
            chapter = typed.split("-")[0]
            near = [s for s in self.all_stages if s.split("-")[0] == chapter][:8]
            self.say(f"· Alas 里没有「{typed}」这一关"
                     + (f"；第 {chapter} 章只有：{'、'.join(near)}" if near else "；下拉里挑一个吧"))
            self.stage_box.focus_set()
            return
        # 开跑前先确认 Alas 连得上（在主线程里问，别等 worker 跑到一半才发现）
        if find_install() is None and not self._ask_alas_path(first=True):
            self.say("· 先把 Alas 的位置指一下，再点开始")
            return
        self.txt.configure(state="normal")
        self.txt.delete("1.0", "end")
        self.txt.configure(state="disabled")
        self._last_said = ""            # 新一轮任务：去重记录清空（见 say）
        self._said_warn.clear()
        if self._update_found:                      # 清屏别把"有新版本"一起清掉
            self._show_update(self._update_found)
        self.cancelled = False
        self._hard = bool(self.hard.get())        # 主线程读一次，worker 用快照
        self._restored = False
        self._last_stuck = ""
        self._running_mode = mode                    # 让「在跑的那个」按钮变蓝（见 _drain）
        self._busy(True)
        # 只有三星要连推下一关；刷油是刷同一关，清日常跟关卡无关
        auto_next = self.auto_next.get() and mode == MODE_3STARS
        self.worker = threading.Thread(
            target=self._safe_pipeline,
            args=(self.stage.get(), auto_next, mode, self.hard.get()), daemon=True)
        self.worker.start()

    # ---------------- 更新 Alas（自动；失败才提醒）----------------
    def _auto_update_alas(self, box: AlasBox, manual: bool = False) -> None:
        """把 Alas 更新到最新（连新活动一起）。**默认全程不用用户点**（2026-10-23 用户定）。

        为什么敢自动：`alas_update.update()` 只做 git 换代码 —— 不动配置、不动 pip、
        不动模拟器的 adb；而且它自己有五道保险：找不到 git / Alas 正在跑 / 工作区有改动 /
        拉不下来 / 换完校验不过 → 一律停手不动。**停手了才提醒**，让用户自己决定。

        `manual=True` 是用户点卡片上「现在更新」的那次：把界面设成忙碌、跑完恢复。
        """
        if manual:
            self._pending_busy = True
        elif _auto_cooling():
            # 6 小时内已经失败过一次 → 不再自动重试，也**不再弹卡片**（弹过一次就够了，
            # 每开一次窗就弹一次是骚扰）。只在左上角留一句，点它才出来。
            self._pending_alas_chip = next(iter(self._missing_events.values()), "新活动")
            return
        names = "、".join(f"「{n}」" for n in self._missing_events.values()) or "新活动"
        self._alas_auto_note = f"Alas 正在更新（{names}），大概一分钟"
        self._pending_status = "正在更新 Alas…"
        # 先把**我们自己**打开过的设置页收掉：它背后是个用户看不见的 `python gui.py`，
        # 让他"关掉 Alas"等于让他关一个看不见的进程（2026-10-23 用户指出）。
        if box.gui_running() and box.close_gui():
            self.say("· 先关掉刚打开的 Alas 设置页（更新时两边不能同时动）")
        try:
            ok, msg = alas_update.update(box.root, say=self.say)
        except Exception as exc:                                  # noqa: BLE001
            ok, msg = False, f"更新 Alas 时出了意外：{exc}（把这条发给开发者）"
        self._alas_auto_note = ""
        self._pending_status = "待命"
        if manual:
            self._pending_busy = False
        if ok:
            _auto_remember("")                      # 成功 → 清掉冷却
            self.say(f"✔ {msg}")
            self.say("  · 新活动的关卡已经能选了（选具体哪一关，比如 A1 / C2）")
            self._pending_stage_clear = True
            self._pending_chip = ""                 # 左上角那句提醒收起来
            self._missing_events = missing_event_options(box.root)
            self.all_stages = box.stages()
            self._stages_applied = False            # 让主线程拿新列表重画一次
            if manual:
                self._pending_toast = ("Alas 更新好了",
                                       "新活动的关卡已经能选了，填个代号开始吧。")
            return
        _auto_remember(msg)                         # 失败 → 冷却 6 小时，别每开窗都试
        self.say(f"⚠️ 没自动更新 Alas：{msg}")
        self.say("  · 主线关卡不受影响，照常能刷")
        name = next(iter(self._missing_events.values()), "新活动")
        if manual:
            # 用户自己点的那次，要**当场给结果**（2026-10-23 要求："弹【已更新/更新失败】"）
            self._pending_toast = ("Alas 没更新成功", msg)
        else:
            self._pending_alas_alert = (name, msg)

    def _alas_alert(self, name: str, why: str) -> None:
        """Alas 没能自动更新 → 两层提醒（左上角渐变 + 右下角卡片），卡片上给「现在更新」。

        **卡片里不写技术原因**（2026-10-23 用户指出"自动更新没成功：Alas 现在还开着"
        这种句子不该给用户看）：`why` 只进日志，卡片只说"点一下就更新好"。
        """
        self._set_chip(f"🔄 Alas 要更新才能刷「{name}」", self._open_update)
        self._toast(f"Alas 要更新才能刷「{name}」",
                    "点「现在更新」把 Alas 更新好，只要一分钟。",
                    "只换 Alas 的程序文件：不动你的设置，也不动模拟器。",
                    action=self._force_alas_update, action_text="现在更新", seconds=15)

    def _force_alas_update(self) -> None:
        """卡片上那个「现在更新」：手动再跑一次（自动那次已经失败过，原因写在卡片里）。"""
        self._toast_close()
        if self.worker is not None and self.worker.is_alive():
            self.say("⚠️ 先等这一趟跑完，再更新 Alas")
            return
        try:
            box = self.box or AlasBox()
        except (AlasError, AlasMissing) as exc:
            self.say(f"❌ {exc}")
            return
        self.box = box
        self.cancelled = False
        self._running_mode = ""
        threading.Thread(target=self._auto_update_alas,
                         args=(box, True), daemon=True).start()

    def on_stop(self) -> None:
        self.cancelled = True
        if self.box is not None:
            self.box.stop()
        # 如果 worker 正卡在"等用户回答"的弹框上，替它回答"否"，别让它一直挂着
        req = self._prompt_req
        if req is not None:
            req["holder"]["ok"] = False
            req["event"].set()
        self.say("⏹ 已请求停止")
        if self.worker is not None and self.worker.is_alive():
            # 还在等你上一步收尾（比如重启模拟器）→ 别把按钮放开，否则会连点重复触发
            self.set_status("正在停止…")
            return
        self.set_status("已停止")
        self._busy(False)

    def on_pick_alas(self) -> None:
        self._ask_alas_path()

    def _show_alas_download(self, open_browser: bool = True) -> None:
        """告诉用户去哪下 Alas —— 光说"去装"是没用的（2026-10-20 新机实测：用户卡在这一步）。

        地址来自线上表（`alas.url`），改文案/换镜像不用发版；壳只指路，**不打包也不分发** Alas。
        """
        url, note = update.alas_download()
        self.say("· Alas 要你自己装（助手不包含它），下载页：")
        self.say(f"  {url}")
        self.say(f"  {note}")
        self.say("· 装好后点「选 Alas 文件夹」，选到里面的 AzurLaneAutoScript 那一层（有 alas.py）")
        if open_browser and messagebox.askyesno(
                "打开下载页？", f"现在用浏览器打开：\n{url}", parent=self.root):
            webbrowser.open(url)

    def _ask_alas_path(self, first: bool = False) -> bool:
        """让用户指一下 Alas 装在哪儿。返回**最后是否已经可用**。

        **为什么必须问**：Alas 是用户自己装的（别的整合包 / 自己解压），装在哪个盘、哪一层
        只有他知道 —— 壳里那几个候选路径只对开发机有意义。问一次、记住（`alas-path.txt`），
        以后不再问；挪了位置还能再点「选 Alas 文件夹」。
        """
        if first:
            answer = messagebox.askyesnocancel(
                "需要先连接 Alas",
                "这个助手要和 Alas 碧蓝航线脚本配合使用（助手不包含 Alas）。\n\n"
                "初步搜索暂未搜索到 Alas。\n\n"
                "· 已经装好了 → 点「是」，手动选 Alas 所在的文件夹\n"
                "   （选外层也行，我会自己往下找）\n"
                "· 还没安装 Alas → 点「否」，我给你下载地址\n",
                parent=self.root)
            if answer is None:           # 取消 = 先不处理
                return False
            if answer is False:          # 没装 → 直接给下载页（2026-10-20 新机实测卡在这）
                self._show_alas_download()
                return False
        path = filedialog.askdirectory(
            title="选 Alas 文件夹（里面要有 alas.py，通常在 …\\AlasApp_x.x\\AzurLaneAutoScript）",
            parent=self.root)
        if not path:
            return False
        root = Path(path)
        found = find_root_under(root)          # 往下两层找（用户的布局各不相同）
        if found is None and root.parent != root:
            found = find_root_under(root.parent)   # 选到 deploy 这种子目录时，往上找一层
        if found is None:
            # 最常见的一种：只装了启动器，本体还没下载 → **直接自动下载**（E3，2026-10-21 用户定）
            target = root if is_launcher_only(root) else (
                root.parent if is_launcher_only(root.parent) else None)
            if target is not None:
                if self._bootstrap_alas(target):
                    root = target
                    found = target
            if found is None:
                messagebox.showwarning("连接不上 Alas",
                                       diagnose_dir(root) + f"\n\n你选的是：{root}",
                                       parent=self.root)
                return False
        root = found
        remember_install(root)
        self.box = None                       # 下次用新路径重新找
        self.say(f"✔ 记住了 Alas 的位置：{root}")
        if not (root / "config" / "alas.json").exists():
            self.say("· 这台 Alas 还没启动过 —— 点按钮时我会自动帮它生成配置")
        return True

    def _bootstrap_alas(self, root: Path) -> bool:
        """调起 Alas 的启动器，等它把**本体**下载好，再关掉它。

        "跑一次"= 让启动器完成首次下载/初始化，**不需要用户去点任何界面**（2026-10-20 用户提出）。
        判据是 `module\\` 出现（Alas 的代码主体）；中途可以取消（启动器留在后台继续下载）。
        """
        launcher = next((root / name for name in ("Alas.exe", "console.bat")
                         if (root / name).exists()), None)
        if launcher is None:
            self.say("· 这个文件夹里没有 Alas.exe，没法自动配置")
            return False
        try:
            proc = subprocess.Popen([str(launcher)], cwd=str(root), **no_console())
        except OSError as exc:
            self.say(f"❌ 打不开 Alas 的启动器：{exc}")
            return False

        win = tk.Toplevel(self.root)
        win.title("正在自动配置 Alas")
        win.transient(self.root)
        win.grab_set()
        win.resizable(False, False)
        ttk.Label(win, text="正在让 Alas 下载本体，请稍等（第一次可能几分钟）…").pack(
            padx=26, pady=(22, 10))
        bar = ttk.Progressbar(win, mode="indeterminate", length=340)
        bar.pack(padx=26)
        bar.start(60)
        status = tk.StringVar(value="不用管它，完成后会自动关闭")
        ttk.Label(win, textvariable=status, style="CardMuted.TLabel").pack(padx=26, pady=(10, 14))
        state = {"ok": False, "stop": False, "start": time.time()}

        def close() -> None:
            try:
                win.grab_release()
                win.destroy()
            except tk.TclError:
                pass

        def cancel() -> None:
            state["stop"] = True
            self.say("· 不等了 —— Alas 会继续在后台下载，好了再点「选 Alas 文件夹」")
            close()

        ttk.Button(win, text="取消等待", style="Small.TButton", command=cancel).pack(pady=(0, 18))

        def tick() -> None:
            if has_code(root):
                state["ok"] = True
                close()
                return
            if state["stop"]:
                return
            waited = int(time.time() - state["start"])
            if waited > 1800:
                state["stop"] = True
                self.say("· 等了 30 分钟还没下载完 —— 让 Alas 继续，装好后再点「选 Alas 文件夹」")
                close()
                return
            status.set(f"已等 {waited} 秒…（完成后会自动关闭）")
            win.after(1000, tick)

        win.after(1000, tick)
        self.root.wait_window(win)          # 阻塞到窗口关闭（Tk 事件照常跑，进度条会动）
        if not state["ok"]:
            return False
        for name in ("taskkill",):
            try:
                subprocess.run([name, "/PID", str(proc.pid), "/T", "/F"],
                               capture_output=True, timeout=20, cwd=SAFE_CWD,
                               **no_console())
            except (OSError, subprocess.SubprocessError):
                pass
        self.say("✔ 已自动配置连接完成，现在可以使用啦")
        messagebox.showinfo("配置完成", "Alas 已经就位，现在可以使用了。", parent=self.root)
        return True

    def _info_blocking(self, title: str, text: str, timeout: float = 600) -> None:
        """worker 线程里"告诉用户一句话并等他点确定"：交给主线程弹框。"""
        holder = {"ok": True}
        event = threading.Event()
        self._prompt_req = {"title": title, "text": text, "holder": holder,
                            "event": event, "kind": "info"}
        event.wait(timeout)

    def _ask_blocking(self, title: str, text: str, timeout: float = 600) -> bool:
        """worker 线程里"问用户一句话"：交给主线程弹框，等它回答。"""
        holder = {"ok": False}
        event = threading.Event()
        self._prompt_req = {"title": title, "text": text, "holder": holder,
                            "event": event, "kind": "yesno"}
        if not event.wait(timeout):
            self._prompt_req = None
            return False
        return holder["ok"]

    def _ensure_resolution_ui(self, mumu: MuMu, serial: str) -> tuple[bool, str]:
        """分辨率不是 720p 时**不动机器**，弹框让用户自己改一次（2026-10-20 用户拍）。

        为什么不再自动关掉重开：MuMu 关掉后经常起不来（实机2 卡了一晚上），
        而且"改配置"在不同版本上并不生效 —— 代价远大于让用户手动改一次。
        """
        size = mumu.screen_size(serial)
        if mumu.is_720p(size):
            return True, ""
        for _ in range(2):
            if not self._ask_blocking(
                    "需要把模拟器分辨率改成 1280×720",
                    f"MuMu 现在的画面是 {size}，但 Alas 只认 1280×720。\n\n"
                    "请在 MuMu 里改（只需要做一次）：\n"
                    "  右上角「设置」→「显示」→ 分辨率 → 选「平板 / 1280×720」\n\n"
                    "改完重启模拟器，改好了点「是」，我重新检查。"):
                return False, "分辨率不是 1280×720"
            size = mumu.screen_size(serial)
            if mumu.is_720p(size):
                return True, "分辨率已经是 1280×720"
        return False, (f"画面还是 {size or '读不到'}，不是 1280×720 —— "
                       "改完要让这台模拟器重新启动一次才会生效")

    def on_open_alas(self) -> None:
        try:
            url = (self.box or AlasBox()).open_gui()
        except AlasError as exc:
            self.say(f"❌ {exc}")
            return
        self.say(f"已打开 Alas 设置：{url}")
        self.say("（界面要几秒才起来；没自动弹出就把上面这个网址粘到浏览器）")
        self.say("⚠️ 别在 Alas 界面里点「启动」，否则会导致工具或 Alas 异常")
        threading.Timer(4.0, lambda: webbrowser.open(url)).start()

    def on_unpark(self) -> None:
        """还原：**把 Alas 的设置放回壳动它之前的样子**（你想回 Alas 自己界面时用）。

        名字特意点明动的是 Alas —— 只说「还原配置」会被误读成"清空助手自己的设置"（用户 2026-10-15 指出）。
        """
        try:
            box = self.box or AlasBox()
            waiting = box.parked_count()
        except AlasError as exc:
            self.say(f"❌ {exc}")
            return
        if not waiting:
            self.say("· 没有需要还原的（要么还没改过 Alas 的设置，要么已经还原过了）")
            return
        if not messagebox.askyesno(
                "还原 Alas 初始配置",
                f"把 Alas 的设置放回「这个助手改之前」的样子？（共 {waiting} 处）\n\n"
                "助手为了不让推关被打断，会临时顶掉其它任务的时间、关掉心情控制 ——\n"
                "这个按钮就是把它们放回去。助手自己的设置和日志不受影响。",
                parent=self.root):
            return
        try:
            done = box.unpark_all()
        except AlasError as exc:
            self.say(f"❌ {exc}")
            return
        self.say(f"✔ 已还原 {done} 处 —— Alas 恢复成助手没动过的样子")
        self.say("（助手自己的设置和日志不受影响；再点「一键三星」会重新设一次，那是必须的）")

    # ---------------- worker ----------------
    def _safe_pipeline(self, stage: str, auto_next: bool, mode: str, hard: bool = False) -> None:
        try:
            self._pipeline(stage, auto_next, mode, hard)
        except AlasMissing as exc:
            # 只有"压根没找到 Alas"才给下载指引（2026-10-20 新机实测卡在这一步）
            self.say(f"❌ {exc}")
            self._show_alas_download(open_browser=False)
            self.set_status("出错")
        except AlasError as exc:
            # 找到 Alas 了，但配置/版本有问题 —— 只说要做什么，别再甩下载链接
            self.say(f"❌ {exc}")
            self.set_status("出错")
        except MuMuError as exc:
            self.say(f"❌ {exc}")
            self.set_status("出错")
        except Exception as exc:                                  # noqa: BLE001
            self.say(f"❌ 出了点意外：{exc}（把这条发给开发者）")
            self.set_status("出错")
        finally:
            self._busy(False)

    def _pipeline(self, stage: str, auto_next: bool, mode: str, hard: bool = False) -> None:
        # ── 0. 先确认 Alas 能用（缺配置就自动生成，缺文件夹就别去动模拟器了）──────
        # 2026-10-20 新机实测：以前先改了模拟器一堆设置，最后才报"缺 alas.json"；
        # 而且要用户自己去开一次 Alas —— 那是把壳的意义抹掉了。
        self.box = AlasBox()
        note = self.box.ensure_config()
        if note:
            self.say("  " + note)
        self.box.read_config()

        # ── 1. 把门打开（MuMu 侧）──────────────────────────────
        self.set_status("检查模拟器…")
        mumu = MuMu()
        index = mumu.pick_index()
        if index is None:
            # 一台都没开：**不替用户启动**（2026-10-20 用户拍）。
            # 自动启动这条路在真机上反复出问题（关了起不来 / 起错实例 / 卡在启动中），
            # 让用户自己开一次，比我们赌 MuMu 的启动行为稳得多。
            self.say("· 没检测到开着的模拟器")
            self._info_blocking(
                "先打开模拟器",
                f"请先打开 MuMu 并进到游戏里，然后再点一次"
                f"「{MODE_LABELS.get(mode, '一键三星')}」哦。")
            raise MuMuError("先打开模拟器再点")
        save_index(index)        # 记住这台，下次开窗时优先认它
        running = mumu.running()
        if mumu.game_running(index):
            self.say("· 用你正在玩的那台模拟器")
        elif len(running) > 1:
            self.say(f"· 用第 1 台模拟器（MuMu 里有 {len(running)} 台开着，"
                     "没看出哪台在跑碧蓝）")
        else:
            self.say("· 找到模拟器了")

        for note in mumu.align_env(index):
            self.say(f"  ✔ {note}")

        # ── 2. 按住开始（Alas 侧）──────────────────────────────
        self.say("· 用的是你电脑上已装好的 Alas")
        note = version_note(self.box.root, update.alas_broken())
        if note:
            self.say("  ⚠️ " + note)
        note = stale_alas_note(self.box.root)
        if note:
            self.say("  ⚠️ " + note)

        # 序列号必须跟着实例走（2026-10-15 实测坑）：实例换了而 Alas 配置没换，
        # 它会连 4 分钟然后 `Request human takeover` 退出，用户看到的是"点了没反应"。
        serial = mumu.serial_for(index)
        if serial:
            self.say(f"  ✔ {self.box.set_emulator_serial(serial)}")
            ok, note = mumu.ensure_adb(serial)       # 开跑前确认真连得上，能修就修
            if note:
                self.say(f"  {'✔' if ok else '⚠️'} {note}")
            if not ok:
                # 模拟器重启过的话 adb 端口会变 —— 重新读一次 MuMu 的权威表再试
                fresh = mumu.serial_for(index)
                if fresh and fresh != serial:
                    serial = fresh
                    self.say(f"  · 模拟器的 adb 端口变了，改用 {fresh} 再试一次")
                    self.box.set_emulator_serial(serial)
                    ok, note = mumu.ensure_adb(serial)
                    if note:
                        self.say(f"  {'✔' if ok else '⚠️'} {note}")
            if not ok:
                raise MuMuError("模拟器连不上，这一趟先不跑")

            # 分辨率：**不动机器**，让用户自己改一次（自动关掉重开常常起不来，见 _ensure_resolution_ui）
            ok, note = self._ensure_resolution_ui(mumu, serial)
            if note:
                self.say(f"  {'✔' if ok else '⚠️'} {note}")
            if not ok:
                if self.cancelled:
                    return
                raise MuMuError("模拟器画面尺寸不是 1280×720，这一趟先不跑")
        else:
            self.say("  ⚠️ 认不出你正在玩的那台模拟器，可能会连不上")

        if self.box.gui_running():
            self.say("  ⚠️ 你的 Alas 界面正开着 —— 别在那边点「启动」，否则会导致工具或 Alas 异常")
        self.say("· 石油少于 500 它不会开始，会往后等几小时")

        # ── 3. 跑 ────────────────────────────────────────────
        if mode == MODE_DAILY:
            self._daily()
            return
        if mode == MODE_EVENT:
            self._event_daily()
            return
        if auto_next:
            self._chain(stage, hard=hard)
        else:
            if mode == MODE_OIL:
                self.say("· 刷光石油：一直刷到石油不足 500 才停")
                # 建议只放在刷油这边 —— 三星模式本来就不用自律寻敌（见 humanize 里那句注释）
                self.say("· 这张图要是还没打成三星，它会一趟趟进出；先用「一键三星」打完，"
                         "之后刷油就能连续刷")
            if mode == MODE_ROTATE:
                self.say(f"· 轮换刷油：每 {ROTATE_RUNS} 趟打完换一组编队"
                         "（在回港那一刻换，不浪费油）")
            # 轮换模式：一批刷完 → 换队 → 再来一批，直到油光或你点停止
            for _round in range(MAX_OIL_ROUNDS):
                # 换过队的那次：只等「90 秒内进图」，进图之后按正常节奏跑（600 秒判死）
                ok = self._stage(stage, mode=mode, hard=hard,
                                 retry=(_round == 0),
                                 first_map_s=(0 if _round == 0 else ROTATE_SILENT_S))
                if self.cancelled or mode != MODE_ROTATE or self._oil_done:
                    break
                if not ok:
                    # 换过队还跑不起来 → 先按日志证据分原因（2026-10-28 用户定）
                    if _round == 0:
                        break
                    if self._last_stuck not in ("silent", "adb", "game", "no_map"):
                        # 船坞满 / 被别的任务叫走 / 打错图 —— 这些**不是换队的问题**，
                        # 有自己的提示（见 `_run_once` 里各分支），别错怪成"编队空"。
                        break
                    if self._last_stuck in ("adb", "game"):
                        # 能修的：模拟器掉线 / 游戏卡死 → 再试一次
                        self.say("  ↻ 换队后没进图，看起来是临时问题，再试一次")
                        if self._last_stuck == "adb":
                            self._reconnect_adb()        # 掉线必须先重连，光重试没用
                        ok = self._stage(stage, mode=mode, hard=hard, retry=False,
                                         silent_s=ROTATE_SILENT_S)
                        if ok:
                            continue                     # 进去了 → 用 3-4 队接着刷
                    # 到这里 = 重试也没用（或没明确错误，多半是编队空）
                    self._restore_fleets(self._last_stuck)
                    if self._restored:
                        break                            # 已经退回过一次还失败 → 停手
                    self._restored = True
                    if self._last_stuck not in ("adb", "game"):
                        # 只有"疑似编队空"才弹那张卡片；掉线/卡死的指引已经在上面说了
                        self._pending_fleet_alert = True
                    continue                             # 用 1-2 队继续刷
                if self._restored:
                    break                                # 已经退回过一次 → 本次就用 1-2 队刷完
                if not self._rotate_once():
                    break
            if not self.cancelled:
                self.set_status("结束")

    # ---------------- 轮换刷油（2026-10-27）----------------
    def _rotate_once(self) -> bool:
        """一批刷完（RunCount 用尽）：换一组编队。返回 True = 已换好、可以再刷一批。

        **零浪费**：Alas 是在"一趟打完回港"时自己停的（`run.py:444-457`），
        不是我们杀进程 —— 所以不会有"停在图里、油白花"的情况。
        """
        if self.box is None:
            return False
        one, two = 1, 0
        try:
            one, two = self.box.fleets()
            nxt = rotate_fleets(one, two)
            notes = self.box.switch_fleets(*nxt)
        except (AlasError, OSError) as exc:
            self.say(f"  ⚠️ 换队没成功：{exc}（继续用 {_fleet_label(one, two)}）")
            return False
        self.say(f"  ↻ 这批刷完了，换到 {_fleet_label(*nxt)}"
                 f"（{'、'.join(notes) or '配置已更新'}）")
        return True

    def _restore_fleets(self, stuck: str) -> None:
        """把编队退回 1-2 队 —— 免得配置停在"游戏里不存在的那组"上，下次开刷直接卡住。

        只在**换队之后跑不起来**时调用（多半是用户没有第 3、4 队）。调用方保证
        不会在正常流程里误触：`_pipeline` 里只有 `_round > 0` 才走这里。
        """
        if self.box is None:
            return
        try:
            one, two = self.box.fleets()
            if one <= 2:
                return
            self.box.switch_fleets(1, 2)
        except (AlasError, OSError):
            return
        # **必须说清为什么退回**（2026-10-28 用户要求）：不同原因后续要做的事完全不同。
        if stuck == "adb":
            self.say("  ↻ 已退回 1-2 队 —— 换过去之后**模拟器掉线了**，不是编队的问题")
            self.say("     把 MuMu 恢复正常（必要时重启一次），再点「轮换刷油」")
        elif stuck == "game":
            self.say("  ↻ 已退回 1-2 队 —— 换过去之后**游戏卡住了**，不是编队的问题")
            self.say("     看一眼游戏画面（多半有个弹窗），处理好再点「轮换刷油」")
        else:
            self.say("  ↻ 已退回 1-2 队 —— 第 3、4 队**没能进图**，多半是这两个编队还是空的")
            self.say("     在游戏里配好第 3、4 队，再点「轮换刷油」")
        _rotate_forget()          # 作废"已确认"，下次点会重新问一遍，不会每批都栽

    # ---------------- 推关 ----------------
    def _chain(self, first: str, hard: bool = False) -> None:
        """打完自动下一关 —— 这一圈得壳来转。

        Alas 的「向前开荒」只会把配置里的关卡**推进**到下一关
        （`module/handler/fast_forward.py:438-448`），它自己**不会接着跑** ——
        那是调度器的活，而壳走的是单任务入口、没有调度器。
        所以壳在外面循环，判断依据是两个现成的值：
          `Scheduler_Enable` 被 Alas 置 false → 没下一关了，全部推完
          `Campaign_Name` 变了              → 达成并推进，继续下一轮
          `Campaign_Name` 没变              → 这一趟没达成，停下
        """
        stage = (first or "").strip().upper()
        done: list[str] = []
        for round_no in range(1, MAX_ROUNDS + 1):
            if self.cancelled:
                break
            self.say(f"── 第 {round_no} 关：{stage} ──")
            if not self._stage(stage, chain=True, hard=hard):
                self.say(f"  ⚠️ {stage} 这一趟没跑成 → 推关到此为止（原因看上面）")
                break
            done.append(stage)

            new_stage, enabled = (self.box.read_task_state(task_for(stage))
                                  if self.box else ("", False))
            if not enabled:
                self.say(f"  🏁「{stage}」已是最后一关，全部推完")
                break
            if new_stage.strip().upper() == stage:
                self.say("  （这一关没达成，先停下）")
                break
            stage = new_stage.strip().upper()
        else:
            self.say(f"（已连推 {MAX_ROUNDS} 关，先停下，防止无限跑）")

        self.say("─" * 30)
        if done:
            self.say(f"✅ 本轮共推完 {len(done)} 关：" + "、".join(done))
            self.set_status(f"推完 {len(done)} 关")
        else:
            self.say("本轮没有推完任何一关")
            self.set_status("结束")

    # ---------------- 清日常 ----------------
    def _daily(self) -> None:
        """清日常：那几个任务**一个一个**跑（每个起一次 Alas）。

        为什么只能壳来串：`run('<任务>')` 每次只跑一个任务、不查队列（`alas.py:65-70`），
        而我们看到的"打完一趟又起一趟"是 `CampaignRun.run()` **内部**自己的循环 ——
        跟清日常没关系（见 `_run_task.py` 的注释）。
        """
        assert self.box is not None
        self.box.set_daily()      # 配置细节不写进界面（用户不需要看 Alas 的参数名）
        self.say("  · 已经帮你排好顺序了（你不用管）")
        done: list[str] = []
        skipped: list[str] = []
        for task, label in DAILY_TASKS:
            if self.cancelled:
                break
            self.say(f"── {label} ──")
            self.set_status(f"清日常：{label}")
            # 第一个任务要登录 / 开游戏，实测比后面几个慢 → 给它更宽的时限
            timeout = DAILY_FIRST_TIMEOUT_S if not done and not skipped else DAILY_TIMEOUT_S
            (done if self._run_daily_task(task, label, timeout) else skipped).append(label)
        self.say("─" * 30)
        if self.cancelled:
            return
        self.say(f"清日常完成：{len(done)}/{len(DAILY_TASKS)} 成功"
                 + (f"（跳过：{'、'.join(skipped)}）" if skipped else ""))
        self.set_status(f"日常清完 {len(done)}/{len(DAILY_TASKS)}")

    def _event_daily(self) -> None:
        """活动每日：A/B/C/D/SP 各打一次 —— Alas 自带的「每日三倍」任务，我们不发明逻辑。

        为什么单独一个入口（2026-10-19 用户拍）：活动期间**每天必须做**，漏一天就少一次三倍，
        比刷油更硬；而且它很慢（每个图的每个小关一趟），混进「清日常」会把 5 分钟的日常拖成半小时。
        """
        assert self.box is not None
        folder, date = self.box.pick_event()
        self.say(f"· 现在开的活动：{date}（Alas 里叫 {folder}）")
        for note in self.box.set_event_daily(folder):
            self.say(f"  ✔ {note}")
        self.say("  · 每个图会把该图的「每日三倍」小关各打一趟，慢的话要十几分钟")
        done: list[str] = []
        skipped: list[str] = []
        for task, label in EVENT_DAILY:
            if self.cancelled:
                break
            self.say(f"── 活动 {label} ──")
            self.set_status(f"活动每日：{label}")
            # 第一个任务包含登录 / 开游戏，给它更宽的时限
            timeout = DAILY_FIRST_TIMEOUT_S if not done and not skipped else EVENT_TIMEOUT_S
            (done if self._run_daily_task(task, label, timeout) else skipped).append(label)
        if self.cancelled:
            return
        self.say("─" * 30)
        self.say(f"活动每日完成：{len(done)}/{len(EVENT_DAILY)} 成功"
                 + (f"（跳过：{'、'.join(skipped)}）" if skipped else ""))
        if skipped:
            self.say("  跳过的图多半是没解锁 / 没有 SP / 这趟太慢；下次点「活动每日」会重新打一遍")
        self.set_status(f"活动每日 {len(done)}/{len(EVENT_DAILY)}")

    def _run_daily_task(self, task: str, label: str,
                        timeout_s: float = DAILY_TIMEOUT_S) -> bool:
        """跑一个日常任务：起一次 Alas，等它退出。返回「是否正常」。

        判定**故意做得很浅**（见 `一键三星_需求记录.md` 的 B4 设计）：
          正常退出 + 日志里没有 `CRITICAL` / `RequestHumanTakeover` → ✅
          超过 `timeout_s` 还没退出 → 停掉、⚠️ 跳过，继续下一个
        **不逐个任务研究"完成标志"** —— 那几个标志各不相同，逐个研究就是复利增长的债。
        跟读手法和 `_run_once` 是同一套（那边带刹车判据，所以没合并）。
        """
        assert self.box is not None
        log_path = self.box.log_file()
        offset = log_path.stat().st_size if log_path.exists() else 0
        started = time.time()
        proc = self.box.start(task)

        collected: list[str] = []

        def feed(line: str) -> None:
            collected.append(line)
            if len(collected) > FEED_LINES:
                del collected[:FEED_LINES // 4]
            human = translate(line)
            if human:
                self.say("  " + human)

        # 第一次运行时日志文件可能还没建出来
        deadline = time.time() + 20
        while not log_path.exists() and time.time() < deadline:
            time.sleep(TAIL_INTERVAL)

        killed = False
        pos, rest = offset, b""
        while True:
            if time.time() - started > timeout_s:
                self.box.stop()
                killed = True
            chunk = b""
            if log_path.exists():
                try:
                    with log_path.open("rb") as fh:
                        fh.seek(pos)
                        chunk = fh.read()
                except OSError:
                    chunk = b""
            if chunk:
                pos += len(chunk)
                rest += chunk
                *whole, rest = rest.split(b"\n")
                for raw in whole:
                    feed(raw.decode("utf-8", "ignore") + "\n")
                continue
            if proc.poll() is not None or killed:
                break
            time.sleep(TAIL_INTERVAL)

        if rest.strip():
            feed(rest.decode("utf-8", "ignore") + "\n")
        proc.wait()

        raw = "".join(collected)
        self._dump_raw(raw)
        took = time.time() - started

        if self.cancelled:
            self.say("  ⏹ 没跑完就停了")
            return False
        if killed:
            self.say(f"  ⚠️ {label}：超过 {int(timeout_s / 60)} 分钟没结束，已停掉、跳过")
            return False
        if "CRITICAL" in raw or "RequestHumanTakeover" in raw:
            self.say(f"  ⚠️ {label}：它报错了，跳过去下一个")
            return False
        self.say(f"  ✅ {label}（{took:.0f} 秒）")
        return True

    def _reconnect_adb(self) -> bool:
        """模拟器掉线时的自动重连：重读 MuMu 端口 → 写进 Alas 配置 → 重启 adb 再连。

        为什么必须**重读端口**：MuMu 多开 / 切换实例时 adb 端口会变
        （2026-10-28 实测：用户双开操作后 16416 掉线、16384 消失），
        拿旧地址重试多少次都没用。
        """
        if self.box is None:
            return False
        try:
            mumu = MuMu()
            index = mumu.pick_index()
            if index is None:
                return False
            serial = mumu.serial_for(index)
            if not serial:
                return False
            self.box.set_emulator_serial(serial)
            ok, note = mumu.ensure_adb(serial)
        except (MuMuError, AlasError, OSError):
            return False
        if note:
            self.say(f"    {'✔' if ok else '⚠️'} {note}")
        return ok

    def _stage(self, stage: str, chain: bool = False, mode: str = MODE_3STARS,
               hard: bool = False, retry: bool = True,
               silent_s: int = STUCK_SILENT_S, first_map_s: int = 0) -> bool:
        """跑一关：最多两趟。返回「这一趟是不是正常收尾」。

        `mode` 只决定"停在哪"（见 `AlasBox.set_stage`）：
          `MODE_3STARS` → 返回「是否达成 100%通关 + 三星」
          `MODE_OIL`    → 返回「是否刷到油不足而正常收工」

        **卡住会自动重试一次** —— Alas 的走位/看图偶发会错位
        （实测同一天同一张 C3：19:18 那次正常在打，21:53 那次卡死 40 分钟、一步没走成），
        换一趟全新的地图状态值得再试；两趟都跑废，才把这一关交给用户手动过。
        **只重试"假死"**（`'silent'`）和**"Alas 转去处理别的任务"**（`'called:X'`，见下）——
        `'white'`（连跑两趟一架都没打成）和 `'runs'`（已经刷到趟数上限）再跑就是白跑/白烧油。

        `'called:X'`：Alas 见到"委托完成"这类提示会 `task_stop` 并把任务 X 叫起来
        （`module/campaign/run.py:355-366`）。**调度器模式下它跑完 X 会自己回来，我们走单任务入口
        没有调度器** —— 所以壳替它补这一步：先把 X 跑掉，再重试本关（2026-10-16 用户实测 10-3
        撞到这个：日志里 `Task call: Commission` 之后就退出了，壳当时报"没进到图里"）。
        """
        for attempt in ((1, 2) if retry else (1,)):
            ok, stuck = self._run_once(stage, chain=chain, attempt=attempt, mode=mode,
                                       hard=hard, silent_s=silent_s,
                                       first_map_s=first_map_s)
            if self.cancelled:
                return ok
            if stuck == "adb" and attempt < 2:
                # 掉线不是"再跑一趟"能解决的 —— 得先把连接修好（2026-10-28 用户提）
                self.say("  ↻ 模拟器掉线了，先帮你重连一下")
                if self._reconnect_adb():
                    self.say("  ↻ 连上了，再跑一趟")
                    continue
                self.say("  ⚠️ 重连也没成功 —— 重启一次 MuMu 再点")
                return False
            # `retry=False`（换队后那次）只有一轮 —— 别打印"再跑一趟"却没跑，那是假话
            if stuck == "silent" and retry and attempt < 2:
                self.say(f"  ↻ {stage} 卡了一下，自动再跑一趟")
                continue
            if stuck.startswith("called:") and retry and attempt < 2:
                task = stuck.split(":", 1)[1]
                label = _task_label(task)
                self.say(f"  ✓ 顺路收一下「{label}」（约 1 分钟），收完自动回到 {stage}")
                self._run_daily_task(task, label, DAILY_TIMEOUT_S)
                continue
            if stuck.startswith("called:"):
                # 两次都是被同一个东西叫走 → 它会一直把 Alas 抢走，得人去处理
                label = _task_label(stuck.split(":", 1)[1])
                self.say(f"  ⚠️ {stage} 还是进不去：Alas 一直被「{label}」叫走（处理完又冒出来）")
                self.say("     先把游戏里那个提示处理掉，再点一次刚才那个按钮")
                return False
            return ok
        return False

    def _run_once(self, stage: str, chain: bool = False, attempt: int = 1,
                  mode: str = MODE_3STARS, hard: bool = False,
                  silent_s: int = STUCK_SILENT_S, first_map_s: int = 0) -> tuple[bool, str]:
        """跑一趟。返回 `(是否达成, 卡住的类型)`，没卡住时类型是空串。

        日志来源是 **Alas 自己的文件日志**，不是 stdout —— 理由见 `AlasBox.log_file()`。
        """
        assert self.box is not None
        task = task_for(stage)          # 引擎要跑的任务，必须和 set_stage 配置的是同一个
        # 配置细节不写进界面（用户不需要看 Alas 的参数名）；要排查就看 AAS 自己的日志
        real_mode = MODE_OIL if mode == MODE_ROTATE else mode
        self.box.set_stage(stage, stage_increase=chain, mode=real_mode, hard=hard,
                           run_count=ROTATE_RUNS if mode == MODE_ROTATE else 0)
        self.say(f"  · 已按「{stage} · {MODE_LABELS.get(mode, '三星')}"
                 f"{' · 困难' if hard and task == MAIN_TASK else ''}」"
                 "帮你调好设置（你不用管）")
        # 开跑前校验：配置里那个任务的关卡名，必须真的是我要打的这一关。
        # 2026-10-15 实测踩过：配置写对了（Main/14-1），引擎却去跑了活动图
        # （启动脚本没拿到任务名，默认跑了 Event）→ Alas 报 `Map file not found ... extra`。
        # 这一条能挡住"配置 vs 引擎"不一致的**整类**问题，成本只有一次读配置。
        written, _ = self.box.read_task_state(task)
        if written.strip().upper() != stage:
            raise AlasError(f"配置没写进去：{task}.Campaign.Name = {written!r}，"
                            f"我要打的是 {stage!r}，先不动手")
        self.set_status(f"运行中：{stage}")

        log_path = self.box.log_file()
        offset = log_path.stat().st_size if log_path.exists() else 0
        # ⚠️ 必须把任务名传给启动脚本 —— 不传它默认跑 `Event`
        # （2026-10-15 实测踩到：壳写了 Main 的配置、引擎却去跑活动图，
        #  Alas 报 `Map file not found: campaign.event_20250520_cn.extra` → 人介入退出。
        #  跑活动关时靠巧合能通，跑主线关必炸。）
        proc = self.box.start(task)

        collected: list[str] = []
        hit_checked = False
        started_at = time.time()      # 引擎启动时刻（换队后的"进图超时"从这里算）
        last_progress = time.time()   # 最近一次"值得说"的进度
        # 趟数只在**下一趟进图重读星数之后**才算数（`pass_done` 是"这一趟打完了、等对账"）：
        # 重读那一刻正是 Alas 自己去判"能不能收工"的时刻，所以踩在这儿刹车
        # 永远不会抢在它宣布三星前面（代价也只有刚进图那几秒）。
        runs = 0                      # 已经打完并且对过账的趟数
        pass_done = False             # 这一趟打完了（看了 CAMPAIGN END），还没等到下一次星数重读
        fought = False                # 这一趟有没有真的打过架（清了小怪 / 打了 BOSS）
        white_runs = 0                # 打完的趟数里，几趟是"白跑"（一架都没打成）
        reached = False               # 有没有出现 Reach condition（= 真达成）
        called_task = ""              # Alas 中途转去处理的那个任务（比如「Commission」）
        brake = ""                    # 非空 = 判定卡住，理由写在里面
        crashed = False               # Alas 自己抛异常崩了（Traceback）
        entered = False               # 有没有进过图（换队后的超时判据只看这个）

        def feed(line: str) -> None:
            nonlocal hit_checked, last_progress, runs, pass_done, fought, white_runs, reached
            nonlocal called_task, crashed, entered
            collected.append(line)
            if len(collected) > FEED_LINES:
                del collected[:FEED_LINES // 4]      # 别把几小时的日志全攒在内存里
            if not hit_checked:
                # 核对"精准命中"：Alas 实际开始跑的关卡 vs 你要的关卡
                token = campaign_started(line)
                if token:
                    hit_checked = True
                    if same_stage(token, stage):
                        self.say(f"  ✔ 确认了：正在打 {token}")
                    else:
                        self.say(f"  ❌ 打错图了：你要 {stage}，它却在打 {token}"
                                 " —— 请把这条发给开发者")
            if COMBAT.search(line):
                fought = True
            if ENTER_MAP.search(line):
                entered = True
            tc = TASK_CALL.search(line)
            if tc:
                called_task = tc.group(1)      # Alas 转去处理它了，这一趟不会再进图
            if CAMPAIGN_END.search(line):
                if not fought:
                    white_runs += 1     # 一趟架都没打成 = 真白跑（跟"没三星"是两码事）
                fought = False
                pass_done = True
            m = MAP_INFO.search(line)
            if m:
                if pass_done:           # 新一趟进图重读星数 → 上一趟结账
                    pass_done = False
                    runs += 1
                if "3_stars" in m.group(2):
                    # 重读已经看到三星 = Alas 紧接着就会自己推关收工
                    # （`module/map/map_operation.py:169-172`），别在这个节骨眼上刹车
                    reached = True
            if REACH.search(line):
                reached = True
            if CRASH.search(line):
                crashed = True
            human = translate(line)
            if human:
                last_progress = time.time()
                self.say("  " + human)

        # 第一次运行时日志文件可能还没建出来
        deadline = time.time() + 20
        while not log_path.exists() and time.time() < deadline:
            time.sleep(TAIL_INTERVAL)

        # 跟读：每轮重新打开并 seek 到上次的**字节**位置 ——
        # 文件对象读到 EOF 后会缓存，不重开就可能永远读不到新追加的内容。
        pos, rest = offset, b""
        while True:
            # 刹车 —— Alas 的单任务入口自己就会"打完一趟再起一趟"（`campaign/run.py` 的 while 循环），
            # 所以某一关永远打不完时，它会一直重开同一张图，而小窗只会傻等：
            # 实测见过连刷 40 分钟 `Walk timeout`、一步没走成（2026-10-14 C3）。
            # 「白跑」按"这一趟**打没打成架**"算，不按"有没有三星"算（详见 stuck_reason 的注释）；
            # 三星另加趟数上限，"趟数"要等下一次重读星数才算 —— 这样刹车不会抢在
            # Alas 宣布三星之前（4-3 实测被抢过）。刷油关掉这两个判据：它的刹车是油量。
            # 换队后只等「进图」这一个信号（2026-10-28 用户实测：正常刷一局时
            # 两次「石油」之间能隔 2~3 分钟，用"任何日志都没动静"会误杀）
            if first_map_s and not entered and time.time() > started_at + first_map_s:
                self.say(f"  ⏹ {first_map_s} 秒还没进图，已替你停掉 Alas")
                self.box.stop()
                stuck, reason = "no_map", "没进到图里"
                break
            stuck, reason = stuck_reason(white_runs, reached, time.time() - last_progress,
                                         allow_runs=mode not in (MODE_OIL, MODE_ROTATE),
                                         runs=runs, run_limit=MAX_RUNS_3STARS,
                                         silent_s=silent_s)
            if stuck:
                if stuck == "runs":
                    self.say(f"  ⏹ {stage} 刷到趟数上限，已替你停掉 Alas")
                else:
                    self.say(f"  ⏹ {stage} 卡住了，已替你停掉 Alas")
                self.box.stop()
                break

            chunk = b""
            if log_path.exists():
                try:
                    with log_path.open("rb") as fh:
                        fh.seek(pos)
                        chunk = fh.read()
                except OSError:
                    chunk = b""
            if chunk:
                pos += len(chunk)
                rest += chunk
                *whole, rest = rest.split(b"\n")
                for raw in whole:
                    feed(raw.decode("utf-8", "ignore") + "\n")
                continue
            if proc.poll() is not None:
                break
            time.sleep(TAIL_INTERVAL)

        if rest.strip():
            feed(rest.decode("utf-8", "ignore") + "\n")
        proc.wait()

        raw = "".join(collected)
        self._dump_raw(raw)
        # 卡住之后按**日志证据**分原因：能修的（掉线/卡死）和修不好的（编队空）走不同路
        if stuck == "silent":
            if ADB_BAD.search(raw):
                stuck = "adb"
            elif GAME_STUCK.search(raw):
                stuck = "game"
        self._last_stuck = stuck

        if stuck == "no_map":
            self.set_status(f"{stage} 没进图")
            return False, stuck
        if stuck and stuck != "no_map":    # no_map 上面已经说过了，别重复
            if mode in (MODE_OIL, MODE_ROTATE):
                self.say(f"  ⚠️ 刷石油卡住了（{reason}）—— 这一步一直没进展，已替你停掉 Alas。")
                self.say("     可以再点一次「刷光石油」；再停在同一个地方，这关就先别挂了。")
            elif stuck == "runs":
                self.say(f"  ⏹ {stage} 刷了 {runs} 趟还没满星，助手先暂停让你确认一下是否存在异常；"
                         "如需继续，再点一次「一键三星」接着刷")
            else:
                if stuck == "silent" and attempt > 1:
                    reason = f"自动跑了 2 趟都没能通关（{reason}）"
                self.say(f"  ⚠️ 当前 {stage} 关卡脚本出现异常（{reason}）—— "
                         "可尝试撤退后重进「一键三星」，或由你手动通关。")
                self.say(f"     打完拿到三星后，再点一次「一键三星」，会自动从下一关接着推。")
            self.set_status(f"{stage} 刷到上限" if stuck == "runs" else f"{stage} 卡住")
            return False, stuck

        if self.cancelled:
            self.say("  ⏹ 没跑完就停了")
            self.set_status("已停止")
            return False, ""

        # 引擎是被"别的任务"叫走的（日志里 `Task call: X`）→ **这一趟没有结论，不算失败**：
        # Alas 是"见到委托完成提示就 task_stop + force_call Commission"（`run.py:352-366`），
        # 而且这个检查排在**每趟进图之前**（`run.py:420`）—— 提示没被收掉，它每次都在这儿掉头。
        # 它走得比"下一趟进图重读星数"还早 —— 日志里只剩进图前那次**旧星数**，
        # 拿它判会误报"未达成"（2026-10-16 18:06 实测：游戏里已经是三星，壳报失败）。
        # 所以这条要**排在所有结论前面**，交给 `_stage` 把 X 跑掉再重试本关。
        # ⚠️ 刷油也必须走这条（2026-10-17 17:20 实测：刷 11-4 起跑 5 秒就被委托提示赶走，
        # 壳报"没刷到低油就停了" —— 其实一架都没打）。它自己收工时日志里有
        # `Triggered stop condition: Oil limit / Run count`，那两个才是真结论。
        if (called_task and not reached
                and not OIL_STOP.search(raw) and not RUN_STOP.search(raw)):
            # 文案（2026-10-21 用户定）：只说"会回来"，不解释 Alas 的机制
            return False, f"called:{called_task}"

        # 困难图今天的次数用完了（`campaign/run.py:422-429`）—— **不是失败**。
        # 星星是累计的，明天再点一次接着补；这一趟再跑第二遍也是白跑，所以直接停手。
        # （2026-10-19 用户实测 4-4 困难：第 1 趟拿 star_3，之后 Alas 不再清全图，
        #   缺的 star_2「累计击破护卫舰队」只能靠多跑；第 3 趟后次数用完停在 17/18。）
        if HARD_LIMIT.search(raw) and not reached:
            self.say("  ⏸ 困难图今天的次数用完了")
            return False, "limit"

        # Alas 自己崩了（日志里有 Traceback）—— **不是失败，也绝不自动重跑**：
        # 2026-10-21 用户实测：撤退/重进会扣困难图次数，一次次数比一次重试值钱。
        if crashed and not reached:
            self.say("  ⚠️ Alas 出错，如已进图可以手动打完这一局")
            return False, "crashed"

        # 船坞满了（设置挑不到船 → Alas 放弃）—— **不是"没打成三星"**，是根本没打成。
        # 2026-10-21 实机：这条落到最后的 stars_verdict，用户看到"⚠️ 未达成：地图 0%"
        # —— 完全误导，他以为关卡太难，其实只差去游戏里清一次船坞。
        if DOCK_FULL.search(raw) and not reached:
            self.say("  ⏸ 这一趟没打成：船坞满了，先去游戏里清一下船坞（或者改「快速退役」设置）")
            return False, "dock"

        if mode in (MODE_OIL, MODE_ROTATE):
            # 油光 = 正常收工。轮换模式靠这个标志收手 ——
            # 不然会"换了队又跑一趟、立刻因油不够再停一次"，来回空转。
            if OIL_STOP.search(raw):
                self._oil_done = True
            verdict = oil_verdict(raw)
            self.say("  " + verdict)
            return verdict.startswith("✅"), ""

        verdict = stars_verdict(raw)
        if verdict is None:
            self.say("  ⚠️ 这一趟没进到图里，所以没有结果")
            return False, ""
        self.say("  " + verdict)
        return verdict.startswith("✅"), ""

    # ---------------- 杂项 ----------------
    def _dump_raw(self, raw: str) -> None:
        """把原始输出留一份，方便后面排查（只写文件，不上界面）。

        挂机器任务（刷油、清日常）会跑几小时，全量写进文件就是几十 MB ——
        只留**最后** `DUMP_LIMIT` 个字符：要排查的都是"出问题时那会儿"的现场。

        **不上界面**（2026-10-21 实机反馈：路径对用户是噪音）。要发给我的时候，
        用界面底部那个「导出日志发给开发者」——那里会把这类文件一起打包。
        """
        try:
            LOG_DIR = paths.log_dir()          # 日志放用户目录：覆盖式更新不会把它冲掉
            path = LOG_DIR / f"onetap_{time.strftime('%Y%m%d-%H%M%S')}.log"
            note = "" if len(raw) <= DUMP_LIMIT else f"（开头 {len(raw)} 字符太长，只留了最后一段）\n"
            path.write_text(note + clean(raw[-DUMP_LIMIT:]), encoding="utf-8")
        except OSError:
            pass


def main() -> None:
    # 先处理"上次换的版本起没起来"和"有没有下好的新版" —— 都在开窗之前，见 selfupdate
    if selfupdate.bootstrap():
        return
    App().root.mainloop()

if __name__ == "__main__":
    main()
