"""壳自己的东西放哪 —— **一律不放 exe 目录**。

为什么（这是自动更新的前提，2026-10-17 定）：代码包更新会**整个替换** `app\\onetap\\`，
放在里面的 `park_state.json`（被顶掉的 Alas 原值快照，丢了 = 用户的 Alas 设置还原不了）
和日志会被一起冲掉。所以一律放用户目录：

    %APPDATA%\\MuMu碧蓝助手\\
        park_state.json     ← 壳改写 Alas 配置时的原值快照（「还原 Alas 初始配置」靠它）
        logs\\               ← 原始日志
        staging\\            ← 下好的待安装版本

源码运行时也一样用这里（`python -m onetap`），这样**开发和打包后的行为一致** ——
不然"打包后才出的 bug"永远要等到打包才能发现。
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

APP_NAME = "MuMu碧蓝助手"


def _data_name() -> str:
    """数据目录名。**测试包用独立目录**（2026-10-26 用户要"另建一个 exe 先测"）。

    为什么不共用：`park_state.json` 是"壳改 Alas 配置前的原值快照"，
    测试版和正式版共用一份的话，一边还原会把另一边的记录冲掉；
    `staging/` 和"待验证"标记也会打架。
    """
    forced = os.environ.get("ONETAP_DATA_NAME", "").strip()
    if forced:
        return forced
    try:
        name = Path(sys.executable).stem
    except (AttributeError, ValueError):
        return APP_NAME
    return f"{APP_NAME}-测试" if "测试" in name else APP_NAME


DATA_NAME = _data_name()
PACKAGE = Path(__file__).resolve().parent          # app\onetap（打包后）或仓库里的 onetap


def data_dir() -> Path:
    """`%APPDATA%\\MuMu碧蓝助手`（测试包是 `…-测试`；`APPDATA` 不在就当用户主目录）。"""
    base = os.environ.get("APPDATA") or str(Path.home())
    path = Path(base) / DATA_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def log_dir() -> Path:
    path = data_dir() / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def staging_dir() -> Path:
    path = data_dir() / "staging"
    path.mkdir(parents=True, exist_ok=True)
    return path


def park_state() -> Path:
    """存档路径；老版本把它放在 `onetap/` 里，第一次用时顺手搬过来。"""
    new = data_dir() / "park_state.json"
    old = PACKAGE / "park_state.json"
    if old.exists() and not new.exists():
        try:
            old.replace(new)
        except OSError:
            pass
    return new
